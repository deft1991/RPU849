create function fn_set_region_v3(p_rgn_id bigint) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
 res boolean  := true;
 r record;
 v_time time;
BEGIN
  -- 1270
  insert into tst_log(report_name, duration, rgn_id, szn_id, date_time) values('start 1270',  null, p_rgn_id, null, clock_timestamp()::timestamp);
  FOR r IN (select id  from ref_szn szn where rgn_id = p_rgn_id)
  LOOP
     v_time := clock_timestamp()::time;
	DELETE FROM rpt_remote_control_detail 
	WHERE 1 = 1
	  AND rgn_id = p_rgn_id 
	  AND szn_id = r.id
	  AND report_name = '1270'
	;
	insert into tst_log(report_name, duration, rgn_id, szn_id, date_time) values('delete 1270', date_part('second',(clock_timestamp()::time - v_time)), p_rgn_id, r.id, clock_timestamp()::timestamp);
	v_time := clock_timestamp()::time;
	INSERT INTO rpt_remote_control_detail(
	  version
	, kpy_id
	, obr_date
	, report_name
	, rgn_id
	, szn_id
	)
	SELECT
	  f.version
	, f.kpy_id
	, f.oper_date
	, '1270'
	, p_rgn_id
	, r.id  
	FROM fn_report_1270_v3(p_rgn_id, r.id, null, null, null) f;
	insert into tst_log(report_name, duration, rgn_id, szn_id, date_time) values('1270', date_part('second',(clock_timestamp()::time - v_time)), p_rgn_id, r.id, clock_timestamp()::timestamp);
	--  
  END LOOP;
  insert into tst_log(report_name, duration, rgn_id, szn_id, date_time) values('finish', null, p_rgn_id, null, clock_timestamp()::timestamp);
  RETURN true;
END;
$$;
