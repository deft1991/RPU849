create function fn_max_date(date1 date, date2 date) returns date
LANGUAGE plpgsql
AS $$
BEGIN                
				return case
							when date1 is null then date2
							when date2 is null then date1
							else case when date1 > date2 then date1 else date2 end
						end;
			END;

$$;
