CREATE MATERIALIZED VIEW vm_okpdtr_prof AS SELECT prof.okpdtr_id,
    COALESCE(min(prof.id), (0)::bigint) AS id
   FROM ref_prof prof
  GROUP BY prof.okpdtr_id;
