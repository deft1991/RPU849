create function get_order_title(ordernum character varying, orderdate date, quoted boolean DEFAULT true) returns character varying
LANGUAGE plpgsql
AS $$
DECLARE
				result varchar := '';
				BEGIN
				IF ordernum IS NULL then Result= '';
				ELSE BEGIN
				Result = 'Пр.№ ' || ordernum;
				IF orderDate IS NOT NULL then
				Result= Result || ' от ' || to_char(orderDate, 'DD.MM.YYYY');
				END iF;
				END;
				END IF;
				IF Result != '' and Quoted is TRUE then Result = '(' || result || ')';
				END IF;
				RETURN Result;
				END;


$$;
