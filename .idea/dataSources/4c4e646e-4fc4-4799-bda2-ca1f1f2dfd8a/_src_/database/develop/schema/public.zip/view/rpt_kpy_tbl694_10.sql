CREATE VIEW rpt_kpy_tbl694_10 AS SELECT kpy.id,
    kpy.version,
    kpy.doc_date,
    kpy.num,
    kpy.obr_date,
    kpy.pz_close_date,
    kpy.szn_rec_id,
    kpy.close_rsn_id,
    kpy.pers_id,
    kpy.pz_close_rsn_id,
    kpy.szn_dep_id,
    kpy.close_date,
    kpy.sys_id,
    kpy.career_id,
    kpy.info_id,
    kpy.pob_id,
    concat(pers.last_name, ' ', pers.first_name, ' ', pers.middle_name) AS fio,
    szn.name AS szn,
    rgn.name AS rgn,
    ( SELECT tpr.name
           FROM psn_job_search_problem dfj,
            ref_dict_line tpr
          WHERE ((dfj.kpy_id = kpy.id) AND (tpr.id = dfj.tpr_id))
         LIMIT 1) AS tpr,
    kzf.name AS kzf,
    rgn.id AS rgn_id
   FROM ((((((psn_kpy kpy
     JOIN psn_person pers ON ((pers.id = kpy.pers_id)))
     JOIN ref_szn szn ON ((kpy.szn_dep_id = szn.id)))
     JOIN psn_career career ON ((career.id = kpy.career_id)))
     JOIN ref_rgn rgn ON ((szn.rgn_id = rgn.id)))
     LEFT JOIN psn_kpy_info persinfo ON ((persinfo.id = kpy.info_id)))
     LEFT JOIN ref_dict_line kzf ON ((kzf.id = persinfo.kzf_id)))
  WHERE ((kpy.obr_date IS NOT NULL) AND ((career.total_staj_month > 12) OR (career.total_staj_month > 31) OR (date_part('year'::text, justify_days((((kpy.obr_date - pers.birth_date))::double precision * '1 day'::interval))) < ((career.total_staj_years + 6))::double precision)));
