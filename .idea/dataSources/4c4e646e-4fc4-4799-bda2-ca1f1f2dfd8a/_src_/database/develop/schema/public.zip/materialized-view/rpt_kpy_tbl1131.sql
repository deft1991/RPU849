CREATE MATERIALIZED VIEW rpt_kpy_tbl1131 AS SELECT kpy.id,
    kpy.version,
    kpy.close_date,
    kpy.doc_date,
    kpy.num,
    kpy.obr_date,
    kpy.pz_close_date,
    kpy.szn_rec_id,
    kpy.close_rsn_id,
    kpy.pers_id,
    kpy.pz_close_rsn_id,
    kpy.szn_dep_id,
    concat(person.last_name, ' ', person.first_name, ' ', person.middle_name) AS fio,
    pol.name AS pol,
    szn.name AS szn_name,
    rgn.name AS rgn_name,
    rgn.id AS rgn_id,
    ( SELECT tpr.name
           FROM psn_job_search_problem dfj,
            ref_dict_line tpr
          WHERE ((dfj.kpy_id = kpy.id) AND (tpr.id = dfj.tpr_id))
         LIMIT 1) AS tpr_name,
    kzf.name AS kzf_name,
    pens.proposit_date,
    career.insur_staj_years,
    NULL::bigint AS career_id,
    NULL::bigint AS info_id,
    NULL::bigint AS pob_id
   FROM ((((((((psn_kpy kpy
     JOIN psn_set_pens pens ON ((kpy.id = pens.kpy_id)))
     LEFT JOIN psn_person person ON ((person.id = kpy.pers_id)))
     LEFT JOIN ref_dict_line pol ON ((pol.id = person.pol_id)))
     JOIN psn_career career ON (((career.id = kpy.career_id) AND
        CASE
            WHEN (lower((pol.code)::text) = 'м'::text) THEN (career.insur_staj_years < 25)
            WHEN (lower((pol.code)::text) = 'ж'::text) THEN (career.insur_staj_years < 20)
            ELSE NULL::boolean
        END)))
     LEFT JOIN psn_kpy_info p_info ON ((kpy.info_id = p_info.id)))
     LEFT JOIN ref_szn szn ON ((szn.id = kpy.szn_dep_id)))
     LEFT JOIN ref_rgn rgn ON ((rgn.id = szn.rgn_id)))
     LEFT JOIN ref_dict_line kzf ON ((p_info.kzf_id = kzf.id)))
  WHERE (career.insur_staj_years <> 0);
