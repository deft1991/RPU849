CREATE MATERIALIZED VIEW rpt_kpy_tbl1085 AS WITH cte AS (
         SELECT kpy.id,
            kpy.version,
            kpy.doc_date,
            kpy.num,
            kpy.obr_date,
            kpy.pz_close_date,
            kpy.szn_rec_id,
            kpy.close_rsn_id,
            kpy.pers_id,
            kpy.pz_close_rsn_id,
            kpy.szn_dep_id,
            kpy.close_date,
            kpy.sys_id,
            kpy.career_id,
            kpy.info_id,
            kpy.pob_id,
            kpy.id AS kpy_id,
            concat(pers.last_name, ' ', pers.first_name, ' ', pers.middle_name) AS fio,
            szn.name AS szn,
            rgn.name AS rgn,
            pp.oper_date,
            pp.start_date,
            pp.end_date,
            rgn.id AS rgn_id,
            (pp.end_date - pp.oper_date) AS date_diff,
            row_number() OVER (PARTITION BY kpy.id ORDER BY pp.oper_date DESC) AS rnum
           FROM (((((((psn_kpy kpy
             JOIN psn_order prikaz ON ((prikaz.kpy_id = kpy.id)))
             JOIN psn_person pers ON ((pers.id = kpy.pers_id)))
             JOIN psn_soc_payment_card p_pmnts_card ON ((prikaz.id = p_pmnts_card.order_id)))
             JOIN psn_soc_payment_period pp ON ((p_pmnts_card.id = pp.soc_pmnts_card_id)))
             JOIN ref_szn szn ON ((kpy.szn_dep_id = szn.id)))
             JOIN ref_rgn rgn ON ((szn.rgn_id = rgn.id)))
             JOIN ref_dict_line scv ON (((scv.id = prikaz.scv_id) AND ((scv.code)::text = '02'::text))))
          WHERE ((pp.is_recalc IS NULL) OR (pp.is_recalc = false))
        )
 SELECT cte.id,
    cte.version,
    cte.doc_date,
    cte.num,
    cte.obr_date,
    cte.pz_close_date,
    cte.szn_rec_id,
    cte.close_rsn_id,
    cte.pers_id,
    cte.pz_close_rsn_id,
    cte.szn_dep_id,
    cte.close_date,
    cte.sys_id,
    cte.career_id,
    cte.info_id,
    cte.pob_id,
    cte.kpy_id,
    cte.fio,
    cte.szn,
    cte.rgn,
    cte.oper_date,
    cte.start_date,
    cte.end_date,
    cte.rgn_id,
    cte.date_diff,
    cte.rnum
   FROM cte
  WHERE (cte.rnum = 1);
