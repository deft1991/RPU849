CREATE VIEW rpt_kpy_tbl649_14 AS SELECT DISTINCT prikaz.id,
    kpy.version,
    kpy.close_date,
    kpy.doc_date,
    kpy.num,
    kpy.obr_date,
    kpy.pz_close_date,
    kpy.szn_rec_id,
    kpy.close_rsn_id,
    kpy.pers_id,
    kpy.pz_close_rsn_id,
    kpy.szn_dep_id,
    ( SELECT tpr.name
           FROM psn_job_search_problem dfj,
            ref_dict_line tpr
          WHERE ((dfj.kpy_id = kpy.id) AND (tpr.id = dfj.tpr_id))
         LIMIT 1) AS tpr_name,
    (((((pers.last_name)::text || ' '::text) || (pers.first_name)::text) || ' '::text) || (pers.middle_name)::text) AS fio,
    kzf.name AS kzf_name,
    szn.name AS szn_name,
    rgn.name AS rgn_name,
    rgn.id AS rgn_id,
    NULL::bigint AS career_id,
    NULL::bigint AS info_id,
    NULL::bigint AS pob_id
   FROM ((((((((((psn_kpy kpy
     JOIN ref_szn szn ON ((szn.id = kpy.szn_dep_id)))
     JOIN ref_rgn rgn ON ((rgn.id = szn.rgn_id)))
     JOIN psn_person pers ON ((pers.id = kpy.pers_id)))
     JOIN psn_kpy_info p_info ON ((p_info.id = kpy.info_id)))
     LEFT JOIN ref_dict_line kzf ON ((kzf.id = p_info.kzf_id)))
     JOIN psn_order prikaz ON ((prikaz.kpy_id = kpy.id)))
     JOIN ref_dict_line prikaz_prkz ON (((prikaz_prkz.id = prikaz.prkz_id) AND ((prikaz_prkz.code)::text = '8'::text))))
     LEFT JOIN ref_dict_line rshs ON (((prikaz.rshs_id = rshs.id) AND ((rshs.code)::text <> 'O'::text))))
     LEFT JOIN psn_order prikaz_parent ON ((prikaz_parent.parent_id = prikaz.id)))
     LEFT JOIN ref_dict_line prikaz_rshs ON (((prikaz_parent.rshs_id = prikaz_rshs.id) AND ((prikaz_rshs.code)::text = 'O'::text))));
