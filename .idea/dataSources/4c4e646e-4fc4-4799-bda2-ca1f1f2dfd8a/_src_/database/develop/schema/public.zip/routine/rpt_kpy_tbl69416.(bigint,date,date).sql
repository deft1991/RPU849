create function rpt_kpy_tbl69416(p_rgn_id bigint, p_start_date date, p_finish_date date) returns TABLE(id bigint, version bigint, doc_date date, num character varying, obr_date date, pz_close_date date, szn_rec_id character varying, close_rsn_id bigint, pers_id bigint, pz_close_rsn_id bigint, szn_dep_id bigint, close_date date, sys_id character varying, career_id bigint, info_id bigint, pob_id bigint, fio character varying, szn character varying, rgn character varying, tpr character varying, kzf character varying, rgn_id bigint)
LANGUAGE SQL
AS $$
SELECT kpy.id,
		    kpy.version,
		    kpy.doc_date,
		    kpy.num,
		    kpy.obr_date,
		    kpy.pz_close_date,
		    kpy.szn_rec_id,
		    kpy.close_rsn_id,
		    kpy.pers_id,
		    kpy.pz_close_rsn_id,
		    kpy.szn_dep_id,
		    kpy.close_date,
		    kpy.sys_id,
		    kpy.career_id,
		    kpy.info_id,
		    kpy.pob_id,
		    concat(pers.last_name, ' ', pers.first_name, ' ', pers.middle_name) AS fio,
		    szn.name AS szn,
		    rgn.name AS rgn,
		    ( SELECT tpr.name
		           FROM psn_job_search_problem dfj,
		            ref_dict_line tpr
		          WHERE dfj.kpy_id = kpy.id AND tpr.id = dfj.tpr_id
		         LIMIT 1) AS tpr,
		    kzf.name AS kzf,
		    rgn.id AS rgn_id
		   FROM psn_kpy kpy
		     JOIN ref_szn szn ON kpy.szn_dep_id = szn.id AND szn.rgn_id = coalesce(p_rgn_id, szn.rgn_id)
		     JOIN ref_rgn rgn ON szn.rgn_id = rgn.id
		     JOIN psn_order prikaz1 ON prikaz1.kpy_id = kpy.id
		     JOIN ref_dict_line prkz1 ON prkz1.id = prikaz1.prkz_id AND prkz1.code::text = '1'::text
		     JOIN ref_dict_line status1 ON status1.id = prikaz1.status_id AND (status1.code::text = ANY (ARRAY['1'::character varying::text, '2'::character varying::text]))
		     JOIN psn_order prikaz13 ON prikaz13.kpy_id = kpy.id
		     JOIN ref_dict_line prkz13 ON prkz13.id = prikaz13.prkz_id AND prkz13.code::text = '13'::text
		     JOIN ref_dict_line status13 ON status13.id = prikaz13.status_id AND (status13.code::text = ANY (ARRAY['1'::character varying::text, '2'::character varying::text]))
		     JOIN psn_person pers ON pers.id = kpy.pers_id
		     JOIN psn_kpy_info persinfo ON persinfo.id = kpy.info_id
		     LEFT JOIN ref_dict_line kzf ON kzf.id = persinfo.kzf_id
		  WHERE prikaz1.order_date > prikaz13.order_date
		     AND NOT (EXISTS ( SELECT prikazo.id
		           FROM psn_order prikazo
		             JOIN ref_dict_line rshso ON prikazo.rshs_id = rshso.id AND rshso.code::text = 'О'::text
		          WHERE prikazo.parent_id = prikaz1.id OR prikazo.parent_id = prikaz13.id))
		     AND kpy.close_date >= p_start_date
		     AND kpy.obr_date <= p_finish_date
		     ;


$$;
