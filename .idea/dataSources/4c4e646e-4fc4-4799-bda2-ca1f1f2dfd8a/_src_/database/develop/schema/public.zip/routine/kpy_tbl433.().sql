create function kpy_tbl433(OUT id bigint, OUT version bigint, OUT close_date date, OUT doc_date date, OUT num character varying, OUT obr_date date, OUT pz_close_date date, OUT szn_rec_id character varying, OUT close_rsn_id bigint, OUT pers_id bigint, OUT pz_close_rsn_id bigint, OUT szn_dep_id bigint, OUT pob_id bigint, OUT vid_narusheniya character varying, OUT age_on_order_date integer, OUT period_viplaty integer, OUT obshiy_period integer, OUT period_prodleniya integer, OUT pol character varying, OUT staj integer, OUT fio character varying, OUT kzf character varying, OUT tpr character varying, OUT rgn_id bigint, OUT rgn character varying, OUT szn character varying, OUT order_date date, OUT career_id bigint, OUT info_id bigint) returns SETOF record
LANGUAGE plpgsql
AS $$
DECLARE
            rec Record; age integer; curr date;
            i integer;
            pr1 record; pr1_start_date date; pr1_end_date date;
            pr2_start_date date; pr2_end_date date;
            year1 date; year2 date;
            feb29 integer;
            BEGIN
            curr := current_date;

            FOR rec IN
            select kpy.*,
            pers.birth_date,
            pol.code as pol_code,
            prikaz.start_date, prikaz.end_date, prikaz.order_date,
            career.insur_staj_years as staj,
            concat(pers.last_name, ' ', pers.first_name, ' ', pers.middle_name) AS fio,
            kzf.name as kzf,
            tpr.name as tpr,
            szn.name as szn_name,
            rgn.id as rgn_id,
            rgn.name as rgn_name
            ,NULL::int8 as career_id, NULL::int8 as info_id
            from psn_kpy kpy
            join ref_szn szn on szn.id = kpy.szn_dep_id
            join ref_rgn rgn on szn.rgn_id = rgn.id
            join psn_order prikaz on prikaz.kpy_id = kpy.id
            join ref_dict_line prkz on prikaz.prkz_id = prkz.id and prkz.code = '6'

            join ref_dict_line prs on prikaz.prs_id = prs.id and prs.code = 'ЬС'

            join psn_order prikaz1 on prikaz1.kpy_id = kpy.id
            join ref_dict_line prkz1 on prikaz1.prkz_id = prkz1.id and prkz1.code = '1'

            join psn_person pers on kpy.pers_id = pers.id
            join ref_dict_line pol on pers.pol_id = pol.id
            join psn_career career on kpy.career_id = career.id
            join psn_kpy_info persinfo on persinfo.id = kpy.info_id
            LEFT join ref_dict_line kzf on kzf.id = persinfo.kzf_id
            LEFT join ref_dict_line tpr ON 1!=1 -- tpr.id = persinfo.tpr_id

            where
            ((date_part('year'::text, justify_days((curr - pers.birth_date)::double precision * '1 day'::interval)) >
            60 and pol.code = 'М')
            or
            (date_part('year'::text, justify_days((curr - pers.birth_date)::double precision * '1 day'::interval)) >
            55 and pol.code = 'Ж'))
            or
            ((career.insur_staj_years < 25 and pol.code = 'М') or (career.insur_staj_years < 20 and pol.code =
            'Ж'))
            or
            (period_posobiya(kpy.id) - career.insur_staj_years * 365 < 14 * career.insur_staj_years)
            or
            (select period_gt24 from obshiy_period(kpy.id))
            loop
            id := rec.id;
            version := rec.version;
            close_date := rec.close_date;
            doc_date := rec.doc_date;
            num := rec.num;
            obr_date := rec.obr_date;
            pz_close_date := rec.pz_close_date;
            szn_rec_id := rec.szn_rec_id;
            close_rsn_id := rec.close_rsn_id;
            pers_id := rec.pers_id;
            pz_close_rsn_id := rec.pz_close_rsn_id;
            szn_dep_id := rec.szn_dep_id;
            pol := rec.pol_code;
            staj := rec.staj;
            fio := rec.fio;
            kzf := rec.kzf;
            tpr := rec.tpr;
            rgn_id := rec.rgn_id;
            rgn := rec.rgn_name;
            szn := rec.szn_name;
            order_date := rec.order_date;
            career_id := rec.career_id;
            info_id := rec.info_id;
            pob_id := rec.pob_id;

            vid_narusheniya = null; age := null; age_on_order_date := null;
            year1 := null; year2 := null; pr1 = null;
            pr1_start_date := null; pr1_end_date = null; pr2_start_date := null; pr2_end_date := null;
            feb29 := null;

            age_on_order_date := (date_part('year'::text, justify_days((rec.order_date - rec.birth_date)::double
            precision * '1 day'::interval))) - 1;

            i := 0;
            for pr1 in select prikaz1.start_date, prikaz1.end_date from psn_order prikaz1 join ref_dict_line prkz1 on
            prkz1.id
            = prikaz1.prkz_id and prkz1.code ='1'
            where prikaz1.kpy_id = rec.id order by prikaz1.order_date DESC
            LOOP
            i := i + 1;
            if i = 1 then pr1_start_date := pr1.start_date;
            pr1_end_date := pr1.end_date;
            elsif i = 2 then pr2_start_date := pr1.start_date;
            pr2_end_date := pr1.end_date;
            end if;
            END LOOP;

            period_viplaty := period_posobiya(rec.id);

            obshiy_period := (select period from obshiy_period(rec.id));

            period_prodleniya := 0;
            period_prodleniya := rec.end_date - pr1_end_date;

            if i = 1 THEN
            year1 := rec.end_date;
            year2 := pr1_start_date;
            ELSIF i = 2 THEN
            year1 := pr2_end_date;
            year2 := pr1_start_date;
            END IF;

            IF date_part('month', year1) > 2 THEN year1 := ('01-01-' || (date_part('year', year1) + 1))::date;
            ELSE year1 := ('01-01-' || date_part('year', year1))::date;
            END IF;

            IF date_part('month', year2) < 2 THEN year2 := ('01-01-' || date_part('year', year2))::date;
            ELSE year2 := ('01-01-' || (date_part('year', year2) + 1))::date;
            END IF;

            feb29 := (year1 - year2) % 365;

            IF (pr1_end_date - pr1_start_date - 1) != 365 THEN vid_narusheniya := 'Первый период выплаты не 12 месяцев';
            END IF;

            IF rec.pol_code = 'М' and age_on_order_date >= 60 THEN vid_narusheniya := 'Мужчина 60 лет и старше';
            END IF;

            IF rec.pol_code = 'М' and age_on_order_date < 60 THEN
            IF rec.staj < 25 THEN vid_narusheniya := 'Стаж менее 25 лет';
            ELSIF rec.staj >= 25 and period_prodleniya != 14*(rec.staj - 25) THEN vid_narusheniya := 'Мужчина,
            неверный период продления';
            END IF;

            END IF;

            IF rec.pol_code = 'Ж' and age_on_order_date >= 55 THEN vid_narusheniya := 'Женщина 55 лет и старше';
            END IF;

            IF rec.pol_code = 'Ж' and age_on_order_date < 55 THEN
            IF rec.staj < 20 THEN vid_narusheniya := 'Стаж менее 20 лет';
            ELSIF rec.staj >= 20 and period_prodleniya != 14*(rec.staj - 25) THEN vid_narusheniya := 'Женщина,
            неверный период продления';
            END IF;
            END IF;

            IF period_viplaty > (730 + feb29) and period_viplaty <= (1095 + feb29) THEN
            IF (i=1) then vid_narusheniya := 'Период выплаты превысил 24 мес. в течение 36 мес., нет второго приказа о
            выплате';
            ELSIF (i=2) THEN vid_narusheniya := 'Период выплаты превысил 24 мес. в течение 36 мес., есть второй приказ о
            выплате';
            END IF;

            END IF;
            return next;
            END LOOP;
            END;
$$;
