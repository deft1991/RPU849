create function rpt_kpy_tbl189(p_rgn_id bigint, p_start_date date, p_finish_date date, p_usl_id bigint, p_kzf_id bigint, p_kng_id bigint, p_tpr_id bigint, p_puv_id bigint, p_age_from bigint, p_age_to bigint, p_pol_id bigint, p_uro_id bigint, p_isrelocready boolean, p_orgname character varying) returns TABLE(id bigint, version bigint, close_date date, doc_date date, num character varying, obr_date date, pz_close_date date, szn_rec_id character varying, close_rsn_id bigint, pers_id bigint, pz_close_rsn_id bigint, szn_dep_id bigint, fio text, kzf_name character varying, rgn_name character varying, szn_name character varying, tpr_name character varying, sys_id character varying, career_id bigint, info_id bigint, pob_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
				r RECORD;
				BEGIN
				RETURN QUERY
				SELECT DISTINCT kpy.id,
				kpy.version,
				kpy.close_date,
				kpy.doc_date,
				kpy.num,
				kpy.obr_date,
				kpy.pz_close_date,
				kpy.szn_rec_id,
				kpy.close_rsn_id,
				kpy.pers_id,
				kpy.pz_close_rsn_id,
				kpy.szn_dep_id,
				concat(pers.last_name, ' ', pers.first_name, ' ', pers.middle_name) AS fio,
				kzf.name AS kzf_name,
				rgn.name AS rgn_name,
				szn.name AS szn_name,
				get_tpr_by_kpy(kpy.id, p_tpr_id) AS tpr_name,
				kpy.sys_id,
				NULL::bigint AS career_id,
				NULL::bigint AS info_id,
				pob.id AS pob_id
				FROM psn_kpy kpy
				JOIN psn_person pers ON kpy.pers_id = pers.id
				JOIN psn_kpy_info p_info ON kpy.info_id = p_info.id
				JOIN ref_dict_line pob ON pob.id = kpy.pob_id
				JOIN ref_szn szn ON szn.id = kpy.szn_dep_id
				JOIN ref_rgn rgn ON rgn.id = szn.rgn_id
				LEFT JOIN ref_dict_line kzf ON p_info.kzf_id = kzf.id
				LEFT JOIN psn_kng ON psn_kng.kpy_id = kpy.id
				LEFT JOIN ref_dict_line kng ON psn_kng.kng_id = kng.id
				LEFT JOIN psn_job_search_problem jsp ON jsp.kpy_id = kpy.id
				LEFT JOIN psn_prev_work p_prev_work ON p_prev_work.kpy_id = kpy.id
				LEFT JOIN psn_prev_work p_prev_work2 ON p_prev_work2.kpy_id = pers.id AND p_prev_work.id != p_prev_work2.id AND p_prev_work.end_date < p_prev_work2.end_date
				LEFT JOIN psn_education p_edu ON p_edu.pers_id = pers.id
				LEFT JOIN lgl_organization ON lgl_organization.id = p_prev_work.org_id
				LEFT JOIN psn_service_summary service_sum ON service_sum.kpy_id = kpy.id
				WHERE (pob.code::text = ANY (ARRAY['1'::character varying::text, '2'::character varying::text, '3'::character varying::text, '4'::character varying::text])) AND p_prev_work2.end_date IS NULL
				and kpy.obr_Date>= p_start_date
				and kpy.obr_Date<= p_finish_date
				and (p_rgn_id = -1 or rgn.id = p_rgn_id)
				and (p_kzf_id = -1 or kzf.id = p_kzf_id)
				and (   (p_kng_id = -1)
				or
				(kng.id = p_kng_id and kng.code != '02')
				or
				(kng.id = p_kng_id and kng.code = '02' and p_info.unempl_date >= kpy.obr_date)
				)
				and (p_puv_id = -1 or p_prev_work.puv_id = p_puv_id)
				and     date_part('year'::text, kpy.obr_date) - date_part('year'::text, pers.birth_date) -
				CASE
				WHEN date_part('month'::text, kpy.obr_date) < date_part('month'::text, pers.birth_date) THEN 1
				WHEN date_part('month'::text, kpy.obr_date) = date_part('month'::text, pers.birth_date) AND date_part('day'::text, kpy.obr_date) < date_part('day'::text, pers.birth_date) THEN 1
				ELSE 0
				END::double precision >= p_age_from
				and     date_part('year'::text, kpy.obr_date) - date_part('year'::text, pers.birth_date) -
				CASE
				WHEN date_part('month'::text, kpy.obr_date) < date_part('month'::text, pers.birth_date) THEN 1
				WHEN date_part('month'::text, kpy.obr_date) = date_part('month'::text, pers.birth_date) AND date_part('day'::text, kpy.obr_date) < date_part('day'::text, pers.birth_date) THEN 1
				ELSE 0
				END::double precision  <= p_age_to
				and (p_pol_id = -1 or pers.pol_id = p_pol_id)
				and (p_uro_id = -1 or p_edu.uro_id = p_uro_id)
				and (p_tpr_id = -1 or jsp.tpr_id = p_tpr_id)
				and (p_info.is_reloc_ready IS NULL OR p_info.is_reloc_ready = p_isRelocReady)
				and (p_orgName = '' or (p_prev_work.org_name LIKE '%'  ||  p_orgName || '%'  or lgl_organization.full_name LIKE '%' || p_orgName || '%'))
				and service_sum.start_Date >= p_start_date
				and service_sum.start_Date <= p_finish_date
				and (p_usl_id = -1 or service_sum.usl_id = p_usl_id)
				and kpy.num in ( 'Z370713','O304502','a281590')
				;
				END;

$$;
