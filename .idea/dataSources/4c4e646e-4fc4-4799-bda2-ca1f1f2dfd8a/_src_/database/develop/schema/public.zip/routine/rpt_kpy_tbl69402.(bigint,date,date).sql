create function rpt_kpy_tbl69402(p_rgn_id bigint, p_start_date date, p_finish_date date) returns TABLE(id bigint, version bigint, doc_date date, num character varying, obr_date date, pz_close_date date, szn_rec_id character varying, close_rsn_id bigint, pers_id bigint, pz_close_rsn_id bigint, szn_dep_id bigint, close_date date, sys_id character varying, career_id bigint, info_id bigint, pob_id bigint, order_num character varying, order_date date, start_date date, end_date date, prkz character varying, summ numeric, fio character varying, szn character varying, rgn character varying)
LANGUAGE SQL
AS $$
SELECT kpy.id,
		    kpy.version,
		    kpy.doc_date,
		    kpy.num,
		    kpy.obr_date,
		    kpy.pz_close_date,
		    kpy.szn_rec_id,
		    kpy.close_rsn_id,
		    kpy.pers_id,
		    kpy.pz_close_rsn_id,
		    kpy.szn_dep_id,
		    kpy.close_date,
		    kpy.sys_id,
		    kpy.career_id,
		    kpy.info_id,
		    kpy.pob_id,
		    prikaz.order_num,
		    prikaz.order_date,
		    prikaz.start_date,
		    prikaz.end_date,
		    prkz.name AS prkz,
		    prikaz.summ,
		    concat(pers.last_name, ' ', pers.first_name, ' ', pers.middle_name) AS fio,
		    szn.name AS szn,
		    rgn.name AS rgn
		   FROM psn_kpy kpy
		     JOIN ref_szn szn ON kpy.szn_dep_id = szn.id AND szn.rgn_id = coalesce(p_rgn_id, szn.rgn_id)
		     JOIN ref_rgn rgn ON szn.rgn_id = rgn.id
		     JOIN psn_order prikaz ON prikaz.kpy_id = kpy.id AND prikaz.order_date BETWEEN p_start_date AND p_finish_date
		     JOIN ref_dict_line prkz ON prkz.id = prikaz.prkz_id AND (prkz.code::text = ANY (ARRAY['1'::character varying::text, '7'::character varying::text, '9'::character varying::text, '21'::character varying::text, '25'::character varying::text]))
		     LEFT JOIN ref_dict_line rshs ON prikaz.rshs_id = rshs.id AND rshs.code::text <> 'O'::text
		     LEFT JOIN psn_order prikaz_parent ON prikaz_parent.parent_id = prikaz.id
		     LEFT JOIN ref_dict_line prkz_parent ON prkz_parent.id = prikaz_parent.prkz_id AND (prkz_parent.code::text = ANY (ARRAY['8'::character varying::text, '10'::character varying::text, '23'::character varying::text, '26'::character varying::text]))
		     JOIN psn_person pers ON pers.id = kpy.pers_id
		  WHERE prkz_parent.id IS NULL AND (prikaz.start_date > prikaz.end_date OR ('now'::text::date + '2 years 1 mon'::interval) < prikaz.end_date);


$$;
