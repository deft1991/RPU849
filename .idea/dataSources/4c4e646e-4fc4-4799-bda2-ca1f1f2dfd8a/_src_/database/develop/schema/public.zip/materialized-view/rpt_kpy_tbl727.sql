CREATE MATERIALIZED VIEW rpt_kpy_tbl727 AS SELECT DISTINCT kpy.id,
    kpy.version,
    kpy.doc_date,
    kpy.num,
    kpy.obr_date,
    kpy.pz_close_date,
    kpy.szn_rec_id,
    kpy.close_rsn_id,
    kpy.pers_id,
    kpy.pz_close_rsn_id,
    kpy.szn_dep_id,
    kpy.close_date,
    kpy.sys_id,
    kpy.career_id,
    kpy.info_id,
    kpy.pob_id,
    concat(person.last_name, ' ', person.first_name, ' ', person.middle_name) AS fio,
    scv.name AS scv,
    prp.name AS prp,
    prikaz9_25.order_date,
    prikaz9_25.order_num,
    prikaz9_25.summ,
    szn.name AS szn,
    prkz.name AS prkz,
    rgn.name AS rgn,
    rgn.id AS rgn_id
   FROM ((((((((((psn_kpy kpy
     LEFT JOIN psn_person person ON ((person.id = kpy.pers_id)))
     JOIN psn_order prikaz9_25 ON ((prikaz9_25.kpy_id = kpy.id)))
     JOIN ref_dict_line prkz_dict ON ((prkz_dict.id = prikaz9_25.prkz_id)))
     JOIN ref_dict_line stp ON ((prikaz9_25.status_id = stp.id)))
     JOIN ref_dict_line ifn ON ((prikaz9_25.ifn_id = ifn.id)))
     LEFT JOIN ref_szn szn ON ((kpy.szn_dep_id = szn.id)))
     LEFT JOIN ref_rgn rgn ON ((rgn.id = szn.rgn_id)))
     LEFT JOIN ref_dict_line scv ON ((scv.id = prikaz9_25.scv_id)))
     LEFT JOIN ref_dict_line prkz ON ((prkz.id = prikaz9_25.prkz_id)))
     LEFT JOIN ref_dict_line prp ON ((prp.id = prikaz9_25.prp_id)))
  WHERE (((prkz_dict.code)::text = ANY (ARRAY['25'::text, '9'::text])) AND ((stp.code)::text = '1'::text) AND (((ifn.code)::text = '3'::text) OR (ifn.id IS NULL)) AND (prikaz9_25.order_date > to_date('2006-01-01'::text, 'YYYY-MM-DD'::text)) AND (prikaz9_25.prp_id IS NOT NULL));
