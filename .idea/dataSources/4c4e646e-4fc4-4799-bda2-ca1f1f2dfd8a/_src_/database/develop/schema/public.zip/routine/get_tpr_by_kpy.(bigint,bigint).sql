create function get_tpr_by_kpy(kpyid bigint, tprid bigint) returns character varying
LANGUAGE plpgsql
AS $$
DECLARE
					result varchar := '';

				BEGIN
					SELECT
						string_agg(tpr.name, ', ')
						INTO result
					FROM psn_kpy kpy
						JOIN psn_job_search_problem jsp ON jsp.kpy_id = kpy.id
						JOIN ref_dict_line tpr ON jsp.tpr_id = tpr.id
					WHERE kpy.id = kpyId
						and (tprid is NULL or jsp.tpr_id = tprid);

					RETURN result;

				END;



$$;
