create function rpt_kpy_tbl69406(p_rgn_id bigint, p_start_date date, p_finish_date date) returns TABLE(id bigint, version bigint, doc_date date, num character varying, obr_date date, pz_close_date date, szn_rec_id character varying, close_rsn_id bigint, pers_id bigint, pz_close_rsn_id bigint, szn_dep_id bigint, close_date date, sys_id character varying, career_id bigint, info_id bigint, pob_id bigint, order_num character varying, order_date date, start_date date, end_date date, prkz character varying, summ numeric, fio character varying, szn character varying, rgn character varying)
LANGUAGE SQL
AS $$
SELECT kpy.id,
		    kpy.version,
		    kpy.doc_date,
		    kpy.num,
		    kpy.obr_date,
		    kpy.pz_close_date,
		    kpy.szn_rec_id,
		    kpy.close_rsn_id,
		    kpy.pers_id,
		    kpy.pz_close_rsn_id,
		    kpy.szn_dep_id,
		    kpy.close_date,
		    kpy.sys_id,
		    kpy.career_id,
		    kpy.info_id,
		    kpy.pob_id,
		    prikaz.order_num,
		    prikaz.order_date,
		    prikaz.start_date,
		    prikaz.end_date,
		    prkz.name AS prkz,
		    prikaz.summ,
		    concat(pers.last_name, ' ', pers.first_name, ' ', pers.middle_name) AS fio,
		    szn.name AS szn,
		    rgn.name AS rgn
		   FROM psn_kpy kpy
		     JOIN ref_szn szn ON kpy.szn_dep_id = szn.id AND szn.rgn_id = coalesce(p_rgn_id, szn.rgn_id)
		     JOIN ref_rgn rgn ON szn.rgn_id = rgn.id
		     JOIN psn_order prikaz ON prikaz.kpy_id = kpy.id
		     LEFT JOIN ref_dict_line rshs ON prikaz.rshs_id = rshs.id AND (rshs.code::text = ANY (ARRAY['Р'::character varying, 'К'::character varying, 'С'::character varying, 'Е'::character varying]::text[]))
		     JOIN psn_person pers ON pers.id = kpy.pers_id
		     LEFT JOIN ref_dict_line prkz ON prkz.id = prikaz.prkz_id AND (prkz.code::text = ANY (ARRAY['9'::character varying, '25'::character varying]::text[]))
		     LEFT JOIN ref_dict_line ifn ON ifn.id = prikaz.ifn_id
		  WHERE NOT (EXISTS ( SELECT prikazo.id
		           FROM psn_order prikazo
		             JOIN ref_dict_line rshso ON prikazo.rshs_id = rshso.id AND rshso.code::text = 'О'::text
		          WHERE prikazo.parent_id = prikaz.id))
		     AND (rshs.id IS NOT NULL OR prkz.id IS NOT NULL)
		     AND (prikaz.prp_id IS NULL OR ifn.code::text = '3'::text)
		     AND prikaz.order_date BETWEEN p_start_date AND p_finish_date
		     ;


$$;
