CREATE MATERIALIZED VIEW rpt_kpy_tbl1177 AS SELECT DISTINCT psn_order.id AS order_id,
    kpy.id,
    kpy.version,
    kpy.close_date,
    kpy.doc_date,
    kpy.num,
    kpy.obr_date,
    kpy.pz_close_date,
    kpy.szn_rec_id,
    kpy.close_rsn_id,
    kpy.pers_id,
    kpy.pz_close_rsn_id,
    kpy.szn_dep_id,
    psn_order.order_num AS ordernum,
    scv.id AS scv_id,
    scv.name AS scvname,
    concat(person.last_name, ' ', person.first_name, ' ', person.middle_name) AS fio,
    kng.name AS kngname,
    szn.name AS sznname,
    psn_order.summ AS ordersum,
    psn_order.order_date AS orderdate,
    tpr.name AS tprname,
    rshs.name AS rshsname,
    prp.name AS prpname,
    prp.id AS prp_id,
    rgn.name AS rgnname,
    rgn.id AS rgn_id,
    prkz.id AS prkz_id,
    NULL::bigint AS career_id,
    NULL::bigint AS info_id,
    NULL::bigint AS pob_id,
    psn_order.start_date,
    psn_order.end_date,
    psn_order.region_coeff,
    sys_talon.sys_updated,
    algo.name AS algo,
    (date_part('year'::text, now()) - date_part('year'::text, person.birth_date)) AS age,
    psn_study.start_date AS study_start_date,
    psn_job.start_date AS job_start_date,
    pw.end_date AS pw_end_date,
    person.birth_date,
    psn_order.staj_last_year,
    ref_lim_max.name AS lim_max,
    ref_lim_min.name AS lim_min,
    close_rsn.name AS close_rsn_name,
    puv.name AS puv,
    ref_prof.name AS prof,
    person.snils,
    psn_order.zp
   FROM (((((((((((((((((((((((((psn_kpy kpy
     LEFT JOIN psn_person person ON ((person.id = kpy.pers_id)))
     LEFT JOIN psn_kpy_info p_info ON ((kpy.info_id = p_info.id)))
     LEFT JOIN ref_dict_line kng ON ((1 <> 1)))
     LEFT JOIN psn_order psn_order ON ((kpy.id = psn_order.kpy_id)))
     LEFT JOIN psn_soc_payment_card card ON ((card.order_id = psn_order.id)))
     LEFT JOIN psn_soc_payment_period period ON ((period.soc_pmnts_card_id = card.id)))
     LEFT JOIN psn_soc_payment_sum sum ON ((sum.pmnts_period_id = period.id)))
     JOIN ref_dict_line tnch ON (((tnch.id = sum.tnch_id) AND ((tnch.code)::text <> ALL ((ARRAY['Н'::character varying, 'О'::character varying])::text[])))))
     LEFT JOIN ref_szn szn ON ((szn.id = kpy.szn_dep_id)))
     LEFT JOIN ref_dict_line tpr ON ((1 <> 1)))
     LEFT JOIN ref_dict_line scv ON ((scv.id = psn_order.scv_id)))
     LEFT JOIN ref_dict_line rshs ON ((rshs.id = psn_order.rshs_id)))
     LEFT JOIN ref_dict_line prp ON ((prp.id = psn_order.prs_id)))
     LEFT JOIN ref_dict_line prkz ON ((prkz.id = psn_order.prkz_id)))
     LEFT JOIN ref_rgn rgn ON ((rgn.id = szn.rgn_id)))
     LEFT JOIN psn_prev_work pw ON (((pw.kpy_id = kpy.id) AND (pw.is_last = true))))
     LEFT JOIN psn_study ON ((psn_study.kpy_id = kpy.id)))
     LEFT JOIN psn_job ON ((psn_job.kpy_id = kpy.id)))
     LEFT JOIN ref_dict_line ref_lim_max ON ((ref_lim_max.id = psn_order.lim_max_id)))
     LEFT JOIN ref_dict_line ref_lim_min ON ((ref_lim_min.id = psn_order.lim_min_id)))
     LEFT JOIN ref_dict_line close_rsn ON ((close_rsn.id = kpy.close_rsn_id)))
     LEFT JOIN ref_dict_line algo ON ((algo.id = psn_order.algo_id)))
     LEFT JOIN ref_dict_line puv ON ((puv.id = pw.puv_id)))
     LEFT JOIN ref_prof ON ((ref_prof.id = pw.prof_id)))
     JOIN sys_talon ON (((sys_talon.sys_id)::text = (psn_order.sys_id)::text)));
