CREATE VIEW vm_sys_talon AS SELECT sys_talon.id,
    sys_talon.version,
    sys_talon.fdate,
    sys_talon.ftime,
    (((sys_talon.fdate || ' '::text) || (sys_talon.ftime)::text))::timestamp without time zone AS fdatetime,
    sys_talon.npart,
    sys_talon.parts,
    sys_talon.person,
    sys_talon.rhd_bgyear,
    sys_talon.rhd_filial,
    sys_talon.rhd_okato,
    sys_talon.rhd_region,
    sys_talon.rhd_schema,
    sys_talon.rhd_user,
    (sys_talon.sys_created)::timestamp(0) without time zone AS sys_created,
    sys_talon.sys_id,
    sys_talon.sys_status,
    (sys_talon.sys_updated)::timestamp(0) without time zone AS sys_updated,
    sys_talon.tdate,
    sys_talon.ttime,
    (((sys_talon.tdate || ' '::text) || (sys_talon.ttime)::text))::timestamp without time zone AS tdatetime,
    sys_talon.txt_filial,
    sys_talon.txt_schema,
    sys_talon.vdate,
    sys_talon.vers,
    sys_meta.pktname,
    sys_meta.received,
    sysstatus.name AS status,
    ref_rgn.name AS region
   FROM (((sys_talon
     LEFT JOIN ref_rgn ON (((sys_talon.rhd_region)::bigint = ref_rgn.id)))
     LEFT JOIN sys_meta ON (((sys_talon.sys_id)::text = (sys_meta.sys_id)::text)))
     LEFT JOIN ref_sys_talon_status sysstatus ON ((sys_talon.sys_status = sysstatus.status)))
  WHERE (sysstatus.status <> ALL (ARRAY[(20)::bigint, (100)::bigint]))
  ORDER BY sys_meta.received DESC;
