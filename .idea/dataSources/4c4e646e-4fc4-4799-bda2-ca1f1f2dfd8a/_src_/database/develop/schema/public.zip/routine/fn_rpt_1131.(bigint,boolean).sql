create function fn_rpt_1131(p_report_run_id bigint, is_histoty boolean) returns TABLE(id bigint, kpy_id bigint, version bigint)
LANGUAGE plpgsql
AS $$
DECLARE
  r     RECORD;
  p_rgn int8;
  p_szn int8;
  p_start_date date;
  p_finish_date date;
  v_cnt  int8 := 0;
BEGIN
	-- Параметры отчета
	SELECT
	  max(t.rgn) AS rgn
	, max(t.szn) AS szn
	, max(t.p_start_date) AS p_start_date
	, max(t.p_finish_date) AS p_finish_date
	INTO
	  p_rgn
	, p_szn
	, p_start_date
	, p_finish_date	  
	FROM (
		SELECT 
		  (CASE par.code WHEN 'rgn' THEN val.value_number ELSE NULL END) rgn
		, (CASE par.code WHEN 'szn' THEN val.value_number ELSE NULL END) szn
		, (CASE par.code WHEN 'p_start_date' THEN val.value_date ELSE NULL END) p_start_date
		, (CASE par.code WHEN 'p_finish_date' THEN val.value_date ELSE NULL END) p_finish_date
		FROM rpt_run_param val
		LEFT JOIN rpt_report_param par ON  par.id = val.param_id
		WHERE 1 = 1
			AND val.report_run_id = p_report_run_id
	) t
	;		
	-- ================================================================
	-- Итог
	-- ================================================================	     
     IF NOT is_histoty THEN 
     	-- Онлайн или по планировщику
	 	FOR r IN (
				SELECT DISTINCT
					kpy.id AS kpy_id,
					kpy.version,
					kpy.close_date,
					kpy.doc_date,
					kpy.num,
					kpy.obr_date,
					kpy.pz_close_date,
					kpy.szn_rec_id,
					kpy.close_rsn_id,
					kpy.pers_id,
					kpy.pz_close_rsn_id,
					kpy.szn_dep_id,
					concat(person.last_name, ' ', person.first_name, ' ', person.middle_name) AS fio,
					pol.name AS pol,
					szn.name AS szn_name,
					rgn.name AS rgn_name,
					rgn.id AS rgn_id,
					( SELECT tpr.name
					  FROM psn_job_search_problem dfj,
						  ref_dict_line tpr
					  WHERE dfj.kpy_id = kpy.id AND tpr.id = dfj.tpr_id LIMIT 1
					) AS tpr_name,
					kzf.name AS kzf_name,
					pens.proposit_date,
					career.insur_staj_years,
					NULL::bigint AS career_id,
					NULL::bigint AS info_id,
					NULL::bigint AS pob_id
				FROM psn_kpy kpy
				INNER JOIN ref_szn szn ON szn.id = kpy.szn_dep_id AND szn.id = coalesce(p_szn, szn.id)
				INNER JOIN ref_rgn rgn ON rgn.id = szn.rgn_id AND rgn.id = coalesce(p_rgn, rgn.id)				
				INNER JOIN psn_person person ON person.id = kpy.pers_id
				INNER JOIN psn_set_pens pens ON kpy.id = pens.kpy_id
				LEFT JOIN ref_dict_line pol ON pol.id = person.pol_id
				INNER JOIN psn_career career ON career.id = kpy.career_id AND
					CASE
					WHEN (lower(pol.code)::text = 'м'::text) THEN (career.insur_staj_years < 25)
					WHEN (lower(pol.code)::text = 'ж'::text) THEN (career.insur_staj_years < 20)
					ELSE NULL::boolean
					END
				LEFT JOIN psn_kpy_info p_info ON kpy.info_id = p_info.id
				LEFT JOIN ref_dict_line kzf ON p_info.kzf_id = kzf.id
				WHERE 1 = 1
					AND career.insur_staj_years <> 0
			 )
		LOOP
			-- Результаты запуска отчетов
			v_cnt := v_cnt + 1;
			INSERT INTO rpt_run_result(
			  version
			, num
			, object_id
			, report_run_id
			)
			VALUES (
			  0
			, v_cnt 
			, r.kpy_id
			, p_report_run_id
			); 
			--
			id := nextval('seq_mdn_kpy');
			kpy_id := r.kpy_id;
			version := r.version;
			RETURN NEXT;
			--
		END LOOP;
		--
		UPDATE rpt_run
		SET reg_date = now()
		, sto_id = (SELECT l.id FROM ref_dict d, ref_dict_line l WHERE d.id = l.dict_id AND d.code = 'СТО' AND l.code = '3')
		WHERE rpt_run.id = p_report_run_id
		;	
		--
	ELSE
	 	FOR r IN (
				SELECT DISTINCT
					kpy.id AS kpy_id,
					kpy.version,
					kpy.close_date,
					kpy.doc_date,
					kpy.num,
					kpy.obr_date,
					kpy.pz_close_date,
					kpy.szn_rec_id,
					kpy.close_rsn_id,
					kpy.pers_id,
					kpy.pz_close_rsn_id,
					kpy.szn_dep_id,
					concat(person.last_name, ' ', person.first_name, ' ', person.middle_name) AS fio,
					pol.name AS pol,
					szn.name AS szn_name,
					rgn.name AS rgn_name,
					rgn.id AS rgn_id,
					( SELECT tpr.name
					  FROM psn_job_search_problem dfj,
						  ref_dict_line tpr
					  WHERE dfj.kpy_id = kpy.id AND tpr.id = dfj.tpr_id LIMIT 1
					) AS tpr_name,
					kzf.name AS kzf_name,
					pens.proposit_date,
					career.insur_staj_years,
					NULL::bigint AS career_id,
					NULL::bigint AS info_id,
					NULL::bigint AS pob_id
				FROM psn_kpy kpy
				INNER JOIN rpt_run_result rsl ON rsl.object_id = kpy.id
					AND rsl.report_run_id = p_report_run_id
				INNER JOIN ref_szn szn ON szn.id = kpy.szn_dep_id AND szn.id = coalesce(p_szn, szn.id)
				INNER JOIN ref_rgn rgn ON rgn.id = szn.rgn_id AND rgn.id = coalesce(p_rgn, rgn.id)				
				INNER JOIN psn_person person ON person.id = kpy.pers_id
				INNER JOIN psn_set_pens pens ON kpy.id = pens.kpy_id
				LEFT JOIN ref_dict_line pol ON pol.id = person.pol_id
				INNER JOIN psn_career career ON career.id = kpy.career_id AND
					CASE
					WHEN (lower(pol.code)::text = 'м'::text) THEN (career.insur_staj_years < 25)
					WHEN (lower(pol.code)::text = 'ж'::text) THEN (career.insur_staj_years < 20)
					ELSE NULL::boolean
					END
				LEFT JOIN psn_kpy_info p_info ON kpy.info_id = p_info.id
				LEFT JOIN ref_dict_line kzf ON p_info.kzf_id = kzf.id
				WHERE 1 = 1
					AND career.insur_staj_years <> 0
			 )
		LOOP
			id := nextval('seq_mdn_kpy');
			kpy_id := r.kpy_id;
			version := r.version;
			RETURN NEXT;
		END LOOP;
		--		
	END IF;
END;
$$;
