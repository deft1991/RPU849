CREATE MATERIALIZED VIEW rpt_kpy_tbl1457 AS SELECT kpy.id,
    kpy.version,
    kpy.doc_date,
    kpy.num,
    kpy.obr_date,
    kpy.pz_close_date,
    kpy.szn_rec_id,
    kpy.close_rsn_id,
    kpy.pers_id,
    kpy.pz_close_rsn_id,
    kpy.szn_dep_id,
    kpy.close_date,
    kpy.sys_id,
    kpy.career_id,
    kpy.info_id,
    kpy.pob_id,
    kpy.unempl_date,
    kpy.id AS kpy_id,
    concat(p.last_name, ' ', p.first_name, ' ', p.middle_name) AS fio,
    szn.name AS szn,
    rgn.name AS rgn,
    rgn.id AS rgn_id,
    ( SELECT tpr.name
           FROM psn_job_search_problem dfj,
            ref_dict_line tpr
          WHERE ((dfj.kpy_id = kpy.id) AND (tpr.id = dfj.tpr_id))
         LIMIT 1) AS tpr,
    kzf.name AS kzf
   FROM (((((((psn_kpy kpy
     JOIN ref_szn szn ON ((szn.id = kpy.szn_dep_id)))
     JOIN ref_rgn rgn ON ((rgn.id = szn.rgn_id)))
     JOIN psn_person p ON ((p.id = kpy.pers_id)))
     JOIN psn_kpy_info inf ON ((inf.id = kpy.info_id)))
     JOIN ref_dict_line kzf ON ((kzf.id = inf.kzf_id)))
     JOIN psn_doc_offered sdc ON ((sdc.kpy_id = kpy.id)))
     JOIN ref_dict_line dok ON ((dok.id = sdc.doc_id)))
  WHERE ((EXISTS ( SELECT dict_kng.name
           FROM psn_kng tkng,
            ref_dict_line dict_kng
          WHERE ((tkng.kpy_id = kpy.id) AND (dict_kng.id = tkng.kng_id) AND ((dict_kng.code)::text <> ALL ((ARRAY['01'::character varying, '03'::character varying])::text[]))))) AND (kpy.unempl_date IS NOT NULL) AND (COALESCE(sdc.szn_date, (kpy.unempl_date + 1)) > kpy.unempl_date));
