CREATE VIEW fn_vm_soc_prd AS SELECT soc_card.order_id,
    soc_prd.id AS prd_id,
    soc_prd.oper_date,
    soc_prd.start_date,
    soc_prd.end_date,
    soc_sum.summ AS prd_sum
   FROM ((psn_soc_payment_card soc_card
     JOIN psn_soc_payment_period soc_prd ON (((soc_prd.soc_pmnts_card_id = soc_card.id) AND (COALESCE(soc_prd.is_recalc, false) = false))))
     JOIN psn_soc_payment_sum soc_sum ON (((soc_sum.pmnts_period_id = soc_prd.id) AND (soc_sum.is_set = true) AND (soc_sum.summ > (0)::numeric) AND ((( SELECT ref_dict_line.code
           FROM ref_dict_line
          WHERE (ref_dict_line.id = soc_sum.tnch_id)))::text <> ALL ((ARRAY['Н'::character varying, 'О'::character varying])::text[])) AND ((( SELECT ref_dict_line.code
           FROM ref_dict_line
          WHERE (ref_dict_line.id = soc_sum.vnu_id)))::text = ANY ((ARRAY['Б'::character varying, 'И'::character varying, 'Р'::character varying, 'Ч'::character varying, 'П'::character varying])::text[])))));
