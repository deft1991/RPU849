create function execute_next_job() returns text
LANGUAGE plpgsql
AS $$
DECLARE
  R RECORD;
  RES TEXT;
BEGIN
  UPDATE sys_jobs_psql SET start=clock_timestamp() WHERE id =
    (select max(id) from sys_jobs_psql where result is null and start is null)
  RETURNING id, sql INTO R;
  IF R is null THEN RETURN 'EMPTY JOB LIST'; END IF;
  EXECUTE R.sql INTO RES;
  UPDATE sys_jobs_psql SET finish=clock_timestamp(), result=RES WHERE id = R.id;
  RETURN RES;
EXCEPTION WHEN OTHERS THEN
  RES := 'ERROR: '||SQLERRM;
  UPDATE sys_jobs_psql SET finish=null, result=RES WHERE id = R.id;
  RETURN RES;
END
$$;
