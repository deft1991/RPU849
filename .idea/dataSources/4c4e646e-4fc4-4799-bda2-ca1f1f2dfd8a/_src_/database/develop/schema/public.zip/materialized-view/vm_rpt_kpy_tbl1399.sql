CREATE MATERIALIZED VIEW vm_rpt_kpy_tbl1399 AS SELECT kpy.id AS kpy_id,
    kpy.obr_date,
    kpy.close_date,
    kpy.szn_dep_id AS szn_id,
    szn.rgn_id,
    ord_17.id AS ord17_id,
    ord_17.order_date AS ord17_order_date,
    ord_17.start_date AS ord17_start_date,
    COALESCE(ord_8.start_date, ord_17.end_date, to_date('01.01.4000'::text, 'DD.MM.YYYY'::text)) AS coalesce_date,
    date_part('day'::text, ((talon.tdate)::timestamp without time zone - (ord_17.start_date)::timestamp without time zone)) AS duration
   FROM ((((psn_kpy kpy
     JOIN ref_szn szn ON ((kpy.szn_dep_id = szn.id)))
     JOIN psn_order ord_17 ON (((ord_17.kpy_id = kpy.id) AND (ord_17.prkz_id IN ( SELECT prkz_17.id
           FROM ref_dict_line prkz_17
          WHERE ((prkz_17.code)::text = ANY ((ARRAY['1'::character varying, '7'::character varying])::text[])))) AND ((ord_17.status_id IS NULL) OR (ord_17.status_id IN ( SELECT stp.id
           FROM ref_dict_line stp
          WHERE ((stp.code)::text = '1'::text)))))))
     LEFT JOIN sys_talon talon ON ((((talon.sys_id)::text = (ord_17.sys_id)::text) AND (ord_17.start_date <= talon.tdate))))
     LEFT JOIN psn_order ord_8 ON (((ord_8.kpy_id = kpy.id) AND (ord_8.prkz_id IN ( SELECT prkz_8.id
           FROM ref_dict_line prkz_8
          WHERE ((prkz_8.code)::text = '8'::text))) AND ((ord_8.status_id IS NULL) OR (ord_8.status_id IN ( SELECT stp.id
           FROM ref_dict_line stp
          WHERE ((stp.code)::text = '1'::text)))))));
