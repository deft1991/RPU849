CREATE MATERIALIZED VIEW rpt_kpy_tbl1147 AS SELECT k.id,
    k.version,
    k.doc_date,
    k.num,
    k.obr_date,
    k.pz_close_date,
    k.szn_rec_id,
    k.close_rsn_id,
    k.pers_id,
    k.pz_close_rsn_id,
    k.szn_dep_id,
    k.close_date,
    k.sys_id,
    k.career_id,
    k.info_id,
    k.pob_id,
    k.id AS kpy_id,
    concat(p.last_name, ' ', p.first_name, ' ', p.middle_name) AS fio,
    szn.name AS szn,
    rgn.name AS rgn,
    prk.order_date,
    prk8.start_date AS cancel_date,
    p_prd.end_date AS finish_date,
    (p_prd.end_date - prk8.start_date) AS count_day,
    rgn.id AS rgn_id,
    NULL::numeric(17,2) AS overpay_sum
   FROM ((((((((((((psn_kpy k
     JOIN ref_szn szn ON ((szn.id = k.szn_dep_id)))
     JOIN ref_rgn rgn ON ((rgn.id = szn.rgn_id)))
     JOIN psn_person p ON ((p.id = k.pers_id)))
     JOIN psn_order prk ON ((prk.kpy_id = k.id)))
     JOIN ref_dict_line prkz ON (((prkz.id = prk.prkz_id) AND ((prkz.code)::text = ANY (ARRAY[('1'::character varying)::text, ('7'::character varying)::text])))))
     JOIN psn_order prk8 ON ((prk8.kpy_id = k.id)))
     JOIN ref_dict_line prkz8 ON (((prkz8.id = prk8.prkz_id) AND ((prkz8.code)::text = '8'::text))))
     JOIN psn_soc_payment_card soc_card ON ((soc_card.order_id = prk.id)))
     JOIN psn_soc_payment_period p_prd ON (((p_prd.soc_pmnts_card_id = soc_card.id) AND (p_prd.is_recalc = false))))
     JOIN psn_soc_payment_sum ahs ON (((ahs.pmnts_period_id = p_prd.id) AND (ahs.summ > (0)::numeric))))
     JOIN ref_dict_line tn4 ON (((tn4.id = ahs.tnch_id) AND ((tn4.code)::text = ANY (ARRAY[('+'::character varying)::text, ('П'::character varying)::text, ('Б'::character varying)::text, ('С'::character varying)::text])))))
     JOIN ref_dict_line vnu ON (((vnu.id = ahs.vnu_id) AND ((vnu.code)::text = ANY (ARRAY[('Б'::character varying)::text, ('И'::character varying)::text, ('Р'::character varying)::text])))))
  WHERE ((p_prd.end_date < prk8.start_date) AND (NOT (EXISTS ( SELECT NULL::unknown AS unknown
           FROM (psn_soc_payment_card soc_card1
             JOIN psn_soc_payment_period p_prd1 ON (((p_prd1.soc_pmnts_card_id = soc_card1.id) AND (soc_card1.order_id = prk.id) AND (p_prd1.end_date > p_prd.end_date))))))));
