create function fn_dw_report_1460(p_rgn_id bigint, p_szn_id bigint) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
			BEGIN
			DELETE FROM dw_rep1460
			WHERE 1 = 1
			AND szn_id = coalesce(p_szn_id, szn_id)
			AND rgn_id = coalesce(p_rgn_id, rgn_id)
			;
			--
			INSERT INTO dw_rep1460(
			szn_id -- СЗН
			, rgn_id -- Регион
			, kpy_num -- КПУ
			, fio -- ФИО
			, obr_date -- Дата обращения
			, birth_date -- Дата рождения
			, order_date -- Дата приказа
			, tpr_id -- Категория испытывающего трудности в поисках работы
			, kng_id -- Категория незанятости
			, report_year -- Отчетный период
			, report_month -- Отчетный месяц
			, cnt -- Мера
			)
			SELECT DISTINCT
			coalesce(szn.id, 0) AS szn_id -- СЗН
			, coalesce(rgn.id, 0) AS rgn_id -- Регион
			, coalesce(kpy.num, '') as kpy_num -- КПУ
			, coalesce(pers.last_name || ' ' || pers.first_name || ' ' || pers.middle_name, '') as fio -- ФИО
			, kpy.obr_date AS obr_date -- Дата обращения
			, pers.birth_date AS birth_date -- Дата рождения
			, ord.order_date AS order_date -- Дата приказа
			, coalesce(jsp.tpr_id, 0) AS tpr_id -- Категория испытывающего трудности в поисках работы
			, coalesce(kpy_kng.kng_id, 0) AS kng_id -- Категория незанятости
			, to_char(ord.order_date, 'YYYY')::int4 AS report_year -- Отчетный период
			, to_char(ord.order_date, 'MM')::int4 AS report_month -- Отчетный период
			, 1 AS cnt -- Мера
			FROM psn_kpy kpy
			INNER JOIN psn_person pers ON pers.id = kpy.pers_id
			INNER JOIN ref_szn szn ON szn.id = kpy.szn_dep_id
			INNER JOIN ref_rgn rgn ON rgn.id = szn.rgn_id
			INNER JOIN psn_order ord ON ord.kpy_id = kpy.id
			AND EXISTS (SELECT null FROM ref_dict_line prkz WHERE prkz.code IN ('1', '7') AND prkz.id = ord.prkz_id)
			AND EXISTS (SELECT null FROM ref_dict_line alg WHERE alg.code = 'П1' AND alg.id = ord.algo_id)
			LEFT JOIN psn_kng kpy_kng ON kpy_kng.kpy_id = kpy.id
			AND EXISTS (SELECT null FROM ref_dict_line kng WHERE kng.code = '03' AND kng.id = kpy_kng.kng_id)
			LEFT JOIN psn_doc_offered doc ON doc.kpy_id = kpy.id
			AND EXISTS (SELECT null FROM ref_dict_line dok WHERE dok.code = 'ПНЗ' AND dok.id = doc.doc_id)
			LEFT JOIN psn_job_search_problem jsp ON jsp.kpy_id = kpy.id
			WHERE 1 = 1
			AND szn.id = coalesce(p_szn_id, szn.id)
			AND rgn.id = coalesce(p_rgn_id, rgn.id)
			AND pers.unempl_date IS NOT NULL
			AND kpy_kng.id IS NULL
			AND EXISTS (
			SELECT null
			FROM dual
			WHERE doc.id IS NULL
			UNION ALL
			SELECT null
			FROM dual
			WHERE doc.szn_date > pers.unempl_date
			)
			AND ord.order_date >= to_date('01.01.2014','DD.MM.YYYY')
			;
			return true;
			--
			END;
$$;
