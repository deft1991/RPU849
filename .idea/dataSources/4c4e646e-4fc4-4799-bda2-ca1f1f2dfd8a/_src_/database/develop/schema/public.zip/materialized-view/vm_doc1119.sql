CREATE MATERIALIZED VIEW vm_doc1119 AS SELECT kpy.id AS kpy_id,
    szn.name AS szn_name,
    kpy.num,
    kpy.obr_date,
    kpy.close_date,
    szn.rgn_id
   FROM (psn_kpy kpy
     JOIN ref_szn szn ON ((szn.id = kpy.szn_dep_id)));
CREATE INDEX vm_doc1119_rgn_index
  ON vm_doc1119 (rgn_id);
