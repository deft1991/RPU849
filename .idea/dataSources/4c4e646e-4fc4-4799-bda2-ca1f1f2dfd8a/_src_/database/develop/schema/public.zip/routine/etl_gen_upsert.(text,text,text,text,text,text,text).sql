create function etl_gen_upsert(in_user text, pswd text, source_db text, host text, source_schema text, dest_schema text, dest_table text) returns text
LANGUAGE plpgsql
AS $$
DECLARE
  dblink_con text := 'host=' || host || ' dbname=' || source_db || '  user=' || in_user || '  password=' || pswd;
  dblink_view text := source_schema || '.vm_' || dest_table;
  dblink_columns text := '';
  target_columns text := '';
  exclude_rule text := '';
  result_columns text := '';
  rec_columns text := '';
  key_columns text := '';
  -- with conflict by 2 foreign ids
  without_id boolean := dest_table in ('lgl_visit_rpu','psn_wish_prof','psn_visit_service','lgl_service',
    'psn_wish_scg','psn_onv','psn_wish_tzn','psn_job_search_problem','lgl_vacancy_contract','lgl_vacancy_scg',
    'lgl_vacancy_riv','psn_kng','psn_wish_schedule','lgl_release_info_plan','lgl_vacancy_onv');
  -- with join ref_prof
  join_prof boolean := dest_table in ('lgl_contract_subject','lgl_vacancy','lgl_release_info',
    'psn_education','psn_job','psn_study','psn_send_job','psn_send_study','psn_prev_work');
  -- default: insert on conflict(id)
  -- psn_person,lgl_organization,lgl_card,lgl_contragent,psn_kpy,psn_family,lgl_visit,psn_order,
  -- psn_doc_proof,psn_soc_payment_period,psn_soc_payment_card,psn_sum_pens,psn_visit_ogu,
  -- psn_doc_confirm,psn_doc_offered,psn_set_pens,lgl_vacancy_history,psn_ipra,psn_service_167,
  -- lgl_plan_expense,psn_service_summary,psn_visit,psn_calc_additional,psn_restrict,psn_wish,
  -- psn_service_10,lgl_vacancy_quota,psn_soc_payment_sum_paid,psn_service_3589,
  -- lgl_contract,psn_kpy_info,psn_career,psn_soc_payment_hold,psn_service_2
  rec record;
BEGIN

  FOR rec IN
      SELECT column_name, data_type, character_maximum_length FROM information_schema.columns
          WHERE table_schema = dest_schema AND table_name = dest_table
  LOOP
    IF not without_id or rec.column_name != 'id' THEN
      dblink_columns :=  dblink_columns || ',vm.' || rec.column_name;
      rec_columns    :=  rec_columns    || ',' || rec.column_name;
      target_columns := target_columns  || ',' || rec.column_name || ' ' || rec.data_type;
    END IF;
    IF (not without_id and rec.column_name != 'id') or (without_id and (rec.column_name = 'sys_id' or substring(rec.column_name,'_..$') != '_id')) THEN
      exclude_rule := exclude_rule || ',' || rec.column_name || '=EXCLUDED.' || rec.column_name;
    END IF;
    IF without_id and rec.column_name != 'sys_id' and substring(rec.column_name,'_..$') = '_id' THEN
      key_columns := key_columns || ',' || rec.column_name;
    END IF;
    result_columns :=  result_columns || ',result.' || rec.column_name;
  END LOOP;

  IF without_id THEN
    RETURN 'insert into ' || dest_table || '(' || trim(leading ',' from rec_columns) || ')'
           || ' select * from dblink(''' || dblink_con || ''', ' || ''' select distinct '
           || trim(leading ',' from replace(dblink_columns,'vm.version','0 as version'))
           || ' from ' || dblink_view || ' vm'') as vm ('|| trim(leading ',' from target_columns) || ')'
           || ' on conflict (' || trim(LEADING ',' FROM key_columns)
           || ') do update set ' || trim(leading ',' from exclude_rule);

  ELSEIF join_prof THEN
    RETURN 'insert into ' || dest_table || '(' || trim(leading ',' from rec_columns) || ') select '
           || replace(trim(leading ',' from result_columns),'result.prof_id','(select coalesce(min(prof.id), 0) from ref_prof prof where prof.okpdtr_id = result.prof_id) prof_id')
           || ' from dblink(''' || dblink_con || ''', ' || ''' select distinct on (id) '
           || trim(leading ',' from replace(replace(dblink_columns,'vm.version','0 as version'),'vm.prof_id','sys_get_numeric_or_null(prof.okpdtr) prof_id')) || ' from '
           || dblink_view || ' vm left join ' || source_schema || '.dbf_prof prof on prof.master_id = vm.prof_id'')'
           || ' as result (' || trim(leading ',' from target_columns)
           || ') on conflict (id) do update set ' || trim(leading ',' from exclude_rule);

  ELSE
    RETURN 'insert into ' || dest_table || '(' || trim(leading ',' from rec_columns) || ')'
          || ' select * from dblink(''' || dblink_con || ''', ' || ''' select distinct on (id)'
          || trim(leading ',' from replace(dblink_columns,'vm.version','0 as version'))
          || ' from ' || dblink_view || ' vm'') as vm ('|| trim(leading ',' from target_columns) || ')'
          || ' where id is not null on conflict (id) do update set ' || trim(leading ',' from exclude_rule);
  END IF;
END
$$;
