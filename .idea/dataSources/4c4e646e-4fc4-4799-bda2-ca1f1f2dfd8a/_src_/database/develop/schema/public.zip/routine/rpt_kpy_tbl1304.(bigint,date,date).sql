create function rpt_kpy_tbl1304(p_rgn_id bigint, p_start_date date, p_finish_date date) returns TABLE(id bigint, version bigint, doc_date date, num character varying, obr_date date, pz_close_date date, szn_rec_id character varying, close_rsn_id bigint, pers_id bigint, pz_close_rsn_id bigint, szn_dep_id bigint, close_date date, sys_id character varying, career_id bigint, info_id bigint, pob_id bigint, fio character varying, szn character varying, rgn character varying, tpr character varying, kzf character varying, rgn_id bigint)
LANGUAGE SQL
AS $$
SELECT kpy.id
						  , kpy.version
						  , kpy.doc_date
						  , kpy.num
						  , kpy.obr_date
						  , kpy.pz_close_date
						  , kpy.szn_rec_id
						  , kpy.close_rsn_id
						  , kpy.pers_id
						  , kpy.pz_close_rsn_id
						  , kpy.szn_dep_id
						  , kpy.close_date
						  , kpy.sys_id
						  , kpy.career_id
						  , kpy.info_id
						  , kpy.pob_id
						  , concat(pers.last_name, ' ', pers.first_name, ' ', pers.middle_name) as fio
						  , szn.name as szn
						  , rgn.name as rgn
						  , (SELECT tpr.name FROM psn_job_search_problem dfj, ref_dict_line tpr WHERE dfj.kpy_id = kpy.id AND tpr.id = dfj.tpr_id limit 1) AS tpr
						  , kzf.name as kzf
						  , rgn.id as rgn_id
						  FROM kpy_tbl1304(p_rgn_id, p_start_date, p_finish_date) kpy
						  JOIN ref_szn szn ON szn.id = kpy.szn_dep_id --AND szn.rgn_id = 34
						  JOIN ref_rgn rgn ON rgn.id = szn.rgn_id
						  JOIN psn_person pers ON pers.id = kpy.pers_id
						  JOIN psn_kpy_info p_info ON p_info.id = kpy.info_id
						  LEFT JOIN ref_dict_line kzf ON kzf.id = p_info.kzf_id
						    WHERE kpy.order_d_o_id IS NULL
						      AND kpy.order_12_o_id IS NULL
						      AND NOT EXISTS(
						        SELECT sec.id FROM kpy_tbl1304(p_rgn_id, p_start_date, p_finish_date) sec
						        WHERE sec.id = kpy.id
						          AND (sec.order_KP_id IS NOT NULL OR sec.order_PP_after_id IS NOT NULL OR sec.order_PP_before_id IS NOT NULL)
						        )
						  ;



$$;
