create function obshiy_period(kpy_id bigint, OUT period integer, OUT period_gt24 boolean) returns record
LANGUAGE plpgsql
AS $$
DECLARE
            pr1 record;
            i integer;
            end_date date;
            start_date date;
            year1 date;
            year2 date;
            feb29_per integer;
            period_viplaty integer;
            BEGIN
            i := 0;

            FOR pr1 IN select prikaz1.start_date as start1, prikaz1.end_date as end1, prikaz.end_date as end2 from
            psn_order prikaz1
            join ref_dict_line prkz on prkz.id = prikaz1.prkz_id and prkz.code ='1'

            join psn_order prikaz on prikaz.kpy_id = obshiy_period.kpy_id
            join ref_dict_line prkz6 on prikaz.prkz_id = prkz6.id and prkz6.code = '6'

            where prikaz1.kpy_id = obshiy_period.kpy_id order by prikaz1.order_date DESC
            LOOP
            i := i + 1;

            if i=1 then start_date := pr1.start1;
            end_date := pr1.end2;
            elsif i=2 then
            start_date := pr1.start1;
            end_date := pr1.end1;
            end if;

            case when i = 1 then
            period_viplaty := pr1.end1 - pr1.start1 + 1;
            when i = 2 then
            period_viplaty := period_viplaty + pr1.end1 - pr1.start1 + 1;
            ELSE period_viplaty := period_viplaty;
            end case;
            END LOOP;

            year1 := end_date;
            year2 := start_date;

            IF date_part('month', year1) > 2 THEN year1 := ('01-01-' || (date_part('year', year1) + 1))::date;
            ELSE year1 := ('01-01-' || date_part('year', year1))::date;
            END IF;

            IF date_part('month', year2) < 2 THEN year2 := ('01-01-' || date_part('year', year2))::date;
            ELSE year2 := ('01-01-' || (date_part('year', year2) + 1))::date;
            END IF;

            feb29_per := (year1 - year2) % 365;

            period := 0;

            if i=1 then period := end_date - start_date + 1;
            elsif i=2 then period := end_date - start_date + 1;
            end if;

            period_gt24 := period_viplaty > (730 + feb29_per) and period <= (1095 + feb29_per);

            RETURN;
            END;
$$;
