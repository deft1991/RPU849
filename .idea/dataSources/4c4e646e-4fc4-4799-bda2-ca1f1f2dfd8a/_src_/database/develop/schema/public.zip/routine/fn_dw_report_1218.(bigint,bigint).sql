create function fn_dw_report_1218(p_rgn_id bigint, p_szn_id bigint) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
			BEGIN
			DELETE FROM dw_rep1218
			WHERE 1 = 1
			AND szn_id = coalesce(p_szn_id, szn_id)
			AND rgn_id = coalesce(p_rgn_id, rgn_id)
			;
			--
			INSERT INTO dw_rep1218(
			szn_id -- СЗН
			, rgn_id -- Регион
			, order_num -- Номер приказа
			, start_date -- Начало
			, finish_date -- Окончание
			, tvs_id -- Тип выплаты
			, rshs_id -- Решение
			, reason -- Причина
			, kpy_num -- КПУ
			, fio -- ФИО
			, amount -- Сумма
			, koef -- Коэффициент
			, order_date -- Дата приказа
			, obr_date -- Дата обращения
			, close_date -- Дата закрытия
			, doc_date -- Дата подачи
			, tpr_id -- Категория испытывающего трудности в поисках работы
			, kng_id -- Категория незанятости
			, report_year -- отчетный период
			, report_month -- Отчетный месяц
			, cnt -- Мера
			)
			SELECT DISTINCT
			coalesce(szn.id, 0) AS szn_id -- СЗН
			, coalesce(rgn.id, 0) AS rgn_id -- Регион
			, coalesce(ord.order_num, '') AS order_num -- Номер приказа
			, ord.start_date AS start_date -- Начало
			, ord.end_date AS finish_date -- Окончание
			, coalesce(ord.tvs_id, 0) AS tvs_id -- Тип выплаты
			, coalesce(rshs.id, 0) AS rshs_id -- Решение
			, coalesce(prs.name, '') AS reason -- Причина
			, coalesce(kpy.num, '') as kpy_num -- КПУ
			, coalesce(pers.last_name || ' ' || pers.first_name || ' ' || pers.middle_name, '') as fio -- ФИО
			, coalesce(ord.summ, 0) AS amount -- Сумма
			, coalesce(ord.region_coeff, 0) AS koef -- Коэффициент
			, ord.order_date AS order_date -- Дата приказа
			, kpy.obr_date AS obr_date -- Дата обращения
			, kpy.close_date AS close_date -- Дата закрытия
			, kpy.doc_date AS doc_date -- Дата подачи
			, coalesce(jsp.tpr_id, 0) AS tpr_id -- Категория испытывающего трудности в поисках работы
			, coalesce(kng.kng_id, 0) AS kng_id -- Категория незанятости
			, to_char(ord.order_date, 'YYYY')::int4 AS report_year -- Отчетный период
			, to_char(ord.order_date, 'MM')::int4 AS report_month -- Отчетный месяц
			, 1 AS cnt -- Мера
			FROM psn_kpy kpy
			INNER JOIN psn_person pers ON pers.id = kpy.pers_id
			INNER JOIN ref_szn szn ON szn.id = kpy.szn_dep_id
			INNER JOIN ref_rgn rgn ON rgn.id = szn.rgn_id
			INNER JOIN psn_order ord ON ord.kpy_id = kpy.id
			AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line stp WHERE dic.id = stp.dict_id AND dic.code = 'СТП' AND stp.code = '1' AND stp.id = coalesce(ord.status_id, stp.id))
			INNER JOIN ref_dict_line rshs ON rshs.id = ord.rshs_id
			LEFT JOIN psn_soc_payment_card card ON card.order_id = ord.id
			LEFT JOIN psn_soc_payment_period soc_prd ON soc_prd.soc_pmnts_card_id = card.id
			LEFT JOIN psn_soc_payment_sum soc_sum ON soc_sum.pmnts_period_id = soc_prd.id AND soc_sum.is_set = true
			LEFT JOIN psn_kng kng ON kng.kpy_id = kpy.id
			LEFT JOIN psn_kpy_info inf ON kpy.info_id = inf.id
			LEFT JOIN ref_dict_line prs ON prs.id = ord.prs_id
			LEFT JOIN psn_job_search_problem jsp ON jsp.kpy_id = kpy.id
			WHERE 1 = 1
			--AND kpy.id IN (1480073634, 13372734, 5387584634, 888492334)
			AND szn.id = coalesce(p_szn_id, szn.id)
			AND rgn.id = coalesce(p_rgn_id, rgn.id)
			AND soc_sum.id IS NULL
			AND rshs.code = 'П'
			AND ord.order_date >= to_date('01.01.2014','DD.MM.YYYY')
			;
			return true;
			--
			END;
$$;
