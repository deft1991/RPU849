create function patch_for_regions_filials(dbconn text, sql_text text) returns void
LANGUAGE plpgsql
AS $$
DECLARE
  r record;
  f record;
BEGIN
  FOR r IN select datname from dblink(coalesce(dbconn,''),
      'SELECT datname FROM pg_database WHERE datistemplate = false and datname like ''region_%''') as (datname text)
  LOOP
    RAISE INFO '% ..', r.datname;
    FOR f IN select * from dblink(coalesce(dbconn,'')||' dbname='||r.datname,
        'SELECT schema_name FROM information_schema.schemata WHERE left(schema_name::text,2)=''f_''') as (schema_name text)
    LOOP
      BEGIN
        RAISE INFO ' % ..', f.schema_name;
        PERFORM dblink(coalesce(dbconn,'')||' dbname='||r.datname, 'DO $_$ BEGIN
          PERFORM set_config(''search_path'', '''||f.schema_name||', public, pg_catalog'', true);
          PERFORM set_config(''default_tablespace'', ''dirty_data_space_'||substr(r.datname, length('region_')+1)||''', true);
          EXECUTE '''||replace(replace(replace(sql_text,'$database$',r.datname),'$schema$',f.schema_name),'''','''''')||''';
        END $_$;');
      EXCEPTION WHEN syntax_error_or_access_rule_violation OR dependent_privilege_descriptors_still_exist THEN
        RAISE WARNING '  ERROR [%] %', SQLSTATE, SQLERRM;
        CONTINUE;
      END;
    END LOOP;
  END LOOP;
  RAISE INFO 'OK';
END;
$$;
