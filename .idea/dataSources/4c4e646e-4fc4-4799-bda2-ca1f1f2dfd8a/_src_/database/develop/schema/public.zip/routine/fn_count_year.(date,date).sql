create function fn_count_year(start_date date, end_date date) returns integer
LANGUAGE plpgsql
AS $$
DECLARE 
BEGIN
  IF start_date IS NULL OR end_date IS NULL THEN return 0; END IF;
  IF to_char(end_date, 'MM')::int8 * 100 + to_char(end_date, 'DD')::int8 
  	>= to_char(start_date, 'MM')::int8 * 100 + to_char(start_date, 'DD')::int8 THEN
    return to_char(end_date, 'YYYY')::int8 - to_char(start_date, 'YYYY')::int8;               
  ELSE
    return to_char(end_date, 'YYYY')::int8 - to_char(start_date, 'YYYY')::int8 - 1;
  END IF;                 
END;
$$;
