create function kpy_tbl1290(p_rgn_id bigint, p_szn_id bigint, p_start_date date, p_finish_date date, p_duration bigint, p_is_without_suspense boolean, p_is_without_charge boolean) returns TABLE(kpy_id bigint, duration bigint, period character varying, job_period character varying, otm_period character varying)
LANGUAGE plpgsql
AS $$
DECLARE
		            r RECORD;
		            BEGIN
		            -- ================================================================
		            -- DDL
		            -- ================================================================
			    if (not exists (SELECT 1 FROM pg_tables WHERE tablename='tmp_report_1290')
				or not exists (SELECT relname FROM pg_class WHERE relname='tmp_report_1290')
				or (SELECT iftableexists('tmp_report_1290') = 'F')
				) then
		            create temporary table tmp_report_1290(
		            id bigserial
		            , marker int8
		            , kpy_id int8
		            , order_id int8
		            , soc_prd_id int8
		            , ord int8
		            , duration int8
		            , parent_id int8
		            , oper_date date
		            , start_date date
		            , end_date date
		            , is_job bool
		            , is_otm bool
		            );
		            else
		            DELETE FROM tmp_report_1290;
		            end if;
		            -- ================================================================
		            -- Фактические выплаты, с датой выплаты до конца отчетного периода
		            -- Берется только первая выплата в каждом расчете
		            -- ================================================================
		            INSERT INTO tmp_report_1290(
		            marker
		            , kpy_id
		            , order_id
		            , soc_prd_id
		            , oper_date
		            )
		            SELECT 1
			    , vm_kpy.kpy_id
			    , vm_kpy.ord_id
			    , vm_soc.period_id
			    , MIN(vm_soc.paid_oper_date) AS oper_date
			    FROM vm_rpt_kpy_tbl1290_kpy vm_kpy
			    INNER JOIN ref_szn szn ON szn.id = vm_kpy.szn_id
			    INNER JOIN vm_rpt_kpy_tbl1290_soc vm_soc ON vm_soc.order_id = vm_kpy.ord_id
			    WHERE 1 = 1
			    AND szn.rgn_id = coalesce(p_rgn_id, szn.rgn_id)
			    AND coalesce(vm_kpy.start_date, vm_soc.paid_oper_date) <= vm_soc.paid_oper_date
			    AND vm_soc.paid_oper_date <= p_finish_date
			    AND (p_is_without_charge is FALSE OR vm_kpy.close_date IS NULL OR vm_soc.sum_oper_date <= vm_kpy.close_date)
			    GROUP BY vm_soc.period_id
			    , vm_kpy.kpy_id
			    , vm_kpy.ord_id
		            --SELECT
		            --1
		            --, kpy.id
		            --, ord.id
		            --, soc_prd.id
		            --, MIN(soc_paid.oper_date) AS oper_date
		            --FROM psn_kpy kpy
		            --INNER JOIN ref_szn szn ON szn.id = kpy.szn_dep_id
		            --INNER JOIN psn_order ord ON ord.kpy_id = kpy.id
		            --INNER JOIN ref_dict_line prkz ON prkz.id = ord.prkz_id
		            --INNER JOIN psn_soc_payment_card soc_card ON soc_card.order_id = ord.id
		            --INNER JOIN psn_soc_payment_period soc_prd ON soc_prd.soc_pmnts_card_id = soc_card.id
		            --INNER JOIN psn_soc_payment_sum soc_sum ON soc_sum.pmnts_period_id = soc_prd.id
		            --INNER JOIN ref_dict_line tn4 ON tn4.id = soc_sum.tnch_id
		            --INNER JOIN ref_dict_line vnu ON vnu.id = soc_sum.vnu_id
		            --INNER JOIN psn_soc_payment_sum_paid soc_paid ON soc_paid.pmnts_period_id = soc_prd.id
		            --WHERE 1 = 1
		            ----AND kpy.szn_dep_id = coalesce(p_szn_id, kpy.szn_dep_id)
		            ----AND kpy.szn_dep_id IS NOT NULL
		            --AND kpy.num in ('Y312226', 'Y316016', 'O284769', 'S325895', 'O305084', '\439433', 'R568905', 'R581723', 'c522269', 'c540227', 'X527034', ']415354', 'e541641', '3070002/1634FRL', '3050004/1634GRD', 'N594345', 'l1153581', 'k667050', '2980001/1634NKL', 'Z374450', 'g396307', 'g404061', '3120003/1634OKT', 'Z373822', 'Z373815', 'Z372276', 'L262128', 'L263135', 'L262865', '3140005/1634NKL', 'e542687', 'A3150824', 'Z370139', 'Z369599', 'A3155067', 'X516502', '[255723', 'g404909')
		            --AND szn.rgn_id = coalesce(p_rgn_id, szn.rgn_id)
		            ----AND kpy.id = 4252781634
		            --AND ord.prkz_id IS NOT NULL
		            --AND prkz.code IN ('1', '7')
		            --AND vnu.code IN ('Б', 'И', 'Р', 'Ч', 'П')
		            --AND tn4.code NOT IN ('Н', 'О')
		            --AND soc_paid.oper_date IS NOT NULL
		            --AND soc_prd.is_recalc != true
		            --AND coalesce(ord.start_date, soc_paid.oper_date) <=  soc_paid.oper_date
		            --AND soc_paid.oper_date <= p_finish_date
		            --AND (p_is_without_charge IS FALSE OR kpy.close_date IS NULL OR soc_sum.oper_date <= kpy.close_date )
		            --GROUP BY
		            --soc_prd.id
		            --, kpy.id
		            --, ord.id
		            ;
		            -- ================================================================
		            -- Периоды выплат с продолжительностью
		            -- ================================================================
		            INSERT INTO tmp_report_1290(
		            marker
		            , kpy_id
		            , order_id
		            , soc_prd_id
		            , ord
		            , oper_date
		            )
		            SELECT
		            2
		            , t.kpy_id
		            , t.order_id
		            , t.soc_prd_id
		            , row_number() OVER (PARTITION BY t.kpy_id, t.order_id ORDER BY t.kpy_id, t.order_id, t.oper_date) AS ORD
		            , t.oper_date
		            FROM
		            tmp_report_1290 t
		            WHERE 1 = 1
		            AND t.marker = 1
		            ;
		            --
		            INSERT INTO tmp_report_1290(
		            marker
		            , kpy_id
		            , order_id
		            , start_date
		            , end_date
		            , duration
		            )
		            SELECT DISTINCT
		            3
		            , t1.kpy_id
		            , t1.order_id
		            , t1.oper_date
		            , t2.oper_date
		            , date_part('day', t2.oper_date::timestamp - t1.oper_date::timestamp)
		            FROM tmp_report_1290 t1
		            INNER JOIN tmp_report_1290 t2 ON t2.marker = t1.marker AND t2.kpy_id = t1.kpy_id AND t2.order_id = t1.order_id AND t2.ord - 1 = t1.ord
		            WHERE 1 = 1
		            AND t1.marker = 2
		            AND date_part('day', t2.oper_date::timestamp - t1.oper_date::timestamp) > p_duration + 1
		            AND t2.oper_date BETWEEN p_start_date AND p_finish_date
		            ORDER BY
		            t1.kpy_id
		            , t2.oper_date
		            ;
		            -- ================================================================
		            -- Общественные работы в отобранных периодах выплат
		            -- ================================================================
		            INSERT INTO tmp_report_1290 (
		            marker
		            , parent_id
		            , kpy_id
		            , start_date
		            , end_date
		            , duration)
		            SELECT DISTINCT
		            4
		            , t.id
		            , job.kpy_id
		            , job.start_date -- D1
		            , job.end_date  -- D2
		            , date_part('day', job.end_date::timestamp - job.start_date::timestamp)
		            FROM tmp_report_1290 t
		            INNER JOIN psn_job job ON job.kpy_id = t.kpy_id AND job.start_date <= t.end_date AND job.end_date >= t.start_date
		            WHERE 1 = 1
		            AND t.marker = 3
		            AND job.start_date IS NOT NULL
		            AND job.end_date IS NOT NULL
		            ;
		            --
		            INSERT INTO tmp_report_1290 (
		            marker
		            , parent_id
		            , kpy_id
		            , start_date
		            , end_date
		            , duration
		            , ord
		            )
		            SELECT
		            5
		            , t.parent_id
		            , t.kpy_id
		            , t.start_date
		            , t.end_date
		            , t.duration
		            , row_number() OVER (PARTITION BY t.parent_id ORDER BY t.parent_id, t.duration DESC)
		            FROM tmp_report_1290 t
		            WHERE 1 = 1
		            AND t.marker = 4
		            ;
		            --
		            INSERT INTO tmp_report_1290 (
		            marker
		            , parent_id
		            , kpy_id
		            , start_date
		            , end_date
		            , duration
		            )
		            SELECT
		            6
		            , t.parent_id
		            , t.kpy_id
		            , t.start_date
		            , t.end_date
		            , t.duration
		            FROM tmp_report_1290 t
		            WHERE 1 = 1
		            AND t.marker = 5
		            AND t.ord = 1
		            ;
		            --
		            UPDATE tmp_report_1290
		            SET is_job = true
		            WHERE 1 = 1
		            AND marker = 3
		            AND id IN (SELECT t2.parent_id
		            FROM tmp_report_1290 t2
		            WHERE  1 = 1
		            AND t2.marker = 6
		            )
		            ;
		            -- ================================================================
		            -- Приказы приостановить и не производиь в отобранных периодах выплат
		            -- ================================================================
		            INSERT INTO tmp_report_1290 (
		            marker
		            , parent_id
		            , kpy_id
		            , start_date
		            , end_date
		            , duration
		            )
		            SELECT DISTINCT
		            7
		            , t.id
		            , o.kpy_id
		            , o.start_date
		            , o.end_date
		            , date_part('day', o.end_date::timestamp - o.start_date::timestamp)
		            FROM tmp_report_1290 t
		            INNER JOIN psn_order o ON o.kpy_id = t.kpy_id AND o.parent_id = t.order_id AND o.start_date <= t.end_date AND o.end_date >= t.start_date
		            INNER JOIN ref_dict_line stp ON stp.id = o.status_id AND stp.code IN ('1', '2')
		            INNER JOIN ref_dict_line prkz ON prkz.id = o.prkz_id AND prkz.code IN ('3', '4')
		            WHERE 1 = 1
		            AND t.marker = 3
		            ;
		            --
		            INSERT INTO tmp_report_1290 (
		            marker
		            , parent_id
		            , kpy_id
		            , start_date
		            , end_date
		            , duration
		            , ord
		            )
		            SELECT
		            8
		            , t.parent_id
		            , t.kpy_id
		            , t.start_date
		            , t.end_date
		            , t.duration
		            , row_number() OVER (PARTITION BY t.parent_id ORDER BY t.parent_id, t.duration DESC)
		            FROM tmp_report_1290 t
		            WHERE 1 = 1
		            AND t.marker = 7
		            ;
		            --
		            INSERT INTO tmp_report_1290 (
		            marker
		            , parent_id
		            , kpy_id
		            , start_date
		            , end_date
		            , duration
		            )
		            SELECT
		            9
		            , t.parent_id
		            , t.kpy_id
		            , t.start_date
		            , t.end_date
		            , t.duration
		            FROM tmp_report_1290 t
		            WHERE 1 = 1
		            AND t.marker = 8
		            AND t.ord = 1
		            ;
		            --
		            UPDATE tmp_report_1290
		            SET is_otm = true
		            WHERE 1 = 1
		            AND marker = 3
		            AND id IN (SELECT t2.parent_id
		            FROM tmp_report_1290 t2
		            WHERE  1 = 1
		            AND t2.marker = 9
		            )
		            ;
		            -- ================================================================
		            -- Итоговый отбор
		            -- ================================================================
		            INSERT INTO tmp_report_1290 (
		            marker
		            , parent_id
		            , kpy_id
		            , start_date
		            , end_date
		            , duration
		            , ord
		            )
		            SELECT
		            10
		            , t.id
		            , t.kpy_id
		            , t.start_date
		            , t.end_date
		            , t.duration
		            , row_number() OVER (PARTITION BY t.kpy_id ORDER BY t.kpy_id, t.duration DESC)
		            FROM tmp_report_1290 t
		            WHERE 1 = 1
		            AND t.marker = 3
		            AND t.is_job IS NULL
		            AND t.is_otm IS NULL
		            ;
		            --
		            INSERT INTO tmp_report_1290 (
		            marker
		            , kpy_id
		            , start_date
		            , end_date
		            , duration
		            )
		            SELECT
		            11
		            , t.kpy_id
		            , t.start_date
		            , t.end_date
		            , t.duration
		            FROM tmp_report_1290 t
		            WHERE 1 = 1
		            AND t.marker = 10
		            AND t.ord = 1
		            ;
		            --
		            INSERT INTO tmp_report_1290 (
		            marker
		            , parent_id
		            , kpy_id
		            , start_date
		            , end_date
		            , duration
		            , ord
		            )
		            SELECT
		            12
		            , t.id
		            , t.kpy_id
		            , t.start_date
		            , t.end_date
		            , t.duration
		            , row_number() OVER (PARTITION BY t.kpy_id ORDER BY t.kpy_id, t.duration DESC)
		            FROM tmp_report_1290 t
		            WHERE 1 = 1
		            AND t.marker = 3
		            AND (t.is_job IS NOT NULL OR (p_is_without_suspense = false AND t.is_otm IS NOT NULL ) )
		            AND NOT EXISTS (SELECT NULL
		            FROM tmp_report_1290 t1
		            WHERE 1 = 1
		            AND t1.marker = 11
		            AND t1.kpy_id = t.kpy_id
		            )
		            ;
		            -- ИТОГ
		            FOR r IN (
		            SELECT
		            t1.kpy_id
		            , t1.duration
		            , to_char(t1.start_date, 'DD.MM.YY') || ' - ' || to_char(t1.end_date, 'DD.MM.YY') period
		            , null AS job_period
		            , null AS otm_period
		            FROM tmp_report_1290 t1
		            WHERE 1 = 1
		            AND t1.marker = 11
		            --
		            UNION ALL
		            --
		            SELECT
		            t2.kpy_id
		            , t2.duration
		            , to_char(t2.start_date, 'DD.MM.YY') || ' - ' || to_char(t2.end_date, 'DD.MM.YY') period
		            , (CASE WHEN t21.start_date IS NOT NULL THEN (to_char(t21.start_date, 'DD.MM.YY') || ' - ' || to_char(t21.end_date, 'DD.MM.YY') ) ELSE NULL END) AS job_period
		            , (CASE WHEN t22.start_date IS NOT NULL THEN (to_char(t22.start_date, 'DD.MM.YY') || ' - ' || to_char(t22.end_date, 'DD.MM.YY') ) ELSE NULL END) AS otm_period
		            FROM tmp_report_1290 t2
		            LEFT JOIN tmp_report_1290 t21 ON t21.marker = 6 AND t21.parent_id = t2.parent_id
		            LEFT JOIN tmp_report_1290 t22 ON t22.marker = 9 AND t22.parent_id = t2.parent_id
		            WHERE 1 = 1
		            AND t2.marker = 12
		            AND t2.ord = 1
		            )
		            LOOP
		            kpy_id := r.kpy_id;
		            duration := r.duration;
		            period := r.period;
		            job_period := r.job_period;
		            otm_period := r.otm_period;
		            RETURN NEXT;
		            END LOOP;
		            END;
$$;
