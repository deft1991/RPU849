create function upsert_from_vm(in_user text, pswd text, source_db text, host text, source_schema text, dest_schema text, dest_table text) returns void
LANGUAGE plpgsql
AS $$
DECLARE
  dblink_con text := 'host=' || host || ' dbname=' || source_db || '  user=' || in_user || '  password=' || pswd;
  dblink_view text := source_schema || '.vm_' || dest_table;
  dblink_columns text := '';
  target_columns text := '';
  exclude_rule text := '';
  result_columns text := '';
  rec_columns text := '';
  key_columns text := '';
  query_sql text := '';
  main_column text := '';
  -- with conflict by 2 foreign ids
  without_id boolean := dest_table in ('lgl_visit_rpu','psn_wish_prof','psn_visit_service','lgl_service',
    'psn_wish_scg','psn_onv','psn_wish_tzn','psn_job_search_problem','lgl_vacancy_contract','lgl_vacancy_scg',
    'lgl_vacancy_riv','psn_kng','psn_wish_schedule','lgl_release_info_plan','lgl_vacancy_onv');
  -- with join ref_prof
  join_prof boolean := dest_table in ('lgl_contract_subject','lgl_vacancy','lgl_release_info',
    'psn_education','psn_job','psn_study','psn_send_job','psn_send_study','psn_prev_work','psn_wish_prof');
  -- default: insert on conflict(id)
  -- psn_person,lgl_organization,lgl_card,lgl_contragent,psn_kpy,psn_family,lgl_visit,psn_order,
  -- psn_doc_proof,psn_soc_payment_period,psn_soc_payment_card,psn_sum_pens,psn_visit_ogu,
  -- psn_doc_confirm,psn_doc_offered,psn_set_pens,lgl_vacancy_history,psn_ipra,psn_service_167,
  -- lgl_plan_expense,psn_service_summary,psn_visit,psn_calc_additional,psn_restrict,psn_wish,
  -- psn_service_10,lgl_vacancy_quota,psn_soc_payment_sum_paid,psn_service_3589,
  -- lgl_contract,psn_kpy_info,psn_career,psn_soc_payment_hold,psn_service_2
  rec record;
BEGIN

  FOR rec IN
      SELECT column_name, data_type, character_maximum_length FROM information_schema.columns
          WHERE table_schema = dest_schema AND table_name = dest_table
  LOOP
    IF (not without_id and rec.column_name != 'id') or (without_id and (rec.column_name = 'sys_id' or substring(rec.column_name,'_..$') != '_id')) THEN
      exclude_rule := exclude_rule || ',' || rec.column_name || '=EXCLUDED.' || rec.column_name;
    END IF;
    IF without_id and rec.column_name != 'sys_id' and substring(rec.column_name,'_..$') = '_id' THEN
      key_columns := key_columns || ',' || rec.column_name;
    END IF;
    IF rec.column_name != 'version' THEN
      IF not without_id or rec.column_name != 'id' THEN
        result_columns :=  result_columns || ',result.' || rec.column_name;
        dblink_columns :=  dblink_columns || ',vm.' || rec.column_name;
        rec_columns    :=  rec_columns    || ',' || rec.column_name;
        target_columns := target_columns  || ',' || rec.column_name || ' ' || rec.data_type;
      END IF;
    END IF;
  END LOOP;
  dblink_columns = trim(leading ',' from dblink_columns);
  target_columns = trim(leading ',' from target_columns);
  key_columns = trim(leading ',' FROM key_columns);
  exclude_rule = trim(leading ',' from exclude_rule);

  IF join_prof THEN
    dblink_columns = replace(dblink_columns,'vm.prof_id','(select id from '||source_schema||'.ref_prof_ids prof where prof.master_id = vm.prof_id limit 1) prof_id');
  END IF;

  IF without_id THEN

    result_columns = trim(leading ',' FROM result_columns);
    rec_columns = trim(leading ',' from rec_columns);

    execute 'drop table if exists tmp_' || dest_table;
    execute 'create temporary table tmp_' || dest_table || ' as select ' || result_columns
            || ' from dblink(''' || dblink_con || ''', ''select ' || dblink_columns || ' from ' || dblink_view || ' vm'')'
            || ' as result (' || target_columns || ')';
    main_column = case dest_table
      when 'lgl_visit_rpu' then 'org_visit_id'
      when 'psn_wish_prof' then 'p_wish_id'
      when 'psn_visit_service' then 'visit_id'
      when 'lgl_service' then 'o_visit_id'
      when 'psn_wish_scg' then 'p_wish_id'
      when 'psn_onv' then 'pers_id'
      when 'psn_wish_tzn' then 'p_wish_id'
      when 'psn_job_search_problem' then 'kpy_id'
      when 'lgl_vacancy_contract' then 'contract_id'
      when 'lgl_vacancy_scg' then 'vacancy_id'
      when 'lgl_vacancy_riv' then 'vacancy_id'
      when 'psn_kng' then 'kpy_id'
      when 'psn_wish_schedule' then 'p_wish_id'
      when 'lgl_release_info_plan' then 'release_info_id'
      when 'lgl_vacancy_onv' then 'vac_id'
    end;

    execute 'delete from ' || dest_table || ' where ' || main_column || ' in (select distinct ' || main_column || ' from tmp_' || dest_table || ')';
    execute 'insert into ' || dest_table || '(version,' || rec_columns || ') select 0,' || result_columns || ' from tmp_' || dest_table || ' as result';

  ELSE -- not without_id

    key_columns = 'id';
    result_columns = '0'||result_columns;
    rec_columns = 'version'||rec_columns;

    query_sql = 'select distinct on (id) ' || dblink_columns || ' from ' || dblink_view || ' vm';

    execute 'insert into ' || dest_table || '(' || rec_columns || ') select ' || result_columns
            || ' from dblink(''' || dblink_con || ''', ''' || query_sql || ''')'
            || ' as result (' || target_columns || ')'
            || ' on conflict (' || key_columns || ') do update set ' || exclude_rule;
  END IF;
END
$$;
