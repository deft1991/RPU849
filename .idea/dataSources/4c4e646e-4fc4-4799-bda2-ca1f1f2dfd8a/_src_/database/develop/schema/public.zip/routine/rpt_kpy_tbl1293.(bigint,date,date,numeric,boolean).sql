create function rpt_kpy_tbl1293(p_rgn_id bigint, p_start_date date, p_finish_date date, p_count_pay numeric, p_is_without_suspense boolean) returns TABLE(id bigint, version bigint, doc_date date, num character varying, obr_date date, pz_close_date date, szn_rec_id character varying, close_rsn_id bigint, pers_id bigint, pz_close_rsn_id bigint, szn_dep_id bigint, close_date date, sys_id character varying, career_id bigint, info_id bigint, pob_id bigint, kpy_id bigint, duration bigint, fio character varying, szn character varying, rgnid bigint, rgn character varying, period character varying, payments bigint, stopping bigint, publicworks character varying, n_pr bigint, lastreg date, lastpayment date, iswithoutsuspense character varying)
LANGUAGE SQL
AS $$
SELECT
						kpy.id, kpy.version, kpy.doc_date, kpy.num, kpy.obr_date, kpy.pz_close_date, kpy.szn_rec_id, 
						kpy.close_rsn_id, kpy.pers_id, kpy.pz_close_rsn_id, kpy.szn_dep_id, kpy.close_date, 
						kpy.sys_id, kpy.career_id, kpy.info_id, kpy.pob_id,
						t.kpy_id,
						t.duration,
						concat(pers.last_name, ' ', pers.first_name, ' ', pers.middle_name) AS fio,
						szn.name AS szn,
						rgn.id AS rgnid,
						rgn.name AS rgn,
						t.period AS period,
						t.p_count_pay AS payments,
						t.duration AS stopping,
						t.job_period AS publicWorks,
						t.n_pr,
						t.last_date_reg AS lastReg,
						t.last_date_sum AS lastPayment,
						t.p_is_without_suspense AS isWithoutSuspense
						from kpy_tbl1293(
							p_rgn_id,
							null,
							p_start_date,
							p_finish_date
						) t
						LEFT JOIN psn_kpy kpy on kpy.id = t.kpy_id
						LEFT JOIN psn_person pers ON kpy.pers_id = pers.id
						LEFT JOIN ref_szn szn ON szn.id = kpy.szn_dep_id
						LEFT JOIN ref_rgn rgn ON rgn.id = szn.rgn_id
						LEFT JOIN psn_kpy_info p_info ON kpy.info_id = p_info.id
						LEFT JOIN ref_dict_line kzf ON p_info.kzf_id = kzf.id
						LEFT JOIN psn_job_search_problem dfj ON dfj.kpy_id = kpy.id
						LEFT JOIN ref_dict_line tpr ON tpr.id = dfj.tpr_id
						WHERE 
					kpy.obr_date >= p_start_date
					AND kpy.obr_date <= p_finish_date
					AND p_count_pay = p_count_pay 
					AND p_is_without_suspense = p_is_without_suspense


$$;
