CREATE MATERIALIZED VIEW rpt_kpy_tbl1120 AS SELECT DISTINCT kpy.id,
    kpy.version,
    kpy.close_date,
    kpy.doc_date,
    kpy.num,
    kpy.obr_date,
    kpy.pz_close_date,
    kpy.szn_rec_id,
    kpy.close_rsn_id,
    kpy.pers_id,
    kpy.pz_close_rsn_id,
    kpy.szn_dep_id,
    szn.rgn_id,
    concat(pers.last_name, ' ', pers.first_name, ' ', pers.middle_name) AS fio,
    pers.pol_id,
    kzf.name AS kzf_name,
    kzf.id AS kzf_id,
    ((date_part('year'::text, kpy.obr_date) - date_part('year'::text, pers.birth_date)) - (
        CASE
            WHEN (date_part('month'::text, kpy.obr_date) < date_part('month'::text, pers.birth_date)) THEN 1
            WHEN ((date_part('month'::text, kpy.obr_date) = date_part('month'::text, pers.birth_date)) AND (date_part('day'::text, kpy.obr_date) < date_part('day'::text, pers.birth_date))) THEN 1
            ELSE 0
        END)::double precision) AS age,
    rgn.name AS rgn_name,
    ( SELECT tpr.name
           FROM psn_job_search_problem dfj,
            ref_dict_line tpr
          WHERE ((dfj.kpy_id = kpy.id) AND (tpr.id = dfj.tpr_id))
         LIMIT 1) AS tpr,
    ( SELECT dict_kng.id
           FROM psn_kng tkng,
            ref_dict_line dict_kng
          WHERE ((tkng.kpy_id = kpy.id) AND (dict_kng.id = tkng.kng_id))
         LIMIT 1) AS kng_id,
    ( SELECT dict_kng.name
           FROM psn_kng tkng,
            ref_dict_line dict_kng
          WHERE ((tkng.kpy_id = kpy.id) AND (dict_kng.id = tkng.kng_id))
         LIMIT 1) AS kng_name,
    szn.name AS szn_name,
    ( SELECT tpr.id
           FROM psn_job_search_problem dfj,
            ref_dict_line tpr
          WHERE ((dfj.kpy_id = kpy.id) AND (tpr.id = dfj.tpr_id))
         LIMIT 1) AS tpr_id,
    ( SELECT tpr.name
           FROM psn_job_search_problem dfj,
            ref_dict_line tpr
          WHERE ((dfj.kpy_id = kpy.id) AND (tpr.id = dfj.tpr_id))
         LIMIT 1) AS tpr_name,
    puv.id AS puv_id,
    p_info.uro_id,
    order12.order_date AS order12date,
    order8.id AS order8_id,
    order8.order_date AS order8date,
    NULL::bigint AS career_id,
    NULL::bigint AS info_id,
    NULL::bigint AS pob_id
   FROM (((((((((((((psn_kpy kpy
     JOIN psn_person pers ON ((kpy.pers_id = pers.id)))
     JOIN psn_kpy_info p_info ON ((kpy.info_id = p_info.id)))
     JOIN ref_dict_line pob ON ((pob.id = kpy.pob_id)))
     JOIN ref_szn szn ON ((szn.id = kpy.szn_dep_id)))
     JOIN ref_rgn rgn ON ((rgn.id = szn.rgn_id)))
     JOIN psn_job j ON ((j.kpy_id = kpy.id)))
     JOIN ref_dict_line vtr ON ((vtr.id = j.vtr_id)))
     LEFT JOIN psn_order order12 ON (((order12.kpy_id = kpy.id) AND (EXISTS ( SELECT prkz12.id
           FROM (ref_dict_line prkz12
             LEFT JOIN ref_dict_line stp ON (((order12.status_id = stp.id) AND ((stp.code)::text = '1'::text))))
          WHERE ((prkz12.id = order12.prkz_id) AND ((prkz12.code)::text = '12'::text)))))))
     LEFT JOIN psn_order order8 ON (((order8.kpy_id = kpy.id) AND (EXISTS ( SELECT prkz8.id
           FROM ref_dict_line prkz8
          WHERE ((prkz8.id = order8.prkz_id) AND ((prkz8.code)::text = '8'::text)))))))
     LEFT JOIN ref_dict_line kzf ON ((p_info.kzf_id = kzf.id)))
     LEFT JOIN psn_prev_work p_prev_work ON ((p_prev_work.kpy_id = kpy.id)))
     LEFT JOIN ref_dict_line puv ON ((puv.id = p_prev_work.puv_id)))
     LEFT JOIN psn_education p_edu ON ((p_edu.pers_id = pers.id)))
  WHERE (((pob.code)::text = ANY (ARRAY[('1'::character varying)::text, ('2'::character varying)::text, ('3'::character varying)::text, ('4'::character varying)::text])) AND ((vtr.code)::text = '3'::text));
