create function fn_get_next_obr(kpy_id bigint) returns bigint
LANGUAGE plpgsql
AS $$
DECLARE
            cnt bigint;
            BEGIN
            select k1.id
            , count (*) as next_obr_count
            into cnt
            from psn_kpy k1
            inner join psn_person pk1 on k1.pers_id = pk1.id
            inner join psn_person pk2 on pk1.snils = pk2.snils and pk1.id != pk2.id
            inner join psn_kpy k2 on k2.pers_id = pk2.id
            and k2.obr_date > k1.obr_date
            where k1.id = kpy_id
            group by 1;

            RETURN cnt;
            END;
$$;
