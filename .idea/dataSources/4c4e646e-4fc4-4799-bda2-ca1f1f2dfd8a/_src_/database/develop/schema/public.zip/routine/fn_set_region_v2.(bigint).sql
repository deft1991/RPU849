create function fn_set_region_v2(p_rgn_id bigint) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
 r RECORD;
BEGIN
 DELETE FROM rpt_remote_control_detail WHERE rgn_id = p_rgn_id and report_name != '1270';
 FOR r IN (SELECT id FROM ref_szn szn WHERE rgn_id = p_rgn_id) LOOP
    PERFORM tsk_set_remote_control_detail_v2(p_rgn_id, r.id);
 END LOOP;
 RETURN TRUE;
END;
$$;
