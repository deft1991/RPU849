CREATE MATERIALIZED VIEW rpt_kpy_tbl811 AS SELECT kpy.id,
    kpy.version,
    kpy.id AS kpy_id,
    kpy.close_date,
    kpy.doc_date,
    kpy.num,
    kpy.obr_date,
    kpy.pz_close_date,
    kpy.szn_rec_id,
    kpy.close_rsn_id,
    kpy.pers_id,
    kpy.pz_close_rsn_id,
    kpy.szn_dep_id,
    concat(pers.last_name, ' ', pers.first_name, ' ', pers.middle_name) AS fio,
    szn.name AS szn,
    rgn.name AS rgn,
    rgn.id AS rgn_id,
    prikaz.order_date,
    pmnts_period.oper_date,
    pmnts_period.start_date,
    pmnts_period.end_date,
    (pmnts_period.end_date - pmnts_period.start_date) AS date_diff,
    NULL::bigint AS career_id,
    NULL::bigint AS info_id,
    NULL::bigint AS pob_id
   FROM (((((((((psn_kpy kpy
     JOIN psn_order prikaz ON ((prikaz.kpy_id = kpy.id)))
     JOIN ref_dict_line prkz ON (((prkz.id = prikaz.prkz_id) AND ((prkz.code)::text = '8'::text))))
     JOIN ref_dict_line prs ON (((prs.id = prikaz.prs_id) AND ((prs.code)::text <> 'КС'::text))))
     JOIN ref_dict_line scv ON (((scv.id = prikaz.scv_id) AND ((scv.code)::text = '01'::text))))
     JOIN psn_soc_payment_card pspc ON ((pspc.order_id = prikaz.id)))
     JOIN psn_soc_payment_period pmnts_period ON ((pmnts_period.soc_pmnts_card_id = pspc.id)))
     JOIN psn_person pers ON ((pers.id = kpy.pers_id)))
     JOIN ref_szn szn ON ((kpy.szn_dep_id = szn.id)))
     JOIN ref_rgn rgn ON ((szn.rgn_id = rgn.id)))
  WHERE (((prikaz.order_date IS NULL) OR (prikaz.order_date > pmnts_period.oper_date)) AND ((pmnts_period.is_recalc IS NULL) OR (pmnts_period.is_recalc = false)) AND (NOT (EXISTS ( SELECT prikazo.id
           FROM (psn_order prikazo
             JOIN ref_dict_line rshso ON (((prikazo.rshs_id = rshso.id) AND ((rshso.code)::text = 'О'::text))))
          WHERE (prikazo.parent_id = prikaz.id)))));
