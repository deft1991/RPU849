CREATE VIEW rpt_kpy_tbl355 AS SELECT DISTINCT kpy.id,
    kpy.version,
    kpy.close_date,
    kpy.doc_date,
    kpy.num,
    kpy.obr_date,
    kpy.pz_close_date,
    kpy.szn_rec_id,
    kpy.close_rsn_id,
    kpy.pers_id,
    kpy.pz_close_rsn_id,
    kpy.szn_dep_id,
    prikaz2.order_date AS order12_date,
    prikaz.order_date,
    (((((pers.last_name)::text || ' '::text) || (pers.first_name)::text) || ' '::text) || (pers.middle_name)::text) AS fio,
    rgn.name AS rgn_name,
    ( SELECT kng.name
           FROM psn_kng tkng,
            ref_dict_line kng
          WHERE ((tkng.kpy_id = kpy.id) AND (kng.id = tkng.kng_id))
         LIMIT 1) AS kng_name,
    ( SELECT kng.id
           FROM psn_kng tkng,
            ref_dict_line kng
          WHERE ((tkng.kpy_id = kpy.id) AND (kng.id = tkng.kng_id))
         LIMIT 1) AS kng_id,
    szn.name AS szn_name,
    rgn.id AS rgn_id,
    ( SELECT tpr.name
           FROM psn_job_search_problem dfj,
            ref_dict_line tpr
          WHERE ((dfj.kpy_id = kpy.id) AND (tpr.id = dfj.tpr_id))
         LIMIT 1) AS tpr_name,
    ( SELECT tpr.id
           FROM psn_job_search_problem dfj,
            ref_dict_line tpr
          WHERE ((dfj.kpy_id = kpy.id) AND (tpr.id = dfj.tpr_id))
         LIMIT 1) AS tpr_id,
    (prikaz.order_date - prikaz2.order_date) AS date_diff,
    NULL::bigint AS career_id,
    NULL::bigint AS info_id,
    NULL::bigint AS pob_id
   FROM ((((((((psn_kpy kpy
     JOIN ref_szn szn ON ((szn.id = kpy.szn_dep_id)))
     JOIN ref_rgn rgn ON ((rgn.id = szn.rgn_id)))
     JOIN psn_person pers ON ((pers.id = kpy.pers_id)))
     JOIN psn_kpy_info p_info ON ((p_info.id = kpy.info_id)))
     JOIN psn_order prikaz ON ((prikaz.kpy_id = kpy.id)))
     JOIN ref_dict_line prkz1 ON (((prkz1.id = prikaz.prkz_id) AND ((prkz1.code)::text = '1'::text))))
     JOIN psn_order prikaz2 ON ((prikaz2.kpy_id = kpy.id)))
     JOIN ref_dict_line prkz2 ON (((prkz2.id = prikaz2.prkz_id) AND ((prkz2.code)::text = '12'::text))))
  WHERE ((prikaz.order_date <> prikaz2.order_date) AND (NOT (EXISTS ( SELECT p.id,
            p.version,
            p.cancel_date,
            p.dop_info,
            p.duration,
            p.end_date,
            p.form_date,
            p.is_keep,
            p.is_money_help,
            p.note_date,
            p.order_date,
            p.order_num,
            p.reg_date,
            p.region_coeff,
            p.staj_last_year,
            p.start_date,
            p.summ,
            p.szn_rec_id,
            p.total_staj_days,
            p.total_staj_month,
            p.total_staj_years,
            p.zp,
            p.algo_id,
            p.ifn_id,
            p.kpy_id,
            p.lim_max_id,
            p.lim_min_id,
            p.official_id,
            p.parent_id,
            p.pnp_id,
            p.prkz_id,
            p.opv_id,
            p.prs_id,
            p.rshs_id,
            p.scv_id,
            p.status_id,
            p.tvs_id,
            p.sys_id
           FROM ((psn_order p
             JOIN ref_dict_line p_prkz ON (((p_prkz.id = prikaz.rshs_id) AND ((p_prkz.code)::text = 'О'::text))))
             JOIN ref_dict_line p_prkz2 ON (((p_prkz2.id = prikaz2.rshs_id) AND ((p_prkz2.code)::text = 'О'::text))))
          WHERE ((p.parent_id = prikaz.id) OR (p.parent_id = prikaz2.id))))));
