create function refresh_mdn(p_report_name text, p_rgn text, p_szn text) returns void
LANGUAGE plpgsql
AS $$
DECLARE
 r RECORD;
 p_rgn_id bigint := p_rgn::bigint;
 p_szn_id bigint := (select id from ref_szn where code=p_szn and rgn_id=p_rgn_id limit 1);
 p_date_column text := case p_report_name
    when '811' then 'oper_date'
    when '1270' then 'oper_date'
    when '1086' then 'oper_date'
    when '1085' then 'oper_date'
    when '1147' then 'order_date'
    when '1146' then 'order_date'
    when '1139' then 'order_date'
    when '1456' then 'order_date'
    when '1318' then 'order_date'
    when '1306' then 'send_date'
    when '1457' then 'unempl_date'
 end;
BEGIN
 DELETE FROM rpt_remote_control_detail WHERE rgn_id = p_rgn_id and report_name = p_report_name and (p_szn_id is null or szn_id = p_szn_id);
 FOR r IN (SELECT id FROM ref_szn szn WHERE rgn_id = p_rgn_id and (p_szn_id is null or id = p_szn_id)) LOOP
   EXECUTE 'INSERT INTO rpt_remote_control_detail (version, kpy_id, obr_date, report_name, rgn_id, szn_id)'
     ||'SELECT f.version, f.kpy_id, f.'||p_date_column||', '''||p_report_name||''', '||cast(p_rgn_id as text)||', '||cast(r.id as text)
     ||' FROM fn_report_'||p_report_name||'('||cast(p_rgn_id as text)||','||cast(r.id as text)||',NULL,NULL,NULL) f';
 END LOOP;
END;
$$;
