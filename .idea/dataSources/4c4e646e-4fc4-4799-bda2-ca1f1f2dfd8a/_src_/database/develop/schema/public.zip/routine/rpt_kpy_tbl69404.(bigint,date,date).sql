create function rpt_kpy_tbl69404(p_rgn_id bigint, p_start_date date, p_finish_date date) returns TABLE(id bigint, version bigint, close_date date, doc_date date, num character varying, obr_date date, pz_close_date date, szn_rec_id character varying, close_rsn_id bigint, pers_id bigint, pz_close_rsn_id bigint, szn_dep_id bigint, order_date date, career_id bigint, info_id bigint, pob_id bigint)
LANGUAGE SQL
AS $$
SELECT DISTINCT prikaz.id,
		    kpy.version,
		    kpy.close_date,
		    kpy.doc_date,
		    kpy.num,
		    kpy.obr_date,
		    kpy.pz_close_date,
		    kpy.szn_rec_id,
		    kpy.close_rsn_id,
		    kpy.pers_id,
		    kpy.pz_close_rsn_id,
		    kpy.szn_dep_id,
		    prikaz.order_date,
		    NULL::bigint AS career_id,
		    NULL::bigint AS info_id,
		    NULL::bigint AS pob_id
		   FROM psn_kpy kpy
		     JOIN ref_szn szn ON szn.id = kpy.szn_dep_id AND szn.rgn_id = coalesce(p_rgn_id, szn.rgn_id)
		     JOIN psn_order prikaz ON prikaz.kpy_id = kpy.id AND prikaz.order_date BETWEEN p_start_date AND p_finish_date
		     JOIN ref_dict_line prikaz_prkz ON prikaz_prkz.id = prikaz.prkz_id AND (prikaz_prkz.code::text = ANY (ARRAY['1'::character varying::text, '7'::character varying::text, '9'::character varying::text, '21'::character varying::text, '25'::character varying::text]))
		     LEFT JOIN ref_dict_line rshs ON prikaz.rshs_id = rshs.id AND rshs.code::text <> 'O'::text
		     LEFT JOIN psn_order prikaz_parent ON prikaz_parent.parent_id = prikaz.id
		     LEFT JOIN ref_dict_line prikaz_rshs ON prikaz_parent.rshs_id = prikaz_rshs.id AND prikaz_rshs.code::text = 'O'::text
		  WHERE prikaz_prkz.id IS NOT NULL AND (rshs.id IS NOT NULL OR prikaz.rshs_id IS NULL) AND prikaz_rshs.id IS NULL AND prikaz.summ <= 0::numeric;


$$;
