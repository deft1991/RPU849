CREATE VIEW rpt_kpy_tbl683 AS SELECT DISTINCT kpy.id,
    kpy.version,
    kpy.doc_date,
    kpy.num,
    kpy.obr_date,
    kpy.pz_close_date,
    kpy.szn_rec_id,
    kpy.close_rsn_id,
    kpy.pers_id,
    kpy.pz_close_rsn_id,
    kpy.szn_dep_id,
    kpy.close_date,
    kpy.sys_id,
    kpy.career_id,
    kpy.info_id,
    kpy.pob_id,
    concat(pers.last_name, ' ', pers.first_name, ' ', pers.middle_name) AS fio,
    szn.name AS szn,
    rgn.name AS rgn,
    ( SELECT tpr.name
           FROM psn_job_search_problem dfj,
            ref_dict_line tpr
          WHERE ((dfj.kpy_id = kpy.id) AND (tpr.id = dfj.tpr_id))
         LIMIT 1) AS tpr,
    kzf.name AS kzf,
    rgn.id AS rgn_id,
    prp.id AS prp_id,
    prikaz.order_date
   FROM ((((((((((((psn_kpy kpy
     JOIN psn_order prikaz ON ((prikaz.kpy_id = kpy.id)))
     JOIN ref_dict_line prkz ON (((prkz.id = prikaz.prkz_id) AND ((prkz.code)::text = '13'::text))))
     JOIN psn_person pers ON ((pers.id = kpy.pers_id)))
     JOIN ref_szn szn ON ((kpy.szn_dep_id = szn.id)))
     JOIN ref_rgn rgn ON ((szn.rgn_id = rgn.id)))
     JOIN psn_kpy_info p_info ON ((p_info.id = kpy.info_id)))
     JOIN ref_dict_line pob ON (((pob.id = kpy.pob_id) AND ((pob.code)::text = ANY ((ARRAY['1'::character varying, '2'::character varying, '3'::character varying, '4'::character varying])::text[])))))
     LEFT JOIN ref_dict_line kzf ON ((kzf.id = p_info.kzf_id)))
     LEFT JOIN psn_job_search_problem fj ON ((kpy.id = fj.kpy_id)))
     LEFT JOIN ref_dict_line prp ON ((prikaz.prp_id = prp.id)))
     JOIN psn_order prikaz13 ON ((prikaz13.kpy_id = kpy.id)))
     JOIN ref_dict_line prkz13 ON (((prkz13.id = prikaz13.prkz_id) AND ((prkz13.code)::text = '13'::text))))
  WHERE (((prikaz.order_date - kpy.doc_date) >= 11) AND (NOT (EXISTS ( SELECT 1
           FROM (psn_order prikazo
             JOIN ref_dict_line rshso ON (((prikazo.rshs_id = rshso.id) AND ((rshso.code)::text = 'О'::text))))
          WHERE (prikazo.parent_id = prikaz13.id)))));
