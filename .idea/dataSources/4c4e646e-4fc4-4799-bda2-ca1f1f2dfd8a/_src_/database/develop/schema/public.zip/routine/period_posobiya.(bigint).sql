create function period_posobiya(kpy_id bigint) returns integer
LANGUAGE plpgsql
AS $$
DECLARE
            i integer;
            pr1 record;
            period_viplaty integer;

            BEGIN
            period_viplaty = 0;
            i := 0;

            FOR pr1 IN select prikaz1.start_date, prikaz.end_date from psn_order prikaz1
            join ref_dict_line prkz on prkz.id = prikaz1.prkz_id and prkz.code ='1'

            join psn_order prikaz on prikaz.kpy_id = period_posobiya.kpy_id
            join ref_dict_line prkz6 on prikaz.prkz_id = prkz6.id and prkz6.code = '6'

            where prikaz1.kpy_id = period_posobiya.kpy_id order by prikaz1.order_date DESC
            loop
            i := i + 1;

            case when i=1 then
            period_viplaty := pr1.end_date - pr1.start_date + 1;
            when i=2 then
            period_viplaty := period_viplaty + pr1.end_date - pr1.start_date + 1;
            ELSE period_viplaty := period_viplaty;
            end case;
            END LOOP;

            RETURN period_viplaty;
            END;
$$;
