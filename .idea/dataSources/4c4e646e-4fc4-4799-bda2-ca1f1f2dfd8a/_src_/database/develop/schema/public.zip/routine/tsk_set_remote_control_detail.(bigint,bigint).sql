create function tsk_set_remote_control_detail(p_rgn_id bigint, p_szn_id bigint) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
  v_time time;
BEGIN
     v_time := clock_timestamp()::time;
	insert into tst_log(report_name, duration, rgn_id, szn_id, date_time) values('start',  null, p_rgn_id, p_szn_id, clock_timestamp()::timestamp);
	DELETE FROM rpt_remote_control_detail 
	WHERE 1 = 1
	  AND rgn_id = p_rgn_id 
	  AND szn_id = p_szn_id
	;
	-- 1270
	insert into tst_log(report_name, duration, rgn_id, szn_id, date_time) values('delete', date_part('second',(clock_timestamp()::time - v_time)), p_rgn_id, p_szn_id, clock_timestamp()::timestamp);
	v_time := clock_timestamp()::time;
	INSERT INTO rpt_remote_control_detail(
	  version
	, kpy_id
	, obr_date
	, report_name
	, rgn_id
	, szn_id
	)
	SELECT
	  f.version
	, f.kpy_id
	, f.oper_date
	, '1270'
	, p_rgn_id
	, p_szn_id  
	FROM fn_report_1270(p_rgn_id, p_szn_id, null, null, null) f;
	insert into tst_log(report_name, duration, rgn_id, szn_id, date_time) values('1270', date_part('second',(clock_timestamp()::time - v_time)), p_rgn_id, p_szn_id, clock_timestamp()::timestamp);
	--  
	-- 811
	v_time := clock_timestamp()::time;
	INSERT INTO rpt_remote_control_detail(
	  version
	, kpy_id
	, obr_date
	, report_name
	, rgn_id
	, szn_id
	)
	SELECT
	  f.version
	, f.kpy_id
	, f.oper_date
	, '811'
	, p_rgn_id
	, p_szn_id  
	FROM fn_report_811(p_rgn_id, p_szn_id, null, null, null) f;
	insert into tst_log(report_name, duration, rgn_id, szn_id, date_time) values('811', date_part('second',(clock_timestamp()::time - v_time)), p_rgn_id, p_szn_id, clock_timestamp()::timestamp);
	--
	-- 1146
	v_time := clock_timestamp()::time;	
	INSERT INTO rpt_remote_control_detail(
	  version
	, kpy_id
	, obr_date
	, report_name
	, rgn_id
	, szn_id
	)
	SELECT
	  f.version
	, f.kpy_id
	, f.order_date
	, '1146'
	, p_rgn_id
	, p_szn_id  
	FROM fn_report_1146(p_rgn_id, p_szn_id, null, null, null) f;
	insert into tst_log(report_name, duration, rgn_id, szn_id, date_time) values('1146', date_part('second',(clock_timestamp()::time - v_time)), p_rgn_id, p_szn_id, clock_timestamp()::timestamp);
	-- 
	-- 1147
	v_time := clock_timestamp()::time;
	INSERT INTO rpt_remote_control_detail(
	  version
	, kpy_id
	, obr_date
	, report_name
	, rgn_id
	, szn_id
	)
	SELECT
	  f.version
	, f.kpy_id
	, f.order_date
	, '1147'
	, p_rgn_id
	, p_szn_id  
	FROM fn_report_1147(p_rgn_id, p_szn_id, null, null, null) f;
	insert into tst_log(report_name, duration, rgn_id, szn_id, date_time) values('1147', date_part('second',(clock_timestamp()::time - v_time)), p_rgn_id, p_szn_id, clock_timestamp()::timestamp);
	--
	-- 1085
	v_time := clock_timestamp()::time;
	INSERT INTO rpt_remote_control_detail(
	  version
	, kpy_id
	, obr_date
	, report_name
	, rgn_id
	, szn_id
	)
	SELECT
	  f.version
	, f.kpy_id
	, f.oper_date
	, '1085'
	, p_rgn_id
	, p_szn_id  
	FROM fn_report_1085(p_rgn_id, p_szn_id, null, null, null) f;
	insert into tst_log(report_name, duration, rgn_id, szn_id, date_time) values('1085', date_part('second',(clock_timestamp()::time - v_time)), p_rgn_id, p_szn_id, clock_timestamp()::timestamp);
	-- 	
	-- 1086
	v_time := clock_timestamp()::time;
	INSERT INTO rpt_remote_control_detail(
	  version
	, kpy_id
	, obr_date
	, report_name
	, rgn_id
	, szn_id
	)
	SELECT
	  f.version
	, f.kpy_id
	, f.oper_date
	, '1086'
	, p_rgn_id
	, p_szn_id  
	FROM fn_report_1086(p_rgn_id, p_szn_id, null, null, null) f;
	insert into tst_log(report_name, duration, rgn_id, szn_id, date_time) values('1086', date_part('second',(clock_timestamp()::time - v_time)), p_rgn_id, p_szn_id, clock_timestamp()::timestamp);
	-- 	
	-- 1456
	v_time := clock_timestamp()::time;
	INSERT INTO rpt_remote_control_detail(
	  version
	, kpy_id
	, obr_date
	, report_name
	, rgn_id
	, szn_id
	)
	SELECT
	  f.version
	, f.kpy_id
	, f.order_date
	, '1456'
	, p_rgn_id
	, p_szn_id  
	FROM fn_report_1456(p_rgn_id, p_szn_id, null, null, null) f;	
	insert into tst_log(report_name, duration, rgn_id, szn_id, date_time) values('1456', date_part('second',(clock_timestamp()::time - v_time)), p_rgn_id, p_szn_id, clock_timestamp()::timestamp);
	-- 
	-- 1318
	v_time := clock_timestamp()::time;
	INSERT INTO rpt_remote_control_detail(
	  version
	, kpy_id
	, obr_date
	, report_name
	, rgn_id
	, szn_id
	)
	SELECT
	  f.version
	, f.kpy_id
	, f.order_date
	, '1318'
	, p_rgn_id
	, p_szn_id  
	FROM fn_report_1318(p_rgn_id, p_szn_id, null, null, null) f;	
	insert into tst_log(report_name, duration, rgn_id, szn_id, date_time) values('1318', date_part('second',(clock_timestamp()::time - v_time)), p_rgn_id, p_szn_id, clock_timestamp()::timestamp);
	-- 
	-- 1306
	v_time := clock_timestamp()::time;
	INSERT INTO rpt_remote_control_detail(
	  version
	, kpy_id
	, obr_date
	, report_name
	, rgn_id
	, szn_id
	)
	SELECT
	  f.version
	, f.kpy_id
	, f.send_date
	, '1306'
	, p_rgn_id
	, p_szn_id  
	FROM fn_report_1306(p_rgn_id, p_szn_id, null, null, null) f;	
	insert into tst_log(report_name, duration, rgn_id, szn_id, date_time) values('1306', date_part('second',(clock_timestamp()::time - v_time)), p_rgn_id, p_szn_id, clock_timestamp()::timestamp);
	--
	-- 1139
	v_time := clock_timestamp()::time;
	INSERT INTO rpt_remote_control_detail(
	  version
	, kpy_id
	, obr_date
	, report_name
	, rgn_id
	, szn_id
	)
	SELECT
	  f.version
	, f.kpy_id
	, f.order_date
	, '1139'
	, p_rgn_id
	, p_szn_id  
	FROM fn_report_1139(p_rgn_id, p_szn_id, null, null, null) f;		
	insert into tst_log(report_name, duration, rgn_id, szn_id, date_time) values('1139', date_part('second',(clock_timestamp()::time - v_time)), p_rgn_id, p_szn_id, clock_timestamp()::timestamp);
	--	
	-- 1457
	v_time := clock_timestamp()::time;
	INSERT INTO rpt_remote_control_detail(
	  version
	, kpy_id
	, obr_date
	, report_name
	, rgn_id
	, szn_id
	)
	SELECT
	  f.version
	, f.kpy_id
	, f.unempl_date
	, '1457'
	, p_rgn_id
	, p_szn_id  
	FROM fn_report_1457(p_rgn_id, p_szn_id, null, null, null) f;		
	insert into tst_log(report_name, duration, rgn_id, szn_id, date_time) values('1457', date_part('second',(clock_timestamp()::time - v_time)), p_rgn_id, p_szn_id, clock_timestamp()::timestamp);
	--
	RETURN true;
--EXCEPTION
--	WHEN OTHERS THEN
--		RETURN false;	
END;
$$;
