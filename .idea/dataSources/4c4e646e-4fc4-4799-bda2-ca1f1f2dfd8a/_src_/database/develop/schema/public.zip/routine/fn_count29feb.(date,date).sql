create function fn_count29feb(start_date date, end_date date) returns integer
LANGUAGE plpgsql
AS $$
DECLARE
            v int;
            BEGIN
               SELECT
                   SUM(CASE to_char(i::date, 'DDMM') WHEN '2902' THEN 1 ELSE 0 END)
                  INTO
                    v
               FROM generate_series(start_date, end_date, '1 day'::interval) i;
                  return v;
            END;
$$;
