create function rpt_kpy_tbl432(p_rgn_id bigint, p_datebegin date, p_dateend date) returns TABLE(id bigint, version bigint, doc_date date, num character varying, obr_date date, pz_close_date date, szn_rec_id character varying, close_rsn_id bigint, pers_id bigint, pz_close_rsn_id bigint, szn_dep_id bigint, close_date date, sys_id character varying, career_id bigint, info_id bigint, pob_id bigint, is_ref_direct boolean, sent_by character varying, unempl_date date, fio character varying, szn character varying, rgn character varying)
LANGUAGE plpgsql
AS $$
BEGIN

						RETURN QUERY
						WITH kpyCTE(kpy_id,prikaz_id,D1,D2)
						AS
						(

						SELECT kpy.id,
						prikaz9_25.id,
						prikaz9_25.start_date,
						coalesce(prikaz10_26.start_date, prikaz9_25.end_date)
						FROM psn_kpy kpy
						JOIN psn_order prikaz9_25 ON prikaz9_25.kpy_id = kpy.id
						JOIN ref_dict_line prkz_dict ON prkz_dict.id = prikaz9_25.prkz_id
						JOIN ref_dict_line stp ON prikaz9_25.status_id = stp.id AND stp.code::text = '1'::text
						LEFT JOIN ref_dict_line ifn ON prikaz9_25.ifn_id = ifn.id
						JOIN psn_order prikaz12 ON prikaz12.kpy_id = kpy.id
						JOIN ref_dict_line prkz_dict12 ON prkz_dict12.id = prikaz12.prkz_id
						JOIN ref_dict_line stp12 ON prikaz12.status_id = stp12.id AND stp12.code::text = '1'::text

						LEFT JOIN psn_order prikaz10_26 ON prikaz10_26.kpy_id = kpy.id AND prikaz10_26.parent_id = prikaz9_25.id
						LEFT JOIN ref_dict_line prkz_dict10_26 ON prkz_dict.id = prikaz10_26.prkz_id AND prkz_dict10_26.code::text IN ('10','26')
						LEFT JOIN ref_dict_line stp10_26 ON prikaz10_26.status_id = stp10_26.id AND stp10_26.code::text = '1'::text
						LEFT JOIN ref_szn szn ON szn.id = kpy.szn_dep_id
						WHERE
						szn.rgn_id = p_rgn_id
						AND (p_dateBegin IS NULL OR prikaz9_25.order_date >= p_dateBegin)
						AND (p_dateEnd IS NULL OR prikaz9_25.order_date <= p_dateEnd)
						AND prkz_dict.code::text IN ('25','9')
						AND prkz_dict12.code::text IN ('12')
						AND (ifn.code = '3' OR ifn.id IS NULL)
						AND prikaz12.order_date IS NOT NULL
						)

						SELECT psn_kpy.id, psn_kpy.version, psn_kpy.doc_date, psn_kpy.num, psn_kpy.obr_date, psn_kpy.pz_close_date, psn_kpy.szn_rec_id,
						psn_kpy.close_rsn_id, psn_kpy.pers_id, psn_kpy.pz_close_rsn_id, psn_kpy.szn_dep_id, psn_kpy.close_date,
						psn_kpy.sys_id, psn_kpy.career_id, psn_kpy.info_id, psn_kpy.pob_id, psn_kpy.is_ref_direct, psn_kpy.sent_by, psn_kpy.unempl_date,
						CAST (concat(pers.last_name, ' ', pers.first_name, ' ', pers.middle_name) AS character varying) AS fio,
						szn.name as szn,
						rgn.name as rgn
						FROM
						(

						SELECT kpy_id from kpyCTE
						EXCEPT
						SELECT DISTINCT kpy.kpy_id
						FROM kpyCTE kpy
						JOIN psn_order prikaz1_7 ON prikaz1_7.kpy_id = kpy.kpy_id
						JOIN ref_dict_line prkz_dict ON prkz_dict.id = prikaz1_7.prkz_id AND prkz_dict.code::text IN ('1', '7')
						JOIN ref_dict_line stp ON prikaz1_7.status_id = stp.id AND stp.code::text = '1'::text
						LEFT JOIN psn_order prikaz8 ON prikaz8.kpy_id = kpy.kpy_id
						LEFT JOIN ref_dict_line prkz_dict8 ON prkz_dict8.id = prikaz8.prkz_id AND prkz_dict8.code::text = '8'
						LEFT JOIN ref_dict_line stp8 ON prikaz8.status_id = stp8.id AND stp8.code::text = '1'::text
						WHERE
						coalesce(prikaz8.start_Date, prikaz1_7.end_date) < kpy.D1
						AND prikaz1_7.ID NOT IN
						(
						SELECT parent_id
						FROM psn_order prikaz8
						JOIN ref_dict_line prkz_dict ON prkz_dict.id = prikaz8.prkz_id AND prkz_dict.code::text = '8'
						JOIN ref_dict_line stp ON prikaz8.status_id = stp.id AND stp.code::text = '1'::text
						JOIN ref_dict_line prp ON prikaz8.prp_id = prp.id AND prp.code::text != '13'::text AND prp.code::text != '21'::text
						WHERE prikaz8.kpy_id = prikaz1_7.kpy_id AND prikaz8.parent_id = prikaz1_7.ID
						)
						UNION
						SELECT DISTINCT
						kpy.kpy_id
						FROM  kpyCTE kpy
						JOIN psn_study study ON study.kpy_id = kpy.kpy_id
						WHERE KPY.D1 between study.start_Date and study.end_date
						AND KPY.D2 between study.start_Date and study.end_date
						) t 	JOIN psn_kpy ON t.kpy_id = psn_kpy.id
						LEFT JOIN psn_person pers ON pers.id = psn_kpy.pers_id
						LEFT JOIN ref_szn szn ON psn_kpy.szn_dep_id = szn.id
						LEFT JOIN ref_rgn rgn ON rgn.id = szn.rgn_id;

						END;

$$;
