CREATE MATERIALIZED VIEW vm_rpt_kpy_tbl719 AS SELECT ord.id,
    ord.order_date,
    ord.kpy_id,
    ord.parent_id
   FROM ((((psn_order ord
     JOIN ref_dict_line tvs ON (((tvs.id = ord.tvs_id) AND ((tvs.code)::text = 'М'::text))))
     JOIN ref_dict_line rshs ON (((rshs.id = ord.rshs_id) AND ((rshs.code)::text = 'П'::text))))
     JOIN ref_dict_line prs ON (((prs.id = ord.prs_id) AND ((prs.code)::text = 'МНФ'::text))))
     JOIN ref_dict_line ifn ON (((ifn.id = ord.ifn_id) AND ((ifn.code)::text = '3'::text))))
  WHERE (NOT (EXISTS ( SELECT prikazo.id
           FROM (psn_order prikazo
             JOIN ref_dict_line rshso ON (((prikazo.rshs_id = rshso.id) AND ((rshso.code)::text = 'О'::text))))
          WHERE (prikazo.parent_id = ord.id))));
CREATE INDEX vm_tbl719_kpy_index
  ON vm_rpt_kpy_tbl719 (kpy_id);
CREATE INDEX vm_tbl719_parent_index
  ON vm_rpt_kpy_tbl719 (parent_id);
