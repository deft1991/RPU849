create function fn_set_region(p_rgn_id bigint) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
 res boolean  := true;
 r record;
BEGIN
  FOR r IN (select id  from ref_szn szn where rgn_id = p_rgn_id)
  LOOP
    res :=   tsk_set_remote_control_detail(p_rgn_id, r.id); 
    IF ( res is false) THEN
      EXIT;
    END IF;  
  END LOOP;
  RETURN res;
END;
$$;
