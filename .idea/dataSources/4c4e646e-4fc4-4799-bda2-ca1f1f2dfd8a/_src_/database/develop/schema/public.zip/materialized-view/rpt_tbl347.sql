CREATE MATERIALIZED VIEW rpt_tbl347 AS SELECT vac.id,
    vac.version,
    org.full_name AS orgname,
    prof.name AS profname,
    vac.reg_date AS receiptdate,
    vac.zp_from AS zpfrom,
    vac.zp_to AS zpto,
    rgn.name AS rgn,
    rgn.id AS rgnid,
    okved2.name AS okved,
    okfs.name AS okfs,
    okfs.id AS okfsid
   FROM ((((((lgl_vacancy vac
     LEFT JOIN lgl_organization org ON ((org.id = vac.org_id)))
     LEFT JOIN ref_prof prof ON ((prof.id = vac.prof_id)))
     LEFT JOIN ref_szn szn ON ((szn.id = vac.szn_id)))
     LEFT JOIN ref_rgn rgn ON ((rgn.id = szn.rgn_id)))
     LEFT JOIN ref_okved2 okved2 ON ((okved2.id = org.okved2_id)))
     LEFT JOIN ref_okfs okfs ON ((okfs.id = org.okfs_id)));
