create function fn_set_region_test(p_rgn_id bigint) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
 r record;
BEGIN
  FOR r IN (select id  from ref_szn szn where rgn_id = p_rgn_id)
  LOOP
    RAISE INFO 'id: %', r.id;
    COMMIT;
    RAISE INFO 'commit ok';
  END LOOP;
  return false;
END;
$$;
