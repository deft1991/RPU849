create function fn_dw_report_1219(p_rgn_id bigint, p_szn_id bigint) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
			BEGIN
			DELETE FROM dw_rep1219
			WHERE 1 = 1
			AND szn_id = coalesce(p_szn_id, szn_id)
			AND rgn_id = coalesce(p_rgn_id, rgn_id)
			;
			--
			INSERT INTO dw_rep1219(
			szn_id -- СЗН
			, rgn_id -- Регион
			, kpy_num -- КПУ
			, fio -- ФИО
			, obr_date -- Дата обращения
			, kng_id -- Категория незанятости
			, tpr_id -- Категория испытывающего трудности в поисках работы
			, proposit_date -- Дата предложения
			, close_rsn_id -- Причина закрытия
			, report_year -- Отчетный год
			, report_month -- Отчетный месяц
			, cnt -- Мера
			)
			SELECT DISTINCT
			coalesce(szn.id, 0) AS szn_id -- СЗН
			, coalesce(rgn.id, 0) AS rgn_id -- Регион
			, coalesce(kpy.num, '') as kpy_num -- КПУ
			, coalesce(pers.last_name || ' ' || pers.first_name || ' ' || pers.middle_name, '') as fio -- ФИО
			, kpy.obr_date AS obr_date -- Дата обращения
			, coalesce(kpy_kng.kng_id, 0) AS kng_id -- Категория незанятости
			, coalesce(jsp.tpr_id, 0) AS tpr_id -- Категория испытывающего трудности в поисках работы
			, pens.proposit_date AS proposit_date -- Дата предложения
			, kpy.close_rsn_id AS close_rsn_id -- Причина закрытия
			, to_char(pens.proposit_date, 'YYYY')::int4 AS report_year -- Отчетный год
			, to_char(pens.proposit_date, 'MM')::int4 AS report_month -- Отчетный месяц
			, 1 AS cnt -- Мера
			FROM psn_kpy kpy
			INNER JOIN psn_person pers ON pers.id = kpy.pers_id
			INNER JOIN ref_szn szn ON szn.id = kpy.szn_dep_id
			INNER JOIN ref_rgn rgn ON rgn.id = szn.rgn_id
			INNER JOIN psn_set_pens pens ON pens.kpy_id = kpy.id
			LEFT JOIN psn_kng kpy_kng ON kpy_kng.kpy_id = kpy.id
			LEFT JOIN psn_job_search_problem jsp ON jsp.kpy_id = kpy.id
			WHERE 1 = 1
			--AND kpy.id IN (932692606, 1330141106)
			AND pens.decision_date IS NULL
			AND szn.id = coalesce(p_szn_id, szn.id)
			AND rgn.id = coalesce(p_rgn_id, rgn.id)
			AND pens.proposit_date >= to_date('01.01.2014','DD.MM.YYYY')
			;
			return true;
			--
			END;
$$;
