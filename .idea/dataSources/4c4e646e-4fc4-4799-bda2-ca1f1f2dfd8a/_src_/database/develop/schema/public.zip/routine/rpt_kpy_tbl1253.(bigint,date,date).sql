create function rpt_kpy_tbl1253(p_rgn_id bigint, p_start_date date, p_finish_date date) returns TABLE(id bigint, version bigint, close_date date, doc_date date, num character varying, obr_date date, pz_close_date date, szn_rec_id character varying, close_rsn_id bigint, pers_id bigint, pz_close_rsn_id bigint, szn_dep_id bigint, fio character varying, szn character varying, rgn character varying, rgn_id bigint, order_date date, career_id bigint, info_id bigint, pob_id bigint)
LANGUAGE SQL
AS $$
SELECT kpy.id,
		    kpy.version,
		    kpy.close_date,
		    kpy.doc_date,
		    kpy.num,
		    kpy.obr_date,
		    kpy.pz_close_date,
		    kpy.szn_rec_id,
		    kpy.close_rsn_id,
		    kpy.pers_id,
		    kpy.pz_close_rsn_id,
		    kpy.szn_dep_id,
		    concat(pers.last_name, ' ', pers.first_name, ' ', pers.middle_name) AS fio,
		    szn.name AS szn,
		    rgn.name AS rgn,
		    rgn.id AS rgn_id,
		    prikaz8.order_date,
		    NULL::bigint AS career_id,
		    NULL::bigint AS info_id,
		    NULL::bigint AS pob_id
		   FROM psn_kpy kpy
		     JOIN ref_szn szn ON kpy.szn_dep_id = szn.id AND szn.rgn_id = coalesce(p_rgn_id, szn.rgn_id)
		     JOIN ref_rgn rgn ON szn.rgn_id = rgn.id
		     JOIN psn_order prikaz8 ON prikaz8.kpy_id = kpy.id AND prikaz8.order_date BETWEEN p_start_date AND p_finish_date
		     JOIN ref_dict_line prkz8 ON prkz8.id = prikaz8.prkz_id AND prkz8.code::text = '8'::text
		     JOIN ref_dict_line prp8 ON prp8.id = prikaz8.prp_id AND prp8.code::text = '13'::text
		     JOIN psn_order prikaz21 ON prikaz21.kpy_id = kpy.id
		     JOIN ref_dict_line prkz21 ON prkz21.id = prikaz21.prkz_id AND prkz21.code::text = '21'::text
		     JOIN psn_person pers ON pers.id = kpy.pers_id
		  WHERE (prikaz8.start_date + 1) < prikaz21.start_date AND NOT (EXISTS ( SELECT prikazo.id
		           FROM psn_order prikazo
		             JOIN ref_dict_line rshso ON prikazo.rshs_id = rshso.id AND rshso.code::text = 'О'::text
		          WHERE prikazo.parent_id = prikaz8.id OR prikazo.parent_id = prikaz21.id));


$$;
