create function patch_for_region_filials(dbconn text, sql_text text) returns void
LANGUAGE plpgsql
AS $$
DECLARE
  f record;
BEGIN
    FOR f IN select * from dblink(coalesce(dbconn,''),
        'SELECT schema_name FROM information_schema.schemata WHERE left(schema_name::text,2)=''f_''') as (schema_name text)
    LOOP
      BEGIN
        RAISE INFO ' % ..', f.schema_name;
        PERFORM dblink(coalesce(dbconn,''), 'DO $_$ BEGIN
          PERFORM set_config(''search_path'', '''||f.schema_name||', public, pg_catalog'', true);
          EXECUTE '''||replace(sql_text,'''','''''')||''';
        END $_$;');
        EXCEPTION WHEN syntax_error_or_access_rule_violation OR dependent_privilege_descriptors_still_exist THEN
        RAISE WARNING '  ERROR [%] %', SQLSTATE, SQLERRM;
      CONTINUE;
    END;
  END LOOP;
RAISE INFO 'OK';
END;
$$;
