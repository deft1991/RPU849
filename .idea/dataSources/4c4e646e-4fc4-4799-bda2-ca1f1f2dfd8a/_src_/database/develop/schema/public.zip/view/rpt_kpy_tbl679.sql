CREATE VIEW rpt_kpy_tbl679 AS SELECT DISTINCT kpy.id,
    kpy.version,
    kpy.doc_date,
    kpy.num,
    kpy.obr_date,
    kpy.pz_close_date,
    kpy.szn_rec_id,
    kpy.close_rsn_id,
    kpy.pers_id,
    kpy.pz_close_rsn_id,
    kpy.szn_dep_id,
    kpy.close_date,
    kpy.sys_id,
    kpy.career_id,
    kpy.info_id,
    kpy.pob_id,
    (((((pers.last_name)::text || ' '::text) || (pers.first_name)::text) || ' '::text) || (pers.middle_name)::text) AS fio,
    szn.name AS szn,
    rgn.name AS rgn,
    ( SELECT tpr.name
           FROM psn_job_search_problem dfj,
            ref_dict_line tpr
          WHERE ((dfj.kpy_id = kpy.id) AND (tpr.id = dfj.tpr_id))
         LIMIT 1) AS tpr,
    kzf.name AS kzf,
    rgn.id AS rgn_id,
    job.start_date AS job_start_date,
    study.start_date AS study_start_date,
    pens.fact_start_date AS pens_start_date
   FROM ((((((((((((((((psn_kpy kpy
     JOIN psn_order prikaz ON ((prikaz.kpy_id = kpy.id)))
     JOIN ref_dict_line prkz ON (((prkz.id = prikaz.prkz_id) AND ((prkz.code)::text = '12'::text))))
     JOIN psn_person pers ON ((pers.id = kpy.pers_id)))
     JOIN ref_szn szn ON ((kpy.szn_dep_id = szn.id)))
     JOIN ref_rgn rgn ON ((szn.rgn_id = rgn.id)))
     JOIN psn_kpy_info p_info ON ((p_info.id = kpy.info_id)))
     JOIN ref_dict_line pob ON (((pob.id = kpy.pob_id) AND ((pob.code)::text = ANY (ARRAY[('1'::character varying)::text, ('2'::character varying)::text, ('3'::character varying)::text, ('4'::character varying)::text])))))
     LEFT JOIN ref_dict_line kzf ON ((kzf.id = p_info.kzf_id)))
     LEFT JOIN psn_service_3589 pgu3589 ON ((kpy.id = pgu3589.kpy_id)))
     LEFT JOIN psn_send_study st ON (((pgu3589.id = st.service3589_id) AND (st.send_date IS NULL))))
     LEFT JOIN psn_family rl ON ((pers.id = rl.pers_id)))
     LEFT JOIN psn_job job ON ((kpy.id = job.kpy_id)))
     LEFT JOIN psn_study study ON ((kpy.id = study.kpy_id)))
     LEFT JOIN psn_set_pens pens ON ((kpy.id = pens.kpy_id)))
     LEFT JOIN psn_job_search_problem fj ON ((kpy.id = fj.kpy_id)))
     JOIN ref_dict_line pol ON ((pers.pol_id = pol.id)))
  WHERE ((kpy.close_date IS NULL) AND (NOT (EXISTS ( SELECT prikazo.id
           FROM (psn_order prikazo
             JOIN ref_dict_line rshso ON (((prikazo.rshs_id = rshso.id) AND ((rshso.code)::text = 'О'::text))))
          WHERE (prikazo.parent_id = prikaz.id)))) AND (NOT (kpy.id IN ( SELECT kpy_1.id
           FROM (((psn_kpy kpy_1
             JOIN psn_person pers_1 ON ((pers_1.id = kpy_1.pers_id)))
             JOIN psn_job_search_problem fj_1 ON ((kpy_1.id = fj_1.kpy_id)))
             JOIN ref_dict_line pol_1 ON ((pers_1.pol_id = pol_1.id)))
          WHERE (((pol_1.code)::text = 'Ж'::text) AND (EXISTS ( SELECT tpr.name
                   FROM psn_job_search_problem dfj,
                    ref_dict_line tpr
                  WHERE ((dfj.kpy_id = kpy_1.id) AND (tpr.id = dfj.tpr_id) AND ((tpr.code)::text = '15'::text)))) AND (rl.is_depend = true) AND ((date_part('year'::text, ('now'::text)::date) - date_part('year'::text, rl.birth_date)) >= (3)::double precision))))));
