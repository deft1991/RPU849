create function fn_report_1146(p_rgn_id bigint, p_szn_id bigint, p_sid bigint, p_start_date date, p_finish_date date) returns TABLE(id bigint, kpy_id bigint, version bigint, doc_date date, num character varying, obr_date date, pz_close_date date, szn_rec_id character varying, close_rsn_id bigint, pers_id bigint, pz_close_rsn_id bigint, szn_dep_id bigint, close_date date, sys_id character varying, career_id bigint, info_id bigint, pob_id bigint, rgn_id bigint, tpr character varying, fio character varying, szn character varying, rgn character varying, cancel_date date, order_date date, finish_date date, count_day bigint)
LANGUAGE plpgsql
AS $$
DECLARE
			r RECORD;
			BEGIN
			-- ================================================================
			-- Итог
			-- ================================================================
			IF p_sid IS NOT NULL THEN
			-- МДН
			FOR r IN (
			SELECT
			t1.szn_id
			, t1.rgn_id
			, t1.kpy_id
			, t1.version
			, t1.obr_date
			, t1.kpy_num
			, t1.fio
			, t1.szn
			, t1.rgn
			, t1.order_date
			, t1.ord_start_date
			, t1.soc_sum_end_date
			, date_part('day', t1.soc_sum_end_date::timestamp - t1.ord_start_date::timestamp) AS OVERPAY_DAY
			FROM (
			SELECT
			szn.id AS szn_id
			, szn.rgn_id AS rgn_id
			, kpy.id AS kpy_id
			, kpy.version AS version
			, kpy.obr_date AS obr_date
			, kpy.num AS kpy_num
			, pers.last_name || ' ' || pers.first_name || ' ' || pers.middle_name as fio
			, szn.name as szn
			, rgn.name as rgn
			, ord_8.order_date
			, ord_8.start_date AS ord_start_date
			, soc_card.id AS soc_card_id
			, max(soc_sum.end_date) AS soc_sum_end_date
			, max(soc_prd.oper_date) AS soc_prd_oper_date
			FROM psn_kpy kpy
			INNER JOIN rpt_param param ON param.num_value = kpy.id
			AND param.sid = p_sid
			AND param.report = '1146'
			AND param.param = 'KPY_ID'
			INNER JOIN psn_person pers ON pers.id = kpy.pers_id
			INNER JOIN psn_order ord_8 ON ord_8.kpy_id = kpy.id
			AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line prkz WHERE dic.id = prkz.dict_id AND dic.code = 'ПРКЗ' AND prkz.code = '8' AND prkz.id = ord_8.prkz_id)
			AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line stp WHERE dic.id = stp.dict_id AND dic.code = 'СТП' AND stp.code = '1' AND stp.id = coalesce(ord_8.status_id, stp.id))
			INNER JOIN psn_order ord_17 ON ord_17.kpy_id = kpy.id
			AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line prkz WHERE dic.id = prkz.dict_id AND dic.code = 'ПРКЗ' AND prkz.code IN ('1', '7') AND prkz.id = ord_17.prkz_id)
			AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line stp WHERE dic.id = stp.dict_id AND dic.code = 'СТП' AND stp.code = '1' AND stp.id = coalesce(ord_17.status_id, stp.id))
			INNER JOIN psn_soc_payment_card soc_card ON soc_card.order_id = ord_17.id
			INNER JOIN psn_soc_payment_period soc_prd ON soc_prd.soc_pmnts_card_id = soc_card.id
			INNER JOIN psn_soc_payment_sum soc_sum ON soc_sum.pmnts_period_id = soc_prd.id
			AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line vnu WHERE dic.id = vnu.dict_id AND dic.code = 'ВНУ' AND vnu.code IN ('Б', 'И', 'Р') AND vnu.id = soc_sum.vnu_id)
			AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line tn4 WHERE dic.id = tn4.dict_id AND dic.code = 'ТНЧ' AND tn4.code IN ('+', 'П', 'Б', 'С') AND tn4.id = soc_sum.tnch_id)
			INNER JOIN ref_szn szn ON kpy.szn_dep_id = szn.id
			INNER JOIN ref_rgn rgn ON rgn.id = szn.rgn_id
			WHERE 1 = 1
			AND ord_8.order_date BETWEEN coalesce(p_start_date, ord_8.order_date) AND coalesce(p_finish_date, ord_8.order_date)
			AND kpy.szn_dep_id = coalesce(p_szn_id, kpy.szn_dep_id)
			AND szn.rgn_id = coalesce(p_rgn_id, szn.rgn_id)
			AND coalesce(soc_prd.is_recalc, false) = false
			AND coalesce(soc_sum.summ, 0) > 0
			GROUP BY szn.id, rgn.id, kpy.id, ord_8.order_date, ord_8.start_date, soc_card.id, pers.id
			) t1
			WHERE 1 = 1
			AND t1.soc_sum_end_date > t1.ord_start_date
			AND NOT EXISTS (SELECT null
			FROM psn_order ord_t
			INNER JOIN psn_soc_payment_card soc_card_t ON soc_card_t.order_id = ord_t.id
			INNER JOIN psn_soc_payment_period soc_prd_t ON soc_prd_t.soc_pmnts_card_id = soc_card_t.id
			WHERE 1 = 1
			AND ord_t.kpy_id = t1.kpy_id
			AND soc_prd_t.oper_date >= t1.soc_prd_oper_date
			AND soc_prd_t.is_recalc = true
			AND soc_prd_t.soc_pmnts_card_id = t1.soc_card_id
			)
			)
			LOOP
			id := nextval('seq_mdn_kpy');
			kpy_id := r.kpy_id;
			version := r.version;
			doc_date := null;
			num := r.kpy_num;
			obr_date := r.obr_date;
			pz_close_date := null;
			szn_rec_id := null;
			close_rsn_id := null;
			pers_id := null;
			pz_close_rsn_id := null;
			szn_dep_id := null;
			close_date := null;
			sys_id := null;
			career_id := null;
			info_id := null;
			pob_id := null;
			rgn_id := null;
			tpr := null;
			fio := r.fio;
			szn := r.szn;
			rgn := r.rgn;
			cancel_date := r.ord_start_date;
			order_date := r.order_date;
			finish_date := r.soc_sum_end_date;
			count_day := r.overpay_day;
			RETURN NEXT;
			END LOOP;
			--
			DELETE FROM rpt_param WHERE sid = p_sid AND report = '1146';
			--
			ELSE
			FOR r IN (
			SELECT
			t1.szn_id
			, t1.rgn_id
			, t1.kpy_id
			, t1.obr_date
			, t1.version
			, t1.kpy_num
			, t1.fio
			, t1.szn
			, t1.rgn
			, t1.ord_start_date
			, t1.order_date
			, t1.soc_sum_end_date
			, date_part('day', t1.soc_sum_end_date::timestamp - t1.ord_start_date::timestamp) AS OVERPAY_DAY
			FROM (
			SELECT
			szn.id AS szn_id
			, szn.rgn_id AS rgn_id
			, kpy.id AS kpy_id
			, kpy.obr_date AS obr_date
			, kpy.version AS version
			, kpy.num AS kpy_num
			, pers.last_name || ' ' || pers.first_name || ' ' || pers.middle_name as fio
			, szn.name as szn
			, rgn.name as rgn
			, ord_8.order_date
			, ord_8.start_date AS ord_start_date
			, soc_card.id AS soc_card_id
			, max(soc_sum.end_date) AS soc_sum_end_date
			, max(soc_prd.oper_date) AS soc_prd_oper_date
			FROM psn_kpy kpy
			INNER JOIN psn_person pers ON pers.id = kpy.pers_id
			INNER JOIN psn_order ord_8 ON ord_8.kpy_id = kpy.id
			AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line prkz WHERE dic.id = prkz.dict_id AND dic.code = 'ПРКЗ' AND prkz.code = '8' AND prkz.id = ord_8.prkz_id)
			AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line stp WHERE dic.id = stp.dict_id AND dic.code = 'СТП' AND stp.code = '1' AND stp.id = coalesce(ord_8.status_id, stp.id))
			INNER JOIN psn_order ord_17 ON ord_17.kpy_id = kpy.id
			AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line prkz WHERE dic.id = prkz.dict_id AND dic.code = 'ПРКЗ' AND prkz.code IN ('1', '7') AND prkz.id = ord_17.prkz_id)
			AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line stp WHERE dic.id = stp.dict_id AND dic.code = 'СТП' AND stp.code = '1' AND stp.id = coalesce(ord_17.status_id, stp.id))
			INNER JOIN psn_soc_payment_card soc_card ON soc_card.order_id = ord_17.id
			INNER JOIN psn_soc_payment_period soc_prd ON soc_prd.soc_pmnts_card_id = soc_card.id
			INNER JOIN psn_soc_payment_sum soc_sum ON soc_sum.pmnts_period_id = soc_prd.id
			AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line vnu WHERE dic.id = vnu.dict_id AND dic.code = 'ВНУ' AND vnu.code IN ('Б', 'И', 'Р') AND vnu.id = soc_sum.vnu_id)
			AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line tn4 WHERE dic.id = tn4.dict_id AND dic.code = 'ТНЧ' AND tn4.code IN ('+', 'П', 'Б', 'С') AND tn4.id = soc_sum.tnch_id)
			INNER JOIN ref_szn szn ON kpy.szn_dep_id = szn.id
			INNER JOIN ref_rgn rgn ON rgn.id = szn.rgn_id
			WHERE 1 = 1
			AND kpy.szn_dep_id = p_szn_id
			AND szn.rgn_id = p_rgn_id
			AND coalesce(soc_prd.is_recalc, false) = false
			AND coalesce(soc_sum.summ, 0) > 0
			GROUP BY szn.id, rgn.id, kpy.id, ord_8.order_date, ord_8.start_date, soc_card.id, pers.id
			) t1
			WHERE 1 = 1
			AND t1.soc_sum_end_date > t1.ord_start_date
			AND NOT EXISTS (SELECT null
			FROM psn_order ord_t
			INNER JOIN psn_soc_payment_card soc_card_t ON soc_card_t.order_id = ord_t.id
			INNER JOIN psn_soc_payment_period soc_prd_t ON soc_prd_t.soc_pmnts_card_id = soc_card_t.id
			WHERE 1 = 1
			AND ord_t.kpy_id = t1.kpy_id
			AND soc_prd_t.oper_date >= t1.soc_prd_oper_date
			AND soc_prd_t.is_recalc = true
			AND soc_prd_t.soc_pmnts_card_id = t1.soc_card_id
			)
			)
			LOOP
			id := nextval('seq_mdn_kpy');
			kpy_id := r.kpy_id;
			version := r.version;
			doc_date := null;
			num := r.kpy_num;
			obr_date := r.obr_date;
			pz_close_date := null;
			szn_rec_id := null;
			close_rsn_id := null;
			pers_id := null;
			pz_close_rsn_id := null;
			szn_dep_id := null;
			close_date := null;
			sys_id := null;
			career_id := null;
			info_id := null;
			pob_id := null;
			rgn_id := null;
			tpr := null;
			fio := r.fio;
			szn := r.szn;
			rgn := r.rgn;
			cancel_date := r.ord_start_date;
			order_date := r.order_date;
			finish_date := r.soc_sum_end_date;
			count_day := r.overpay_day;
			RETURN NEXT;
			END LOOP;
			--
			END IF;
			END;
$$;
