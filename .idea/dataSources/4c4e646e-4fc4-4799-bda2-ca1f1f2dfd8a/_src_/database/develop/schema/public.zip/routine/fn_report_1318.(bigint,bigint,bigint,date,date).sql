create function fn_report_1318(p_rgn_id bigint, p_szn_id bigint, p_sid bigint, p_start_date date, p_finish_date date) returns TABLE(id bigint, kpy_id bigint, version bigint, doc_date date, num character varying, obr_date date, pz_close_date date, szn_rec_id character varying, close_rsn_id bigint, pers_id bigint, pz_close_rsn_id bigint, szn_dep_id bigint, close_date date, sys_id character varying, career_id bigint, info_id bigint, pob_id bigint, rgn_id bigint, tpr character varying, fio character varying, szn character varying, rgn character varying, kzf character varying, order_date date)
LANGUAGE plpgsql
AS $$
DECLARE
  r RECORD;
BEGIN
	-- ================================================================
	-- Итог
	-- ================================================================	     
     IF p_sid IS NOT NULL THEN 
     	-- МДН
	 	FOR r IN (
				SELECT
				  kpy.id AS kpy_id
				, kpy.version AS version	  
				, kpy.num AS kpy_num
				, concat(pers.last_name, ' ', pers.first_name, ' ', pers.middle_name) AS fio
				, szn.name AS szn
				, rgn.name AS rgn
				, kpy.obr_date AS obr_date
				, kzf.name AS kzf_name
				, ord_17.order_date AS order_date
				FROM psn_kpy kpy
				INNER JOIN rpt_param param ON param.num_value = kpy.id
					AND param.sid = p_sid 
					AND param.report = '1318' 
					AND param.param = 'KPY_ID'	
				INNER JOIN psn_person pers ON pers.id = kpy.pers_id
				INNER JOIN ref_szn szn ON szn.id = kpy.szn_dep_id
				INNER JOIN ref_rgn rgn ON rgn.id = szn.rgn_id
				INNER JOIN psn_kpy_info info ON info.id = kpy.info_id
				LEFT JOIN ref_dict_line kzf ON kzf.id = info.kzf_id
				INNER JOIN psn_order ord_17 ON ord_17.kpy_id = kpy.id
					AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line prkz WHERE dic.id = prkz.dict_id AND dic.code = 'ПРКЗ' AND prkz.code IN ('1', '7') AND prkz.id = ord_17.prkz_id)
					AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line stp WHERE dic.id = stp.dict_id AND dic.code = 'СТП' AND stp.code = '1' AND stp.id = coalesce(ord_17.status_id, stp.id))
					AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line alg WHERE dic.id = alg.dict_id AND dic.code = 'АЛГ' AND alg.code = 'П7' AND alg.id = ord_17.algo_id)
				WHERE 1 = 1
				  AND szn.rgn_id = coalesce(p_rgn_id, szn.rgn_id)
			 	  AND szn.id = coalesce(p_szn_id, szn.id)
			 	  AND ord_17.order_date BETWEEN coalesce(p_start_date, ord_17.order_date) AND coalesce(p_finish_date, ord_17.order_date)				
				  AND EXISTS ( SELECT NULL
						     FROM psn_person p1
						     INNER JOIN psn_kpy k1 ON k1.pers_id = p1.id
						     INNER JOIN PSN_ORDER prk1 ON prk1.kpy_id = k1.id
						     INNER JOIN ref_dict_line prkz1 ON prkz1.id = prk1.prkz_id AND prkz1.code = '1'
						     INNER JOIN ref_dict_line alg1 ON alg1.id = prk1.algo_id AND alg1.code = 'П7'
						     WHERE 1 = 1
						       AND k1.id != kpy.id 
						       AND k1.obr_date <= kpy.obr_date 
						       AND p1.snils = pers.snils
						     --
						     UNION ALL
						     --
							SELECT NULL
						     FROM psn_person p1
						     INNER JOIN psn_kpy k1 ON k1.pers_id = p1.id
						     INNER JOIN PSN_ORDER prk1 ON prk1.kpy_id = k1.id
						     INNER JOIN ref_dict_line prkz1 ON prkz1.id = prk1.prkz_id AND prkz1.code = '7'
						     INNER JOIN ref_dict_line alg1 ON alg1.id = prk1.algo_id AND alg1.code = 'П7'
						     WHERE 1 = 1
						       AND k1.id != kpy.id 
						       AND k1.obr_date <= kpy.obr_date 
						       AND p1.snils = pers.snils
						   )
			 )
		LOOP
		  id := nextval('seq_mdn_kpy');
		  kpy_id := r.kpy_id;
		  version := r.version;
		  doc_date := null;
		  num := r.kpy_num;
		  obr_date := r.obr_date;
		  pz_close_date := null;
		  szn_rec_id := null;
		  close_rsn_id := null;
		  pers_id := null;
		  pz_close_rsn_id := null;
		  szn_dep_id := null;
		  close_date := null;
		  sys_id := null;
		  career_id := null;
		  info_id := null;
		  pob_id := null;
		  rgn_id := null;
		  tpr := null;
		  fio := r.fio; 
		  szn := r.szn;
		  rgn := r.rgn;
		  obr_date := r.obr_date;
		  kzf := r.kzf_name;
		  order_date := r.order_date;
		  RETURN NEXT;
		END LOOP;
		--
		DELETE FROM rpt_param WHERE sid = p_sid AND report = '1318';  		
		--
	ELSE
		-- Отчет
	 	FOR r IN (
				SELECT
				  kpy.id AS kpy_id
				, kpy.version AS version  
				, kpy.num AS kpy_num
				, concat(pers.last_name, ' ', pers.first_name, ' ', pers.middle_name) AS fio
				, szn.name AS szn
				, rgn.name AS rgn
				, kpy.obr_date AS obr_date
				, kzf.name AS kzf_name
				, ord_17.order_date AS order_date
				FROM psn_kpy kpy
				INNER JOIN psn_person pers ON pers.id = kpy.pers_id
				INNER JOIN ref_szn szn ON szn.id = kpy.szn_dep_id
				INNER JOIN ref_rgn rgn ON rgn.id = szn.rgn_id
				INNER JOIN psn_kpy_info info ON info.id = kpy.info_id
				LEFT JOIN ref_dict_line kzf ON kzf.id = info.kzf_id
				INNER JOIN psn_order ord_17 ON ord_17.kpy_id = kpy.id
					AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line prkz WHERE dic.id = prkz.dict_id AND dic.code = 'ПРКЗ' AND prkz.code IN ('1', '7') AND prkz.id = ord_17.prkz_id)
					AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line stp WHERE dic.id = stp.dict_id AND dic.code = 'СТП' AND stp.code = '1' AND stp.id = coalesce(ord_17.status_id, stp.id))
					AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line alg WHERE dic.id = alg.dict_id AND dic.code = 'АЛГ' AND alg.code = 'П7' AND alg.id = ord_17.algo_id)
				WHERE 1 = 1
				  AND szn.rgn_id = p_rgn_id
			 	  AND szn.id = p_szn_id
			 	  AND ord_17.order_date BETWEEN coalesce(p_start_date, ord_17.order_date) AND coalesce(p_finish_date, ord_17.order_date)				
				  AND EXISTS ( SELECT NULL
						     FROM psn_person p1
						     INNER JOIN psn_kpy k1 ON k1.pers_id = p1.id
						     INNER JOIN PSN_ORDER prk1 ON prk1.kpy_id = k1.id
						     INNER JOIN ref_dict_line prkz1 ON prkz1.id = prk1.prkz_id AND prkz1.code = '1'
						     INNER JOIN ref_dict_line alg1 ON alg1.id = prk1.algo_id AND alg1.code = 'П7'
						     WHERE 1 = 1
						       AND k1.id != kpy.id 
						       AND k1.obr_date <= kpy.obr_date 
						       AND p1.snils = pers.snils
						     --
						     UNION ALL
						     --
							SELECT NULL
						     FROM psn_person p1
						     INNER JOIN psn_kpy k1 ON k1.pers_id = p1.id
						     INNER JOIN PSN_ORDER prk1 ON prk1.kpy_id = k1.id
						     INNER JOIN ref_dict_line prkz1 ON prkz1.id = prk1.prkz_id AND prkz1.code = '7'
						     INNER JOIN ref_dict_line alg1 ON alg1.id = prk1.algo_id AND alg1.code = 'П7'
						     WHERE 1 = 1
						       AND k1.id != kpy.id 
						       AND k1.obr_date <= kpy.obr_date 
						       AND p1.snils = pers.snils
						   )
				)
		LOOP
		  id := nextval('seq_mdn_kpy');
		  kpy_id := r.kpy_id;
		  version := r.version;
		  doc_date := null;
		  num := r.kpy_num;
		  obr_date := r.obr_date;
		  pz_close_date := null;
		  szn_rec_id := null;
		  close_rsn_id := null;
		  pers_id := null;
		  pz_close_rsn_id := null;
		  szn_dep_id := null;
		  close_date := null;
		  sys_id := null;
		  career_id := null;
		  info_id := null;
		  pob_id := null;
		  rgn_id := null;
		  tpr := null;
		  fio := r.fio; 
		  szn := r.szn;
		  rgn := r.rgn;
		  obr_date := r.obr_date;
		  kzf := r.kzf_name;
		  order_date := r.order_date;
		  RETURN NEXT;
		END LOOP;
		--	
	END IF;
END;
$$;
