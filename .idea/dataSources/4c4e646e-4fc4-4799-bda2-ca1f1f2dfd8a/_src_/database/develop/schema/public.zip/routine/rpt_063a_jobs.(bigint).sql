create function rpt_063a_jobs(vacs_id bigint) returns TABLE(id bigint, start_date date, fio text, rgn bigint, vacancy_id bigint, org_id bigint, uro character varying, prof_name character varying, ipra_vid character varying, ipra_gin character varying, ipra_ppi character varying, end_date date)
LANGUAGE plpgsql
AS $$
BEGIN

            DROP TABLE IF EXISTS jobs_temp;
            CREATE TEMP TABLE jobs_temp AS
            SELECT j.* from psn_job j where j.vacancy_id = vacs_id;

            RETURN QUERY SELECT
            job.id,
            job.start_date,
            concat(p.last_name, ' ', p.first_name, ' ', p.middle_name),
            rgn.id,
            job.vacancy_id,
            job.org_id,
            uro.name,
            edu.prof_name,
            ipra.ipra_dep,
            gin.name,
            ppi.name,
            job.end_date
            FROM jobs_temp job
            JOIN psn_kpy kpy ON kpy.id = job.kpy_id
            JOIN psn_kpy_info p_info ON p_info.id = kpy.info_id
            JOIN ref_szn szn ON szn.id = kpy.szn_dep_id
            JOIN ref_rgn rgn on rgn.id = szn.rgn_id
            JOIN psn_person p ON p.id = kpy.pers_id
            LEFT JOIN psn_education edu ON edu.pers_id = p.id
            LEFT JOIN ref_dict_line uro ON uro.id = p_info.uro_id
            LEFT JOIN psn_ipra ipra ON ipra.kpy_id = kpy.id
            LEFT JOIN ref_dict_line gin ON gin.id = ipra.gin_id
            LEFT JOIN ref_dict_line ppi ON ppi.id = ipra.ppi_id
            WHERE job.vacancy_id = vacs_id
            AND   kpy.close_date IS NOT NULL
            OR    EXISTS (select close.* from ref_dict_line close
            where close.id = kpy.close_rsn_id and close.code = '01')
            OR      (
            EXISTS (select pz_close.* from ref_dict_line pz_close
            where pz_close.id = kpy.pz_close_rsn_id and pz_close.code = '01')
            AND
            EXISTS (select close.* from ref_dict_line close
            where close.id = kpy.close_rsn_id and close.code = '12')
            );

            DROP TABLE IF EXISTS jobs_temp;
            END;
$$;
