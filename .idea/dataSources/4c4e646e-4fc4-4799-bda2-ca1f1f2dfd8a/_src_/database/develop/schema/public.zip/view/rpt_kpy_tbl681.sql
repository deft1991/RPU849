CREATE VIEW rpt_kpy_tbl681 AS SELECT kpy.id,
    kpy.version,
    kpy.doc_date,
    kpy.num,
    kpy.obr_date,
    kpy.pz_close_date,
    kpy.szn_rec_id,
    kpy.close_rsn_id,
    kpy.pers_id,
    kpy.pz_close_rsn_id,
    kpy.szn_dep_id,
    kpy.close_date,
    concat(pers.last_name, ' ', pers.first_name, ' ', pers.middle_name) AS fio,
    szn.name AS szn,
    region.name AS rgn,
    ( SELECT tpr.name
           FROM psn_job_search_problem dfj,
            ref_dict_line tpr
          WHERE ((dfj.kpy_id = kpy.id) AND (tpr.id = dfj.tpr_id))
         LIMIT 1) AS tpr,
    kzf.name AS kzf,
    NULL::bigint AS career_id,
    NULL::bigint AS info_id,
    NULL::bigint AS pob_id
   FROM ((((((((psn_kpy kpy
     LEFT JOIN psn_order prikaz ON ((prikaz.kpy_id = kpy.id)))
     LEFT JOIN ref_dict_line prikaz_prkz ON ((prikaz_prkz.id = prikaz.prkz_id)))
     JOIN psn_person pers ON ((pers.id = kpy.pers_id)))
     LEFT JOIN psn_kpy_info p_info ON ((p_info.id = kpy.info_id)))
     LEFT JOIN ref_dict_line pob ON ((pob.id = kpy.pob_id)))
     LEFT JOIN ref_szn szn ON ((kpy.szn_dep_id = szn.id)))
     LEFT JOIN ref_region region ON ((region.id = szn.rgn_id)))
     LEFT JOIN ref_dict_line kzf ON ((kzf.id = p_info.kzf_id)))
  WHERE ((((prikaz_prkz.code)::text <> ALL (ARRAY[('12'::character varying)::text, ('13'::character varying)::text])) OR (((prikaz_prkz.code)::text = ANY (ARRAY[('12'::character varying)::text, ('13'::character varying)::text])) AND (EXISTS ( SELECT prikaz_other.id
           FROM (psn_order prikaz_other
             LEFT JOIN ref_dict_line rshs ON ((prikaz_other.rshs_id = rshs.id)))
          WHERE (((rshs.code)::text = 'O'::text) AND (prikaz_other.parent_id = prikaz.id)))))) AND ((pob.code)::text = ANY (ARRAY[('1'::character varying)::text, ('2'::character varying)::text, ('3'::character varying)::text, ('4'::character varying)::text])) AND ((kpy.doc_date - kpy.close_date) >= 11) AND (EXISTS ( SELECT kng.name
           FROM psn_kng tkng,
            ref_dict_line kng
          WHERE ((tkng.kpy_id = kpy.id) AND (kng.id = tkng.kng_id) AND ((kng.code)::text <> '11'::text)))));
