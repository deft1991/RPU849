create function fn_report_1399_v2(p_rgn_id bigint, p_szn_id bigint, p_start_date date, p_finish_date date, p_duration bigint) returns TABLE(kpy_id bigint, duration bigint)
LANGUAGE plpgsql
AS $$
DECLARE
  r RECORD;
BEGIN
	-- ================================================================
	-- DDL
	-- ================================================================
	BEGIN
		DELETE FROM tmp_report_1399;
	EXCEPTION
	  WHEN others THEN
		create temporary table tmp_report_1399(
		  id bigserial
		, marker int8
		, kpy_id int8
		, order_id int8
		, order_date date
		, start_date date
		, end_date date
		, ord int8
		, duration int8
		);
	END;	
	-- ================================================================
	-- Действующие приказы "Назначить пособие" (нумерация по порядку - дате приказа)
	-- ================================================================
     INSERT INTO tmp_report_1399(
	  marker
	, order_id
	, kpy_id
	, order_date
	, start_date
	, end_date
	, ord
	, duration
	)
	SELECT
	  1
	, ord_17.id
	, kpy.id
	, ord_17.order_date
	, ord_17.start_date
	, coalesce(ord_8.start_date, ord_17.end_date, to_date('01.01.4000', 'DD.MM.YYYY'))   
	, row_number() OVER (PARTITION BY kpy.ID ORDER BY ord_17.order_date) 
	, date_part('day', talon.tdate::timestamp - ord_17.start_date::timestamp)   
	FROM psn_kpy kpy
	INNER JOIN ref_szn szn ON kpy.szn_dep_id = szn.id
	INNER JOIN psn_order ord_17 ON ord_17.kpy_id = kpy.id 
		AND ord_17.prkz_id IN (SELECT prkz_17.id FROM ref_dict_line prkz_17 WHERE prkz_17.code IN ('1', '7'))
		AND (ord_17.status_id IS NULL OR ord_17.status_id IN (SELECT stp.id FROM ref_dict_line stp WHERE stp.code = '1'))
	LEFT JOIN sys_talon talon ON talon.sys_id = ord_17.sys_id 
		AND ord_17.start_date <= talon.tdate 
		AND date_part('day',  talon.tdate::timestamp - ord_17.start_date::timestamp ) >= 10 --coalesce(p_duration, 0)
	LEFT JOIN psn_order ord_8 ON ord_8.kpy_id = kpy.id 
			  AND ord_8.prkz_id IN (SELECT prkz_8.id FROM ref_dict_line prkz_8 WHERE prkz_8.code IN ('8'))
		       AND (ord_8.status_id IS NULL OR ord_8.status_id IN (SELECT stp.id FROM ref_dict_line stp WHERE stp.code = '1'))
	WHERE 1 = 1
 	  --AND kpy.szn_dep_id = coalesce(p_szn_id, kpy.szn_dep_id)
	  --AND szn.rgn_id = coalesce(p_rgn_id, szn.rgn_id)
	  AND szn.rgn_id = 34
	  --AND kpy.obr_date <= p_finish_date
	  AND kpy.obr_date <= to_date('31.12.2016', 'DD.MM.YYYY')
	  --AND coalesce(kpy.close_date, p_start_date) >= p_start_date
	  AND coalesce(kpy.close_date, to_date('01.12.2016', 'DD.MM.YYYY')) >= to_date('01.12.2016', 'DD.MM.YYYY')
	  --AND ord_17.order_date BETWEEN p_start_date AND p_finish_date
	  AND ord_17.order_date BETWEEN to_date('01.12.2016', 'DD.MM.YYYY') AND to_date('31.12.2016', 'DD.MM.YYYY')
	  --AND kpy.id = 3609771034
 	;	
 	-- ================================================================
	-- Действующие приказы "Снять с учета" (нумерация по порядку - дате приказа)
	-- ================================================================
	INSERT INTO tmp_report_1399(
	  marker
	, order_id
	, kpy_id
	, start_date
	, ord
	)
	SELECT
	  2
	, t.order_id
	, t.kpy_id
	, t.start_date
	, ROW_NUMBER() OVER (PARTITION BY t.kpy_id ORDER BY t.order_date) AS R
	FROM tmp_report_1399 t 
	INNER JOIN psn_order ord_8 ON ord_8.kpy_id = t.kpy_id 
			  AND ord_8.prkz_id IN (SELECT prkz_8.id FROM ref_dict_line prkz_8 WHERE prkz_8.code IN ('8'))
		       AND (ord_8.status_id IS NULL OR ord_8.status_id IN (SELECT stp.id FROM ref_dict_line stp WHERE stp.code = '1'))
	WHERE 1 = 1
	  AND t.marker = 1
	  AND t.ord = 1
	  AND ord_8.start_date >= t.start_date
	;
 	-- ================================================================
	-- Лицевые счета хотя бы с одним начислением
	-- ================================================================
	INSERT INTO tmp_report_1399(
	  marker
	, kpy_id
	, start_date
	, duration
	)
	SELECT DISTINCT
	  3
	, t.kpy_id
	, t.start_date
	, t.duration
	FROM tmp_report_1399 t 
	INNER JOIN psn_soc_payment_card soc_card ON soc_card.order_id = t.order_id
	INNER JOIN psn_soc_payment_period soc_prd ON soc_prd.soc_pmnts_card_id = soc_card.id
	INNER JOIN psn_soc_payment_sum soc_sum ON soc_sum.pmnts_period_id = soc_prd.id
 	WHERE 1 = 1
	  AND t.marker = 1	
	;
 	-- ================================================================
	-- Действующие приказы до снятия с учета
	-- ================================================================	
	INSERT INTO tmp_report_1399(
	  marker
	, kpy_id
	, start_date
	, duration
	)
	SELECT DISTINCT
	  4
	, t.kpy_id
	, t.start_date
	, t.duration
	FROM tmp_report_1399 t
	LEFT JOIN tmp_report_1399 t2 ON t2.marker = 2 AND t2.kpy_id = t.kpy_id AND t.ord = 1 AND t2.ord = 1
	LEFT JOIN tmp_report_1399 t3 ON t2.marker = 3 AND t3.order_id = t.order_id
	LEFT JOIN psn_order ord_8 ON ord_8.kpy_id = t.kpy_id 
			  AND ord_8.prkz_id IN (SELECT prkz_8.id FROM ref_dict_line prkz_8 WHERE prkz_8.code IN ('8'))
		       AND (ord_8.status_id IS NULL OR ord_8.status_id IN (SELECT stp.id FROM ref_dict_line stp WHERE stp.code = '1'))
		       AND t.start_date >= ord_8.start_date
	LEFT JOIN psn_order ord_34 ON ord_34.kpy_id = t.kpy_id 
			  AND ord_34.prkz_id IN (SELECT prkz_34.id FROM ref_dict_line prkz_34 WHERE prkz_34.code IN ('3', '4'))
		       AND (ord_34.status_id IS NULL OR ord_34.status_id IN (SELECT stp.id FROM ref_dict_line stp WHERE stp.code = '1'))
		       AND ord_34.parent_id = t.order_id
		       AND t.start_date <= ord_34.end_date
		       AND t.end_date >= ord_34.start_date
	WHERE 1 = 1
	  AND t.marker = 1	
	  AND t2.order_id IS NULL -- нет более раннего приказа "Снять с учета"
	  AND t3.order_id IS NULL -- нет лицевого счета или по счету нет ни одного начисления
	  AND ord_8.id IS NULL
	  AND ord_34.id IS NULL
	;
	-- ================================================================
	-- Итог
	-- ================================================================	     
 	FOR r IN (
			SELECT
			  t.kpy_id
			, max(t.duration) AS duration
			FROM tmp_report_1399 t
			WHERE 1 = 1
			  AND t.marker = 4	
			GROUP BY t.kpy_id
		 )
	LOOP
	  kpy_id := r.kpy_id;
	  duration := r.duration;
	  RETURN NEXT;
	END LOOP;
END;
$$;
