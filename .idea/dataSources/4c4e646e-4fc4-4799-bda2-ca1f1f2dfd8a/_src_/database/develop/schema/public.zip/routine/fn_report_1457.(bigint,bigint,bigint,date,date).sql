create function fn_report_1457(p_rgn_id bigint, p_szn_id bigint, p_sid bigint, p_start_date date, p_finish_date date) returns TABLE(id bigint, kpy_id bigint, version bigint, doc_date date, num character varying, obr_date date, pz_close_date date, szn_rec_id character varying, close_rsn_id bigint, pers_id bigint, pz_close_rsn_id bigint, szn_dep_id bigint, close_date date, sys_id character varying, career_id bigint, info_id bigint, pob_id bigint, rgn_id bigint, kzf character varying, tpr character varying, fio character varying, szn character varying, rgn character varying, unempl_date date)
LANGUAGE plpgsql
AS $$
DECLARE
			r RECORD;
			BEGIN
			-- ================================================================
			-- Итог
			-- ================================================================
			IF p_sid IS NOT NULL THEN
			-- МДН
			FOR r IN (
			SELECT DISTINCT
			kpy.id
			, kpy.version
			, kpy.num as kpy_num
			, pers.last_name || ' ' || pers.first_name || ' ' || pers.middle_name as fio
			, szn.name as szn
			, rgn.name as rgn
			, kpy.obr_date as obr_date
			, coalesce(ord_12.order_date, pers.unempl_date) AS order_date
			, kzf.name AS kzf
			, (SELECT k2.name FROM ref_dict_line k2 WHERE k2.id = kng.kng_id AND k2.code != '03' limit 1) AS tpr
			FROM psn_kpy kpy
			INNER JOIN rpt_param param ON param.num_value = kpy.id
			AND param.sid = p_sid
			AND param.report = '1457'
			AND param.param = 'KPY_ID'
			INNER JOIN psn_person pers ON pers.id = kpy.pers_id
			INNER JOIN psn_kpy_info info ON info.id = kpy.info_id
			INNER JOIN ref_szn szn ON szn.id = kpy.szn_dep_id
			INNER JOIN ref_rgn rgn ON rgn.id = szn.rgn_id
			LEFT JOIN ref_dict_line kzf ON kzf.id = info.kzf_id
			LEFT JOIN psn_kng kng ON kng.kpy_id = kpy.id
			AND EXISTS (SELECT null FROM ref_dict_line kk WHERE kk.id = kng.kng_id AND kk.code IN ('03', '04', '08', '15' ))
			LEFT JOIN psn_doc_offered doc ON doc.kpy_id = kpy.id
			AND EXISTS (SELECT null FROM ref_dict_line d WHERE d.id = doc.doc_id AND d.code = 'ПНЗ')
			LEFT JOIN psn_order ord_12 ON ord_12.kpy_id = kpy.id
			AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line prkz WHERE dic.id = prkz.dict_id AND dic.code = 'ПРКЗ' AND prkz.code = '12' AND prkz.id = ord_12.prkz_id)
			AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line stp WHERE dic.id = stp.dict_id AND dic.code = 'СТП' AND stp.code = '1' AND stp.id = coalesce(ord_12.status_id, stp.id))
			INNER JOIN psn_prev_work pw ON pw.kpy_id = kpy.id	AND pw.is_last IS TRUE
			WHERE 1 = 1
			AND coalesce(ord_12.order_date, pers.unempl_date) BETWEEN coalesce(p_start_date, ord_12.order_date, pers.unempl_date) AND coalesce(p_finish_date, ord_12.order_date, pers.unempl_date)
			AND szn.rgn_id = coalesce(p_rgn_id, szn.rgn_id)
			AND szn.id = coalesce(p_szn_id, szn.id)
			AND coalesce(ord_12.order_date, pers.unempl_date) IS NOT NULL
			AND coalesce(info.zp, 0) = 0
			AND kng.id IS NULL
			AND (coalesce(ord_12.order_date, pers.unempl_date) - pw.end_date) <= 365 + coalesce(fn_count29feb(coalesce(ord_12.order_date, pers.unempl_date), pw.end_date),0)
			AND EXISTS (SELECT null
			FROM dual
			WHERE 1 = 1
			AND doc.id IS NULL
			UNION ALL
			SELECT null
			FROM dual
			WHERE 1 = 1
			AND doc.id IS NOT NULL
			AND doc.szn_date > coalesce(ord_12.order_date, pers.unempl_date)
			)
			)
			LOOP
			id := nextval('seq_mdn_kpy');
			kpy_id := r.id;
			version := r.version;
			num := r.kpy_num;
			obr_date := r.obr_date;
			fio := r.fio;
			szn := r.szn;
			rgn := r.rgn;
			unempl_date := r.order_date;
			kzf := r.kzf;
			tpr := r.tpr;
			RETURN NEXT;
			END LOOP;
			--
			DELETE FROM rpt_param WHERE sid = p_sid AND report = '1457';
			--
			ELSE
			FOR r IN (
			SELECT DISTINCT
			kpy.id
			, kpy.version
			, kpy.num as kpy_num
			, pers.last_name || ' ' || pers.first_name || ' ' || pers.middle_name as fio
			, szn.name as szn
			, rgn.name as rgn
			, kpy.obr_date as obr_date
			, coalesce(ord_12.order_date, pers.unempl_date) AS order_date
			, kzf.name AS kzf
			, (SELECT k2.name FROM ref_dict_line k2 WHERE k2.id = kng.kng_id AND k2.code != '03' limit 1) AS tpr
			FROM psn_kpy kpy
			INNER JOIN psn_person pers ON pers.id = kpy.pers_id
			INNER JOIN psn_kpy_info info ON info.id = kpy.info_id
			INNER JOIN ref_szn szn ON szn.id = kpy.szn_dep_id
			INNER JOIN ref_rgn rgn ON rgn.id = szn.rgn_id
			LEFT JOIN ref_dict_line kzf ON kzf.id = info.kzf_id
			LEFT JOIN psn_kng kng ON kng.kpy_id = kpy.id
			AND EXISTS (SELECT null FROM ref_dict_line k WHERE k.id = kng.kng_id AND k.code IN ('03', '04', '08', '15' ) )
			LEFT JOIN psn_doc_offered doc ON doc.kpy_id = kpy.id
			AND EXISTS (SELECT null FROM ref_dict_line d WHERE d.id = doc.doc_id AND d.code = 'ПНЗ')
			LEFT JOIN psn_order ord_12 ON ord_12.kpy_id = kpy.id
			AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line prkz WHERE dic.id = prkz.dict_id AND dic.code = 'ПРКЗ' AND prkz.code = '12' AND prkz.id = ord_12.prkz_id)
			AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line stp WHERE dic.id = stp.dict_id AND dic.code = 'СТП' AND stp.code = '1' AND stp.id = coalesce(ord_12.status_id, stp.id))
			INNER JOIN psn_prev_work pw ON pw.kpy_id = kpy.id	AND pw.is_last IS TRUE
			WHERE 1 = 1
			AND szn.rgn_id = p_rgn_id
			AND szn.id = p_szn_id
			AND coalesce(ord_12.order_date, pers.unempl_date) IS NOT NULL
			AND coalesce(info.zp, 0) = 0
			AND kng.id IS NULL
			AND (coalesce(ord_12.order_date, pers.unempl_date) - pw.end_date) <= 365 + coalesce(fn_count29feb(coalesce(ord_12.order_date, pers.unempl_date), pw.end_date),0)
			AND EXISTS (SELECT null
			FROM dual
			WHERE 1 = 1
			AND doc.id IS NULL
			UNION ALL
			SELECT null
			FROM dual
			WHERE 1 = 1
			AND doc.id IS NOT NULL
			AND doc.szn_date > coalesce(ord_12.order_date, pers.unempl_date)
			)
			)
			LOOP
			id := nextval('seq_mdn_kpy');
			kpy_id := r.id;
			version := r.version;
			num := r.kpy_num;
			obr_date := r.obr_date;
			fio := r.fio;
			szn := r.szn;
			rgn := r.rgn;
			unempl_date := r.order_date;
			kzf := r.kzf;
			tpr := r.tpr;
			RETURN NEXT;
			END LOOP;
			--
			END IF;
			END;
$$;
