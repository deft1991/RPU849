create function doc1119(datefrom date, dateto date, rgnid bigint DEFAULT '-1'::integer) returns TABLE(sznname character varying, cnt2 bigint, cnt3 bigint, cnt4 bigint, cnt5 bigint, cnt6 bigint, cnt7 bigint, cnt8 bigint, cnt9 bigint, cnt10 bigint, cnt11 bigint)
LANGUAGE plpgsql
AS $$
DECLARE
			r RECORD;
			BEGIN
			-- ================================================================
			-- DDL
			-- ================================================================
			if (not exists (SELECT 1 FROM pg_tables WHERE tablename='tmp_report_doc1119')
			or not exists (SELECT relname FROM pg_class WHERE relname='tmp_report_doc1119')
			or (SELECT iftableexists('tmp_report_doc1119') = 'F')
			) then
				create temporary table tmp_report_doc1119(
				  szn_name character varying
				  , cnt2 bigint
				  , cnt3 bigint
				  , cnt4 bigint
				  , cnt5 bigint
				  , cnt6 bigint
				  , cnt7 bigint
				  , cnt8 bigint
				  , cnt9 bigint
				  , cnt10 bigint
				  , cnt11 bigint
				);
				alter table tmp_report_doc1119 add primary key (szn_name);
			else
				DELETE FROM tmp_report_doc1119;
			end if;

			-- cnt2
			INSERT INTO tmp_report_doc1119 (szn_name, cnt2)
			SELECT vm.szn_name
			  , COUNT(DISTINCT vm.kpy_id) as cnt
			FROM vm_doc1119 vm
			  JOIN psn_order order12 ON order12.kpy_id = vm.kpy_id AND order12.order_date IS NOT NULL
			  JOIN ref_dict_line prkz12 ON prkz12.id = order12.prkz_id AND prkz12.code::text = '12'::text
			  JOIN ref_dict_line stp12 ON order12.status_id = stp12.id AND stp12.code::text = '1'::text
			WHERE vm.rgn_id = rgnid
			  AND order12.order_date between datefrom AND dateto
			GROUP BY vm.szn_name
			;

			-- cnt3
			INSERT INTO tmp_report_doc1119 (szn_name, cnt3)
			SELECT vm.szn_name
			  , COUNT(DISTINCT vm.kpy_id) as cnt
			FROM vm_doc1119 vm
			  JOIN psn_order order1 ON order1.kpy_id = vm.kpy_id
			  JOIN ref_dict_line prkz1 ON prkz1.id = order1.prkz_id AND prkz1.code::text = '1'::text
			  JOIN ref_dict_line stp1 ON order1.status_id = stp1.id AND stp1.code::text = '1'::text
			WHERE vm.rgn_id = rgnid
			  AND order1.order_date between datefrom AND dateto
			GROUP BY vm.szn_name
			ON CONFLICT (szn_name) DO UPDATE SET cnt3 = EXCLUDED.cnt3
			;

			-- cnt4
			INSERT INTO tmp_report_doc1119 (szn_name, cnt4)
			SELECT vm.szn_name
			  , COUNT(DISTINCT vm.kpy_id) as cnt
			FROM vm_doc1119 vm
			  JOIN ref_dict_line pob ON pob.id = vm.pob_id AND pob.code in ('1' ,'2', '3', '4')
			WHERE vm.rgn_id = rgnid
			  AND vm.obr_date <= dateto
			  AND vm.close_date between datefrom AND dateto
			GROUP BY vm.szn_name
			ON CONFLICT (szn_name) DO UPDATE SET cnt4 = EXCLUDED.cnt4
			;

			-- cnt5
			INSERT INTO tmp_report_doc1119 (szn_name, cnt5)
			SELECT vm.szn_name
			  , COUNT(DISTINCT vm.kpy_id) as cnt
			FROM vm_doc1119 vm
			  JOIN psn_order order9 ON order9.kpy_id = vm.kpy_id
			  JOIN ref_dict_line prkz9 ON prkz9.id = order9.prkz_id AND prkz9.code::text = '9'::text
			  JOIN ref_dict_line stp9 ON order9.status_id = stp9.id AND stp9.code::text = '1'::text
			WHERE vm.rgn_id = rgnid
			  AND order9.order_date BETWEEN datefrom AND dateto
			GROUP BY vm.szn_name
			ON CONFLICT (szn_name) DO UPDATE SET cnt5 = EXCLUDED.cnt5
			;

			-- cnt6
			INSERT INTO tmp_report_doc1119 (szn_name, cnt6)
			SELECT vm.szn_name
			  , COUNT(DISTINCT vm.kpy_id) as cnt
			FROM vm_doc1119 vm
			JOIN psn_order order25 ON order25.kpy_id = vm.kpy_id
			  JOIN ref_dict_line prkz25 ON prkz25.id = order25.prkz_id AND prkz25.code::text = '25'::text
			  JOIN ref_dict_line stp25 ON order25.status_id = stp25.id AND stp25.code::text = '1'::text
			WHERE vm.rgn_id = rgnid
			  AND order25.order_date BETWEEN datefrom AND dateto
			GROUP BY vm.szn_name
			ON CONFLICT (szn_name) DO UPDATE SET cnt6 = EXCLUDED.cnt6
			;

			-- cnt7
			INSERT INTO tmp_report_doc1119 (szn_name, cnt7)
			SELECT vm.szn_name
			  , COUNT(DISTINCT vm.kpy_id) as cnt
			FROM vm_doc1119 vm
			  JOIN psn_study study on study.kpy_id = vm.kpy_id
			WHERE vm.rgn_id = rgnid
			  AND study.start_date BETWEEN datefrom AND dateto
			GROUP BY vm.szn_name
			ON CONFLICT (szn_name) DO UPDATE SET cnt7 = EXCLUDED.cnt7
			;

			-- cnt8
			INSERT INTO tmp_report_doc1119 (szn_name, cnt8)
			SELECT vm.szn_name
			  , COUNT(DISTINCT vm.kpy_id) as cnt
			FROM vm_doc1119 vm
			  JOIN psn_order order21 ON order21.kpy_id = vm.kpy_id
			  JOIN ref_dict_line prkz21 ON prkz21.id = order21.prkz_id AND prkz21.code::text = '21'::text
			  JOIN ref_dict_line stp21 ON order21.status_id = stp21.id AND stp21.code::text = '1'::text
			WHERE vm.rgn_id = rgnid
			  AND order21.order_date BETWEEN datefrom AND dateto
			GROUP BY vm.szn_name
			ON CONFLICT (szn_name) DO UPDATE SET cnt8 = EXCLUDED.cnt8
			;

			-- cnt9
			INSERT INTO tmp_report_doc1119 (szn_name, cnt9)
			SELECT vm.szn_name
			  , COUNT(DISTINCT vm.kpy_id) as cnt
			FROM vm_doc1119 vm
			  JOIN ref_dict_line psu on psu.id = vm.close_rsn_id AND psu.code::text = '16'::text
			WHERE vm.rgn_id = rgnid
			  AND vm.close_date BETWEEN datefrom AND dateto
			GROUP BY vm.szn_name
			ON CONFLICT (szn_name) DO UPDATE SET cnt9 = EXCLUDED.cnt9
			;

			-- cnt10
			INSERT INTO tmp_report_doc1119 (szn_name, cnt10)
			SELECT vm.szn_name
			  , COUNT(DISTINCT vm.kpy_id) as cnt
			FROM vm_doc1119 vm
			  JOIN psn_set_pens set_pens on set_pens.kpy_id = vm.kpy_id
			WHERE vm.rgn_id = rgnid
			  AND set_pens.proposit_date BETWEEN datefrom AND dateto
			GROUP BY vm.szn_name
			ON CONFLICT (szn_name) DO UPDATE SET cnt10 = EXCLUDED.cnt10
			;

			-- cnt11
			INSERT INTO tmp_report_doc1119 (szn_name, cnt11)
			SELECT vm.szn_name
			  , COUNT(DISTINCT vm.kpy_id) as cnt
			FROM vm_doc1119 vm
			  JOIN psn_set_pens set_pens on set_pens.kpy_id = vm.kpy_id
			WHERE vm.rgn_id = rgnid
			  AND set_pens.decision_date BETWEEN datefrom AND dateto
			GROUP BY vm.szn_name
			ON CONFLICT (szn_name) DO UPDATE SET cnt11 = EXCLUDED.cnt11
			;

			-- ================================================================
			-- Итог
			-- ================================================================
			FOR r IN (
				SELECT T.szn_name
				  , coalesce(T.cnt2, 0) as cnt2
				  , coalesce(T.cnt3, 0) as cnt3
				  , coalesce(T.cnt4, 0) as cnt4
				  , coalesce(T.cnt5, 0) as cnt5
				  , coalesce(T.cnt6, 0) as cnt6
				  , coalesce(T.cnt7, 0) as cnt7
				  , coalesce(T.cnt8, 0) as cnt8
				  , coalesce(T.cnt9, 0) as cnt9
				  , coalesce(T.cnt10, 0) as cnt10
				  , coalesce(T.cnt11, 0) as cnt11
				FROM tmp_report_doc1119 T
				ORDER BY szn_name
				)
			LOOP
			  sznname := r.szn_name;
			  cnt2 := r.cnt2;
			  cnt3 := r.cnt3;
			  cnt4 := r.cnt4;
			  cnt5 := r.cnt5;
			  cnt6 := r.cnt6;
			  cnt7 := r.cnt7;
			  cnt8 := r.cnt8;
			  cnt9 := r.cnt9;
			  cnt10 := r.cnt10;
			  cnt11 := r.cnt11;
			  RETURN NEXT;
			END LOOP;
		END;



		-- Оставляю старый код функции, с запросом стоимостью 12888033.98. В качестве назидания потомкам.
		--
		--				SELECT
		--				szn_name,
		--				COUNT(DISTINCT(CASE WHEN order12_date IS NOT NULL then kpy_id else null END)) as cnt2,
		--				COUNT(DISTINCT(CASE WHEN order1_date IS NOT NULL AND order1_date between dateFrom AND dateTo then kpy_id else null END)) as cnt3,
		--				COUNT(DISTINCT(CASE WHEN obr_date <= dateTo AND close_date between dateFrom AND dateTo AND pob_code in ('1' ,'2', '3', '4') then kpy_id else NULL END)) as cnt4,
		--				COUNT(DISTINCT(CASE WHEN order9_date between dateFrom AND dateTo then kpy_id else NULL END)) as cnt5,
		--				COUNT(DISTINCT(CASE WHEN order25_date between dateFrom AND dateTo then kpy_id else NULL END)) as cnt6,
		--				COUNT(DISTINCT(CASE WHEN study_start_date between dateFrom AND dateTo then kpy_id else null END)) as cnt7,
		--				COUNT(DISTINCT(CASE WHEN order21_date between dateFrom AND dateTo then kpy_id else NULL END))  as cnt8,
		--				COUNT(DISTINCT(CASE WHEN close_Date between dateFrom AND dateTo AND psu_code = '16' then kpy_id else null END)) as cnt9,
		--				COUNT(DISTINCT(CASE WHEN proposit_date between dateFrom AND dateTo then kpy_id else NULL END)) as cnt10,
		--				COUNT(DISTINCT(CASE WHEN decision_date between dateFrom AND dateTo then kpy_id else NULL END)) as cnt11
		--			FROM (
		--				 SELECT kpy.id as kpy_id,
		--					szn.name as szn_name,
		--					kpy.num,
		--					kpy.obr_date,
		--					kpy.close_date,
		--					order12.order_date as order12_date,
		--					order1.order_date as order1_date,
		--					pob.code as pob_code,
		--					order9.order_date as order9_date,
		--					order25.order_date as order25_date,
		--					order21.order_date as order21_date,
		--					study.start_Date as study_start_date,
		--					psu.code as psu_code,
		--					set_pens.proposit_date,
		--					set_pens.decision_date
		--				 , NULL::int8 as career_id, NULL::int8 as info_id, NULL::int8 as pob_id FROM psn_kpy kpy
		--				LEFT JOIN ref_szn szn ON szn.id = kpy.szn_dep_id
		--				LEFT JOIN psn_order order12 ON order12.kpy_id = kpy.id AND (EXISTS ( SELECT prkz12.id FROM ref_dict_line prkz12
		--				LEFT JOIN ref_dict_line stp12 ON order12.status_id = stp12.id AND stp12.code::text = '1'::text
		--				WHERE prkz12.id = order12.prkz_id AND prkz12.code::text = '12'::text))
		--				LEFT JOIN psn_order order1 ON order1.kpy_id = kpy.id AND (EXISTS ( SELECT prkz1.id FROM ref_dict_line prkz1
		--				LEFT JOIN ref_dict_line stp1 ON order1.status_id = stp1.id AND stp1.code::text = '1'::text
		--				WHERE prkz1.id = order1.prkz_id AND prkz1.code::text = '1'::text))
		--				LEFT JOIN psn_person pers ON kpy.pers_id = pers.id
		--				LEFT JOIN psn_kpy_info p_info ON kpy.info_id = p_info.id
		--				LEFT JOIN ref_dict_line pob ON pob.id = kpy.pob_id AND pob.code in ('1' ,'2', '3', '4')
		--				LEFT JOIN psn_order order9 ON order9.kpy_id = kpy.id AND (EXISTS ( SELECT prkz9.id FROM ref_dict_line prkz9
		--				LEFT JOIN ref_dict_line stp9 ON order1.status_id = stp9.id AND stp9.code::text = '1'::text
		--				WHERE prkz9.id = order9.prkz_id AND prkz9.code::text = '9'::text))
		--				LEFT JOIN psn_order order25 ON order25.kpy_id = kpy.id AND (EXISTS ( SELECT prkz25.id FROM ref_dict_line prkz25
		--				LEFT JOIN ref_dict_line stp25 ON order25.status_id = stp25.id AND stp25.code::text = '1'::text
		--				WHERE prkz25.id = order25.prkz_id AND prkz25.code::text = '25'::text))
		--				LEFT JOIN psn_order order21 ON order21.kpy_id = kpy.id AND (EXISTS ( SELECT prkz21.id FROM ref_dict_line prkz21
		--				LEFT JOIN ref_dict_line stp21 ON order21.status_id = stp21.id AND stp21.code::text = '1'::text
		--				WHERE prkz21.id = order21.prkz_id AND prkz21.code::text = '21'::text))
		--				LEFT JOIN psn_study study on study.kpy_id = kpy.id
		--				LEFT JOIN ref_dict_line PSU on PSU.id =	kpy.close_Rsn_id
		--				LEFT JOIN psn_set_pens set_pens on set_pens.kpy_id = kpy.id
		--				 WHERE (rgnId = - 1 OR szn.rgn_Id = rgnId)
		--
		--				) T
		--
		--				GROUP BY szn_name
		--				ORDER BY szn_name


$$;
