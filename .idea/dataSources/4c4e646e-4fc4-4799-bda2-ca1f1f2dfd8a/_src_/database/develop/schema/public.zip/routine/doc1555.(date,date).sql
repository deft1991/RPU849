create function doc1555(datefrom date, dateto date) returns TABLE(prof character varying, cnt bigint, cnt2 bigint, cnt3 bigint, rgn character varying, fdo character varying, fdo_sorting_order integer, rgn_sorting_order character varying)
LANGUAGE SQL
AS $$
WITH CTE AS(
			SELECT
			coalesce(prof.name, okpdtr.name) AS prof,
			count(distinct t.kpy_id) AS CNT,
			count(distinct(case when prikaz.start_date >= datefrom and prkz_dict.code::text = '4'::text AND stp.code::text = '1'::text
			and ((prikaz8.id IS NOT NULL and prikaz8.start_date >= dateto) or (prikaz8.id IS NULL)) then kpy.id else null end)) AS CNT2,
			count(distinct t.kpy_id) - count(distinct(case when prikaz.start_date >= datefrom and prkz_dict.code::text = '4'::text AND stp.code::text = '1'::text then kpy.id else null end)) AS CNT3,
			rgn.name as rgn,
			rgn.sorting_order as rgn_sorting_order,
			fdo.name as fdo,
			fdo.sorting_order as fdo_sorting_order
			FROM
			(
			SELECT kpy.id as kpy_id
			FROM psn_kpy kpy
			JOIN ref_dict_line pob on pob.id = kpy.pob_id
			WHERE pob.code in ('1','2','3','4')
			AND kpy.obr_date <= dateto
			AND kpy.close_date >= dateto
			) t
			LEFT JOIN psn_order prikaz ON prikaz.kpy_id = t.kpy_id AND prikaz.start_date <= dateto AND prikaz.end_date >= dateto
			LEFT JOIN ref_dict_line prkz_dict on prkz_dict.id = prikaz.prkz_id AND prkz_dict.code::text = '4'::text
			LEFT JOIN ref_dict_line stp ON prikaz.status_id = stp.id  AND stp.code::text = '1'::text
			LEFT JOIN psn_wish wish ON wish.kpy_id = t.kpy_id
			LEFT JOIN psn_wish_prof wp ON wp.p_wish_id = wish.id
			LEFT JOIN ref_prof prof ON wp.prof_id = prof.id
			LEFT JOIN ref_okpdtr okpdtr ON okpdtr.id = prof.okpdtr_id
			LEFT JOIN psn_kpy kpy ON kpy.id = t.kpy_id
			LEFT JOIN ref_szn szn ON kpy.szn_dep_id = szn.id
			LEFT JOIN ref_rgn rgn ON rgn.id = szn.rgn_id
			LEFT JOIN ref_fdo fdo ON fdo.id = rgn.fdo_id
			LEFT JOIN psn_order prikaz8 ON prikaz8.kpy_id = t.kpy_id
			LEFT JOIN ref_dict_line prkz_dict8 on prkz_dict8.id = prikaz8.prkz_id AND prkz_dict8.code::text = '8'::text
			LEFT JOIN ref_dict_line stp8 ON prikaz8.status_id = stp8.id AND stp8.code::text = '1'::text

			GROUP BY okpdtr.name, prof.name, rgn.name, rgn.sorting_order, fdo.name, fdo.sorting_order
			)


			SELECT prof, 0 as cnt, 0 as cnt2, 0 as cnt3, rgn.name as rgn, fdo.name as fdo, fdo.sorting_order as fdo_sorting_order, rgn.sorting_order as rgn_sorting_order
			FROM cte
			CROSS JOIN ref_rgn rgn
			LEFT JOIN ref_fdo fdo on fdo.id = rgn.fdo_id
			EXCEPT
			SELECT prof, 0, 0, 0, rgn, fdo, fdo_sorting_order, rgn_sorting_order
			FROM cte
			UNION
			SELECT prof, cte.cnt, cnt2, cnt3, rgn, fdo, fdo_sorting_order, rgn_sorting_order
			FROM cte
			ORDER BY prof, fdo_sorting_order, rgn_sorting_order

$$;
