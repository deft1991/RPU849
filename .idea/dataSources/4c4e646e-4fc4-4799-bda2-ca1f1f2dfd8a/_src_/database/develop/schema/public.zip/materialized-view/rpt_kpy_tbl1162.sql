CREATE MATERIALIZED VIEW rpt_kpy_tbl1162 AS SELECT DISTINCT kpy.id,
    kpy.version,
    kpy.doc_date,
    kpy.num,
    kpy.obr_date,
    kpy.pz_close_date,
    kpy.szn_rec_id,
    kpy.close_rsn_id,
    kpy.pers_id,
    kpy.pz_close_rsn_id,
    kpy.szn_dep_id,
    kpy.close_date,
    kpy.sys_id,
    kpy.career_id,
    kpy.info_id,
    kpy.pob_id,
    concat(person.last_name, ' ', person.first_name, ' ', person.middle_name) AS fio,
    prikaz.order_num,
    prikaz.order_date,
    prikaz.start_date,
    prikaz.end_date,
    prp.name AS prp,
    szn.name AS szn,
    rgn.name AS rgn,
    rgn.id AS rgn_id,
    puv.name AS puv
   FROM ((((((((((psn_kpy kpy
     LEFT JOIN psn_person person ON ((person.id = kpy.pers_id)))
     JOIN psn_order prikaz ON ((prikaz.kpy_id = kpy.id)))
     JOIN ref_dict_line stp ON ((prikaz.status_id = stp.id)))
     JOIN ref_dict_line prkz_dict ON ((prkz_dict.id = prikaz.prkz_id)))
     LEFT JOIN ref_szn szn ON ((kpy.szn_dep_id = szn.id)))
     LEFT JOIN ref_rgn rgn ON ((rgn.id = szn.rgn_id)))
     LEFT JOIN ref_dict_line prp ON ((prp.id = prikaz.prp_id)))
     LEFT JOIN psn_doc_confirm dc ON ((dc.kpy_id = kpy.id)))
     JOIN psn_prev_work pw ON ((pw.kpy_id = kpy.id)))
     JOIN ref_dict_line puv ON (((puv.id = pw.puv_id) AND (pw.is_last IS TRUE))))
  WHERE (((prkz_dict.code)::text = '4'::text) AND ((stp.code)::text = '1'::text) AND (((prp.code)::text <> ALL (ARRAY[('09'::character varying)::text, ('10'::character varying)::text, ('11'::character varying)::text])) OR (((prp.code)::text = '09'::text) AND (dc.id IS NULL))));
