CREATE VIEW rpt_kpy_tbl694_03 AS SELECT DISTINCT kpy.id,
    kpy.version,
    kpy.close_date,
    kpy.doc_date,
    kpy.num,
    kpy.obr_date,
    kpy.pz_close_date,
    kpy.szn_rec_id,
    kpy.close_rsn_id,
    kpy.pers_id,
    kpy.pz_close_rsn_id,
    kpy.szn_dep_id,
    prikaz.order_num,
    prikaz.order_date,
    prikaz.summ,
    prikaz.start_date,
    prikaz.end_date,
    concat_ws(' '::text, pers.last_name, pers.first_name, pers.middle_name) AS fio,
    rgn.name AS rgn_name,
    NULL::bigint AS career_id,
    NULL::bigint AS info_id,
    NULL::bigint AS pob_id,
    rgn.id AS rgn_id
   FROM ((((((((((psn_kpy kpy
     JOIN ref_szn szn ON ((szn.id = kpy.szn_dep_id)))
     JOIN ref_rgn rgn ON ((rgn.id = szn.rgn_id)))
     JOIN psn_person pers ON ((pers.id = kpy.pers_id)))
     JOIN psn_order prikaz ON ((prikaz.kpy_id = kpy.id)))
     JOIN ref_dict_line prikaz_prkz ON (((prikaz_prkz.id = prikaz.prkz_id) AND ((prikaz_prkz.code)::text = ANY (ARRAY[('8'::character varying)::text, ('10'::character varying)::text, ('23'::character varying)::text, ('26'::character varying)::text])))))
     LEFT JOIN ref_dict_line rshs ON (((prikaz.rshs_id = rshs.id) AND ((rshs.code)::text <> 'O'::text))))
     LEFT JOIN psn_order prikaz_parent ON ((prikaz_parent.parent_id = prikaz.id)))
     LEFT JOIN ref_dict_line prikaz_rshs ON (((prikaz_parent.rshs_id = prikaz_rshs.id) AND ((prikaz_rshs.code)::text = 'O'::text))))
     LEFT JOIN psn_order prikaz12 ON ((prikaz12.kpy_id = kpy.id)))
     LEFT JOIN ref_dict_line prikaz_12 ON (((prikaz_12.id = prikaz12.prkz_id) AND ((prikaz_12.code)::text = '12'::text))))
  WHERE ((prikaz.start_date < prikaz12.start_date) OR (prikaz.start_date > ((now())::timestamp without time zone + '2 years 1 mon'::interval)));
