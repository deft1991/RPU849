CREATE MATERIALIZED VIEW rpt_vac_tbl1150 AS SELECT vac.id,
    vac.version,
    szn.name AS szn,
    rgn.name AS rgn,
    rgn.id AS rgnid,
    vac.prof_name AS profname,
    vac.num,
    vac.needed,
    COALESCE(rgn2.name, rgn.name) AS workplacergn,
    loc.name AS locname,
    vac.reg_date AS regdate,
    vac.close_date AS closedate,
    vac.approve_date AS approvedate,
    org.name AS orgname,
    vac.salary_from AS salaryfrom,
    vac.salary_to AS salaryto,
    vac.employed
   FROM ((((((((obv_vacancy vac
     LEFT JOIN ref_szn szn ON ((szn.id = vac.szn_id)))
     LEFT JOIN ref_rgn rgn ON ((rgn.id = szn.rgn_id)))
     LEFT JOIN ref_dict_line dict_vrm_line ON (((vac.vrm_id = dict_vrm_line.id) AND (dict_vrm_line.dict_id = ( SELECT ref_dict.id
           FROM ref_dict
          WHERE ((ref_dict.code)::text = 'ВРМ'::text))))))
     LEFT JOIN obv_vacancy_kvt vac_kvt ON ((vac_kvt.vacancy_id = vac.id)))
     LEFT JOIN ref_dict_line dict_kvt_line ON (((vac_kvt.kvt_id = dict_kvt_line.id) AND (dict_kvt_line.dict_id = ( SELECT ref_dict.id
           FROM ref_dict
          WHERE ((ref_dict.code)::text = 'КВТ'::text))))))
     LEFT JOIN obv_locality loc ON ((vac.locality_id = loc.region_id)))
     LEFT JOIN ref_rgn rgn2 ON ((rgn2.id = loc.region_id)))
     LEFT JOIN obv_org org ON ((org.id = vac.org_id)))
  WHERE (((vac.close_date IS NULL) OR (vac.close_date >= ('now'::text)::date)) AND (vac.needed > 0) AND ((((dict_vrm_line.code)::text = 'К'::text) AND ((dict_kvt_line.code)::text = '08'::text)) OR ((dict_vrm_line.code)::text = 'И'::text)));
