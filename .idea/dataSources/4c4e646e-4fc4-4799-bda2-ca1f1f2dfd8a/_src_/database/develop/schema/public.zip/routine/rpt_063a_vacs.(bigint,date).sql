create function rpt_063a_vacs(vacs_id bigint, dateto date) returns TABLE(id bigint, reg_date date, grf_1 character varying, grf_2 character varying, grf_3 text, grf_4 text, average numeric, org_id bigint, prof_name character varying, init_need_no integer)
LANGUAGE plpgsql
AS $$
BEGIN

            DROP TABLE IF EXISTS vacs_by_id_temp;
            CREATE TEMP TABLE vacs_by_id_temp AS
            SELECT v.* from lgl_vacancy v where v.id = vacs_id;


            DROP TABLE IF EXISTS vacs_primary_temp;
            CREATE TEMP TABLE vacs_primary_temp AS
            SELECT
            vacs.id,
            vacs.reg_date,
            case
            when grf.code in ('Д','Н','Ч','Ю') then grf.name
            when grf.code in ('С1','Л5','Л6') then 'Полный рабочий день'
            when grf.code in ('Б','В','Е') then 'Гибкий режим работы'
            else NULL
            end as grf_1,
            case
            when grf.code in ('Г','С2','С3','У2','У3') then grf.name
            else NULL
            end as grf_2,
            case
            when grf.code in ('М') then 'занят'
            else NULL
            end grf_3,
            case
            when grf.code in ('И') then 'дистанционная занятость'
            else NULL
            end grf_4,
            (zp_from + zp_to) / 2 as average,
            vacs.org_id,
            vacs.prof_name,
            vacs.init_need_no,
            vacs.prof_id,
            vacs.prz_id
            from vacs_by_id_temp vacs
            JOIN ref_dict_line vrm on vrm.id = vacs.vrm_id
            JOIN lgl_vacancy_quota quota on quota.vacancy_id = vacs.id
            LEFT JOIN ref_dict_line kvt on kvt.id = quota.kvt_id and kvt.code = '08'
            LEFT JOIN ref_dict_line grf on grf.id = vacs.grf_id
            where (vrm.code = 'И' or (vrm.code = 'К' and kvt.id IS NOT NULL)) and dateTo >= vacs.reg_date;


            RETURN QUERY SELECT
            vacs.id,
            vacs.reg_date,
            case
            when grf.code in ('Д','Н','Ч','Ю') then grf.name
            when grf.code in ('С1','Л5','Л6') then 'Полный рабочий день'
            when grf.code in ('Б','В','Е') then 'Гибкий режим работы'
            else NULL
            end as grf_1,
            case
            when grf.code in ('Г','С2','С3','У2','У3') then grf.name
            else NULL
            end as grf_2,
            case
            when grf.code in ('М') then 'занят'
            else NULL
            end grf_3,
            case
            when grf.code in ('И') then 'дистанционная занятость'
            else NULL
            end grf_4,
            (zp_from + zp_to) / 2 as average,
            vacs.org_id,
            vacs.prof_name,
            vacs.init_need_no
            from lgl_vacancy vacs
            JOIN ref_dict_line vrm on vrm.id = vacs.vrm_id
            JOIN lgl_vacancy_quota quota on quota.vacancy_id = vacs.id
            LEFT JOIN ref_dict_line kvt on kvt.id = quota.kvt_id and kvt.code = '08'
            LEFT JOIN ref_dict_line grf on grf.id = vacs.grf_id
            FULL JOIN vacs_primary_temp vacs_p on vacs_p.org_id = vacs.org_id and vacs_p.prof_id = vacs.prof_id and vacs_p.prz_id = vacs.prz_id
            where (vrm.code = 'ИП' or (vrm.code = 'К' and kvt.id IS NOT NULL)) and dateTo >= vacs.reg_date;

            DROP TABLE IF EXISTS vacs_by_id_temp;
            DROP TABLE IF EXISTS vacs_primary_temp;
            END;
$$;
