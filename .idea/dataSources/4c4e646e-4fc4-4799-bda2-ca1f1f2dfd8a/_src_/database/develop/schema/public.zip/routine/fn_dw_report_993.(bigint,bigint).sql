create function fn_dw_report_993(p_rgn_id bigint, p_szn_id bigint) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
			BEGIN
			DELETE FROM dw_rep993
			WHERE 1 = 1
			AND szn_id = coalesce(p_szn_id, szn_id)
			AND rgn_id = coalesce(p_rgn_id, rgn_id)
			;
			BEGIN
			DELETE FROM tmp_dw_report_993;
			EXCEPTION
			WHEN others THEN
			create temporary table tmp_dw_report_993(
			id bigserial
			, marker      int8
			, kpy_id      int8
			, order_id    int8
			, order_date  date
			, order2_id   int8
			, order2_date date
			, ord         int4
			);
			END;
			-- Действующие на конец периода приказы "Назначить"
			INSERT INTO tmp_dw_report_993(
			marker
			, kpy_id
			, order_id
			, ord
			)
			SELECT
			1
			, kpy.id
			, ord.id
			, ROW_NUMBER() OVER(PARTITION BY kpy.id ORDER BY ord.order_date ASC)
			FROM psn_kpy kpy
			INNER JOIN ref_szn szn ON szn.id = kpy.szn_dep_id
			INNER JOIN ref_rgn rgn ON rgn.id = szn.rgn_id
			INNER JOIN psn_order ord ON ord.kpy_id = kpy.id
			AND EXISTS (SELECT null FROM ref_dict_line prkz WHERE prkz.code IN ('1', '7')  AND prkz.id = ord.prkz_id)
			AND EXISTS (SELECT null FROM ref_dict_line stp WHERE stp.code = '1' AND stp.id = coalesce(ord.status_id, stp.id))
			LEFT JOIN psn_order ord_e ON ord_e.kpy_id = kpy.id
			AND ord_e.parent_id = ord.id
			AND ord_e.start_date > current_date
			AND EXISTS (SELECT null FROM ref_dict_line rshs_e WHERE rshs_e.id = ord_e.rshs_id AND rshs_e.code = 'Е')
			WHERE 1 = 1
			AND szn.id = coalesce(p_szn_id, szn.id)
			--AND kpy.id IN (3705070822, 4188167822, 4196223322, 5118359522)
			AND rgn.id = coalesce(p_rgn_id, rgn.id)
			AND ord.order_date <= current_date
			AND ord_e.id IS NULL
			;
			--
			INSERT INTO tmp_dw_report_993(
			marker
			, kpy_id
			, order_id
			, order_date
			, order2_id
			, order2_date
			, ord
			)
			SELECT
			2
			, ord.kpy_id
			, ord.id
			, ord.order_date
			, ord_i.id
			, ord_i.order_date
			, ROW_NUMBER() OVER(PARTITION BY ord.kpy_id ORDER BY ord_i.order_date DESC)
			FROM tmp_dw_report_993 t
			INNER JOIN psn_order ord ON ord.id = t.order_id
			AND EXISTS (SELECT null FROM ref_dict_line stp WHERE stp.code = '1' AND stp.id = coalesce(ord.status_id, stp.id))
			LEFT JOIN psn_order ord_i ON ord_i.kpy_id = ord.kpy_id
			AND ord_i.parent_id = ord.id
			AND EXISTS (SELECT null FROM ref_dict_line rshs_e WHERE rshs_e.id = ord_i.rshs_id AND rshs_e.code IN ('ПИ', 'У'))
			AND ord_i.order_date < current_date
						WHERE 1 = 1
			AND t.marker = 1
			AND t.ord = 1
			AND ord.order_date <= current_date
			;
			--
			INSERT INTO tmp_dw_report_993(
			marker
			, kpy_id
			, order_id
			, order_date
			, order2_id
			, order2_date
			)
			SELECT
			3
			, t.kpy_id
			, t.order_id
			, t.order_date
			, coalesce(t.order2_id, t.order_id)
			, coalesce(t.order2_date , t.order_date)
			FROM tmp_dw_report_993 t
			WHERE 1 = 1
			AND t.marker = 2
			AND t.ord = 1
			;
			--
			INSERT INTO dw_rep993(
			szn_id -- СЗН
			, rgn_id -- Регион
			, kpy_num -- КПУ
			, fio -- ФИО
			, obr_date -- Дата обращения
			, kng_id -- Категория незанятости
			, tpr_id -- Категория испытывающего трудности в поисках работы
			, puv_id -- Причина увольнения
			, order_num -- Номер приказа
			, algo_id -- Алгоритм расчета
			, count_week -- Количество недель
			, report_year -- Отчетный период
			, report_month -- Отчетный месяц
			, сnt -- Мера
			)
			SELECT
			coalesce(szn.id, 0) AS szn_id -- СЗН
			, coalesce(rgn.id, 0) AS rgn_id -- Регион
			, coalesce(kpy.num, '') as kpy_num -- КПУ
			, coalesce(pers.last_name || ' ' || pers.first_name || ' ' || pers.middle_name, '') as fio -- ФИО
			, kpy.obr_date AS obr_date -- Дата обращения
			, coalesce(kpy_kng.kng_id, 0) AS kng_id -- Категория незанятости
			, coalesce(jsp.tpr_id, 0) AS tpr_id -- Категория испытывающего трудности в поисках работы
			, coalesce(prw.puv_id, 0) AS puv_id -- Причина увольнения
			, coalesce(ord.order_num, '') AS order_num -- Номер приказа
			, coalesce(ord.algo_id, 0) AS algo_id -- Алгоритм расчета
			, inf.last_year_staj AS count_week -- Количество недель
			, to_char(ord.order_date, 'YYYY')::int4 AS report_year -- Отчетный период
			, to_char(ord.order_date, 'MM')::int4 AS report_month -- Отчетный месяц
			, 1 AS cnt -- Мера
			FROM tmp_dw_report_993 t
			INNER JOIN psn_order ord ON ord.id = t.order2_id
			AND EXISTS (SELECT null FROM ref_dict_line rshs WHERE rshs.id = ord.rshs_id AND rshs.code = 'П')
			AND EXISTS (SELECT null FROM ref_dict_line stp WHERE stp.code = '1' AND stp.id = coalesce(ord.status_id, stp.id))
			AND EXISTS (SELECT null FROM ref_dict_line alg WHERE alg.code != 'П1' AND alg.id = ord.algo_id)
			INNER JOIN psn_kpy kpy ON kpy.id = t.kpy_id
			INNER JOIN psn_person pers ON pers.id = kpy.pers_id
			INNER JOIN ref_szn szn ON szn.id = kpy.szn_dep_id
			INNER JOIN ref_rgn rgn ON rgn.id = szn.rgn_id
			INNER JOIN psn_kpy_info inf ON inf.id = kpy.info_id
			INNER JOIN ref_dict_line kzf ON kzf.id = inf.kzf_id
			INNER JOIN psn_kng kpy_kng ON kpy_kng.kpy_id = kpy.id
			AND EXISTS (SELECT null FROM ref_dict_line kng WHERE kng.code NOT IN ('04', '08', '07', '28') AND kng.id = kpy_kng.kng_id)
			INNER JOIN psn_job_search_problem jsp ON jsp.kpy_id = kpy.id
			AND EXISTS (SELECT null FROM ref_dict_line tpr WHERE tpr.code NOT IN ('Щ', 'ЗЧ') AND tpr.id = jsp.tpr_id)
			INNER JOIN psn_prev_work prw ON prw.kpy_id = kpy.id AND prw.is_last = true
			AND EXISTS (SELECT null FROM ref_dict_line puv WHERE puv.code NOT LIKE 'Д%' AND puv.id = prw.puv_id)
			WHERE 1 = 1
			AND t.marker = 3
			AND ord.order_date >= to_date('01.01.2014','DD.MM.YYYY')
			AND inf.zp IS NOT NULL
			AND coalesce(inf.last_year_staj, 0) > 26
			AND NOT EXISTS (
			SELECT null
			FROM dual
			WHERE 1 = 1
			AND kzf.code = '01'
			AND DATE_PART('year', kpy.obr_date) - DATE_PART('year', prw.end_date) > 1
			)
			AND (inf.zp * 0.75) > (850 * coalesce(ord.region_coeff, 1))
			;
			return true;
			--
			END;
$$;
