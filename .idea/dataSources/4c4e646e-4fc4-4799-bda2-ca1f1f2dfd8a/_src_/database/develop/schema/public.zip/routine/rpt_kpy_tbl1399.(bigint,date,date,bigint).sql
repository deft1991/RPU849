create function rpt_kpy_tbl1399(p_rgn_id bigint, p_start_date date, p_finish_date date, p_duration bigint) returns TABLE(id bigint, version bigint, doc_date date, num character varying, obr_date date, pz_close_date date, szn_rec_id character varying, close_rsn_id bigint, pers_id bigint, pz_close_rsn_id bigint, szn_dep_id bigint, close_date date, sys_id character varying, career_id bigint, info_id bigint, pob_id bigint, is_ref_direct boolean, sent_by character varying, unempl_date date, kpy_id bigint, duration bigint, fio character varying, szn character varying, rgn character varying, tpr character varying, kzf character varying)
LANGUAGE SQL
AS $$
SELECT
					kpy.id, kpy.version, kpy.doc_date, kpy.num, kpy.obr_date, kpy.pz_close_date, kpy.szn_rec_id,
					kpy.close_rsn_id, kpy.pers_id, kpy.pz_close_rsn_id, kpy.szn_dep_id, kpy.close_date,
					kpy.sys_id, kpy.career_id, kpy.info_id, kpy.pob_id, kpy.is_ref_direct, kpy.sent_by, kpy.unempl_date,
					t.kpy_id,
					t.duration,
					concat(pers.last_name, ' ', pers.first_name, ' ', pers.middle_name) AS fio,
					szn.name AS szn,
					rgn.name AS rgn,
					tpr.name AS tpr,
					kzf.name AS kzf
					from kpy_tbl1399(
					p_rgn_id,
					null,
					p_start_date,
					p_finish_date,
					p_duration
					) t
					LEFT JOIN psn_kpy kpy on kpy.id = t.kpy_id
					LEFT JOIN psn_person pers ON kpy.pers_id = pers.id
					LEFT JOIN ref_szn szn ON szn.id = kpy.szn_dep_id
					LEFT JOIN ref_rgn rgn ON rgn.id = szn.rgn_id
					LEFT JOIN psn_kpy_info p_info ON kpy.info_id = p_info.id
					LEFT JOIN ref_dict_line kzf ON p_info.kzf_id = kzf.id
					LEFT JOIN psn_job_search_problem dfj ON dfj.kpy_id = kpy.id
					LEFT JOIN ref_dict_line tpr ON tpr.id = dfj.tpr_id

$$;
