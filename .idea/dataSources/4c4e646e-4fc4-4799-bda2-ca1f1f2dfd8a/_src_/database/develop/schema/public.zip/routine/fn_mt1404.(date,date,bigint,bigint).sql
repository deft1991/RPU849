create function fn_mt1404(datefrom date, dateto date, rgnid bigint, fdoid bigint) returns TABLE(rgnname character varying, fdoname character varying, cnt_inv_total bigint, cnt_inv_1gr bigint, cnt_inv_2gr bigint, cnt_inv_3gr bigint, cnt_inv_job bigint, cnt6 bigint, cnt7 bigint, cnt8 bigint, cnt9 bigint, cnt10 bigint, cnt11 bigint, cnt12 bigint, cnt13 bigint, cnt14 bigint, cnt15 bigint)
LANGUAGE SQL
AS $$
SELECT
			rgn_name,
			fdo_name,
			COUNT(distinct inv_total) as cnt_inv_total,
			COUNT(distinct inv_1gr) as cnt_inv_1gr,
			COUNT(distinct inv_2gr) as cnt_inv_2gr,
			COUNT(distinct inv_3gr) as cnt_inv_3gr,
			COUNT(distinct inv_job) as cnt_inv_job,
			COUNT(distinct case when ((vac_tzn.code not in ('В','З','С')) or (job_tzn.code not in ('В','З','С'))) then inv_job else null end) as cnt6,
			COUNT(distinct case when ((vac_tzn.code not in ('В','З','С')) or (job_tzn.code not in ('В','З','С'))  and gin_code = '1') then inv_job else null end) as cnt7,
			COUNT(distinct case when ((vac_tzn.code not in ('В','З','С')) or (job_tzn.code not in ('В','З','С'))) and vac_vrm.code in ('И','ИП') and gin_code = '1' then inv_job else null end) as cnt8,
			COUNT(distinct case when ((vac_tzn.code not in ('В','З','С')) or (job_tzn.code not in ('В','З','С'))) and vac_vrm.code = 'К' and gin_code = '1' then inv_job else null end) as cnt9,
			COUNT(distinct case when ((vac_tzn.code not in ('В','З','С')) or (job_tzn.code not in ('В','З','С'))  and gin_code = '2') then inv_job else null end) as cnt10,
			COUNT(distinct case when ((vac_tzn.code not in ('В','З','С')) or (job_tzn.code not in ('В','З','С'))) and vac_vrm.code in ('И','ИП') and gin_code = '2' then inv_job else null end) as cnt11,
			COUNT(distinct case when ((vac_tzn.code not in ('В','З','С')) or (job_tzn.code not in ('В','З','С'))) and vac_vrm.code = 'К' and gin_code = '2' then inv_job else null end) as cnt12,
			COUNT(distinct case when ((vac_tzn.code not in ('В','З','С')) or (job_tzn.code not in ('В','З','С'))  and gin_code = '3') then inv_job else null end) as cnt13,
			COUNT(distinct case when ((vac_tzn.code not in ('В','З','С')) or (job_tzn.code not in ('В','З','С'))) and vac_vrm.code in ('И','ИП') and gin_code = '3' then inv_job else null end) as cnt14,
			COUNT(distinct case when ((vac_tzn.code not in ('В','З','С')) or (job_tzn.code not in ('В','З','С'))) and vac_vrm.code = 'К' and gin_code = '3' then inv_job else null end) as cnt15
			FROM
			(SELECT
			rgn.name AS rgn_name
			, rgn.sorting_order AS rng_sorting_order
			, fdo.name AS fdo_name
			, fdo.sorting_order AS fdo_sorting_order
			, gin.code AS gin_code
			, case when kpy.obr_date between datefrom and dateto AND ipra.gin_id is not null then kpy.id else null end AS inv_total
			, case when kpy.obr_date between datefrom and dateto AND ipra.gin_id is not null and gin.code = '1' then kpy.id else null end AS inv_1gr
			, case when kpy.obr_date between datefrom and dateto AND ipra.gin_id is not null and gin.code = '2' then kpy.id else null end AS inv_2gr
			, case when kpy.obr_date between datefrom and dateto AND ipra.gin_id is not null and gin.code = '3' then kpy.id else null end AS inv_3gr
			, case when ((ipra.gin_id is not null
			or jsp_tpr.code = '1' or ipra.ppi_id is not null
			or ipra.invalid_Year is not null or ipra.end_date is not null)
			and (job.start_Date between datefrom and dateto)) then kpy.id else null end AS inv_job
			FROM psn_kpy kpy
			INNER JOIN ref_dict_line pob ON pob.id = kpy.pob_id
			INNER JOIN psn_ipra ipra on ipra.kpy_id = kpy.id
			INNER JOIN ref_dict_line gin ON gin.id = ipra.gin_id
			INNER JOIN ref_szn szn ON szn.id = kpy.szn_dep_id
			INNER JOIN ref_rgn rgn ON rgn.id = szn.rgn_id
			INNER JOIN ref_fdo fdo on fdo.id = rgn.fdo_id
			LEFT JOIN psn_job_search_problem jsp on jsp.kpy_id = kpy.id
			LEFT JOIN ref_dict_line jsp_tpr ON jsp_tpr.id = jsp.tpr_id
			LEFT JOIN psn_job job ON job.kpy_id = kpy.id
			WHERE
			kpy.obr_date between datefrom and dateto
			AND pob.code = '1'
			AND rgn.id = COALESCE(rgnid, rgn.id)
			AND fdo.id = COALESCE(fdoid, fdo.id)
			)t
			LEFT JOIN psn_job job ON job.kpy_id = inv_job
			LEFT JOIN ref_dict_line job_tzn ON job_tzn.id = job.tzn_id
			LEFT JOIN lgl_vacancy vac on vac.id = job.vacancy_id
			LEFT JOIN ref_dict_line vac_tzn ON vac_tzn.id = vac.tzn_id
			LEFT JOIN ref_dict_line vac_vrm ON vac_vrm.id = vac.vrm_id
			GROUP BY rgn_name, fdo_name, rng_sorting_order, fdo_sorting_order
			ORDER BY rng_sorting_order, fdo_sorting_order


$$;
