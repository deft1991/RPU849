CREATE MATERIALIZED VIEW rpt_kpy_tbl1270 AS SELECT kpy.id,
    kpy.version,
    kpy.doc_date,
    kpy.num,
    kpy.obr_date,
    kpy.pz_close_date,
    kpy.szn_rec_id,
    kpy.close_rsn_id,
    kpy.pers_id,
    kpy.pz_close_rsn_id,
    kpy.szn_dep_id,
    kpy.close_date,
    kpy.sys_id,
    kpy.career_id,
    kpy.info_id,
    kpy.pob_id,
    kpy.id AS kpy_id,
    concat(pers.last_name, ' ', pers.first_name, ' ', pers.middle_name) AS fio,
    szn.name AS szn,
    rgn.name AS rgn,
    pers.birth_date,
    ( SELECT tpr.name
           FROM psn_job_search_problem dfj,
            ref_dict_line tpr
          WHERE ((dfj.kpy_id = kpy.id) AND (tpr.id = dfj.tpr_id))
         LIMIT 1) AS tpr,
    kzf.name AS kzf,
    rgn.id AS rgn_id,
    ((paid_sum.oper_date)::date - add_hold_sum.oper_date) AS date_diff,
    add_hold_sum.oper_date,
    concat(to_char((pp.start_date)::timestamp with time zone, 'dd.MM.yyyy'::text), ' - ', to_char((pp.end_date)::timestamp with time zone, 'dd.MM.yyyy'::text)) AS period,
    scv.name AS scv_name
   FROM (((((((((((((psn_kpy kpy
     JOIN psn_order prikaz ON ((prikaz.kpy_id = kpy.id)))
     JOIN psn_person pers ON ((pers.id = kpy.pers_id)))
     JOIN psn_soc_payment_card p_pmnts_card ON ((prikaz.id = p_pmnts_card.order_id)))
     JOIN psn_soc_payment_period pp ON ((p_pmnts_card.id = pp.soc_pmnts_card_id)))
     JOIN psn_soc_payment_sum add_hold_sum ON ((add_hold_sum.pmnts_period_id = pp.id)))
     JOIN psn_soc_payment_sum_paid paid_sum ON ((paid_sum.pmnts_period_id = pp.id)))
     JOIN ref_szn szn ON ((kpy.szn_dep_id = szn.id)))
     JOIN ref_rgn rgn ON ((szn.rgn_id = rgn.id)))
     JOIN ref_dict_line tnch ON (((tnch.id = add_hold_sum.tnch_id) AND ((tnch.code)::text <> ALL (ARRAY[('Н'::character varying)::text, ('О'::character varying)::text])))))
     JOIN ref_dict_line vnu ON (((vnu.id = add_hold_sum.vnu_id) AND ((vnu.code)::text = ANY (ARRAY[('Б'::character varying)::text, ('И'::character varying)::text, ('Р'::character varying)::text, ('Ч'::character varying)::text, ('Н'::character varying)::text])))))
     JOIN psn_kpy_info inf ON ((inf.id = kpy.info_id)))
     LEFT JOIN ref_dict_line kzf ON ((kzf.id = inf.kzf_id)))
     LEFT JOIN ref_dict_line scv ON ((scv.id = prikaz.scv_id)))
  WHERE ((pp.is_recalc IS NULL) OR ((pp.is_recalc = false) AND (add_hold_sum.summ > (0)::numeric) AND (add_hold_sum.oper_date < paid_sum.oper_date)));
