CREATE MATERIALIZED VIEW vm_rpt_kpy_tbl1290_kpy AS SELECT kpy.id AS kpy_id,
    kpy.close_date,
    kpy.szn_dep_id AS szn_id,
    ord.id AS ord_id,
    ord.start_date
   FROM (((psn_kpy kpy
     JOIN psn_job job ON (((job.kpy_id = kpy.id) AND (job.start_date IS NOT NULL) AND (job.end_date IS NOT NULL))))
     JOIN psn_order ord ON ((ord.kpy_id = kpy.id)))
     JOIN ref_dict_line prkz ON (((prkz.id = ord.prkz_id) AND ((prkz.code)::text = ANY (ARRAY[('1'::character varying)::text, ('7'::character varying)::text])))))
UNION
 SELECT kpy.id AS kpy_id,
    kpy.close_date,
    kpy.szn_dep_id AS szn_id,
    ord.id AS ord_id,
    ord.start_date
   FROM (((psn_kpy kpy
     JOIN psn_order ord ON (((ord.kpy_id = kpy.id) AND (ord.start_date IS NOT NULL) AND (ord.end_date IS NOT NULL))))
     JOIN ref_dict_line stp ON (((stp.id = ord.status_id) AND ((stp.code)::text = ANY (ARRAY[('1'::character varying)::text, ('2'::character varying)::text])))))
     JOIN ref_dict_line prkz ON (((prkz.id = ord.prkz_id) AND ((prkz.code)::text = ANY (ARRAY[('3'::character varying)::text, ('4'::character varying)::text])))))
UNION
 SELECT kpy.id AS kpy_id,
    kpy.close_date,
    kpy.szn_dep_id AS szn_id,
    oord.id AS ord_id,
    oord.start_date
   FROM ((psn_kpy kpy
     JOIN psn_order oord ON ((oord.kpy_id = kpy.id)))
     JOIN ref_dict_line prkz ON (((prkz.id = oord.prkz_id) AND ((prkz.code)::text = ANY (ARRAY[('1'::character varying)::text, ('7'::character varying)::text])))))
  WHERE ((NOT (EXISTS ( SELECT job.kpy_id
           FROM psn_job job
          WHERE ((job.start_date IS NOT NULL) AND (job.end_date IS NOT NULL) AND (job.kpy_id = kpy.id))))) AND (NOT (EXISTS ( SELECT ord.kpy_id
           FROM ((psn_order ord
             JOIN ref_dict_line stp ON (((stp.id = ord.status_id) AND ((stp.code)::text = ANY (ARRAY[('1'::character varying)::text, ('2'::character varying)::text])))))
             JOIN ref_dict_line prkz_1 ON (((prkz_1.id = ord.prkz_id) AND ((prkz_1.code)::text = ANY (ARRAY[('3'::character varying)::text, ('4'::character varying)::text])))))
          WHERE ((ord.kpy_id = kpy.id) AND (ord.start_date IS NOT NULL) AND (ord.end_date IS NOT NULL))))));
CREATE INDEX vm_tbl1290_kpy_index
  ON vm_rpt_kpy_tbl1290_kpy (kpy_id);
CREATE INDEX vm_tbl1290_szn_index
  ON vm_rpt_kpy_tbl1290_kpy (szn_id);
CREATE INDEX vm_tbl1290_order_index
  ON vm_rpt_kpy_tbl1290_kpy (ord_id);
