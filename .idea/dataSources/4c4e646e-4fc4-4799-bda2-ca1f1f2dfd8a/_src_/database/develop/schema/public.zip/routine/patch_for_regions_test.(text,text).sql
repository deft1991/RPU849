create function patch_for_regions_test(p_rgn_id text, p_szn_id text) returns void
LANGUAGE plpgsql
AS $$
DECLARE
BEGIN
DELETE FROM rpt_remote_control_detail
WHERE 1 = 1
      AND rgn_id = p_rgn_id
      AND szn_id = p_szn_id
;
-- 1270
INSERT INTO rpt_remote_control_detail(
  version
  , kpy_id
  , obr_date
  , report_name
  , rgn_id
  , szn_id
)
  SELECT
    f.version
    , f.kpy_id
    , f.oper_date
    , '1270'
    , p_rgn_id
    , p_szn_id
  FROM fn_report_1270(p_rgn_id, p_szn_id, null, null, null) f;
--
-- 811
INSERT INTO rpt_remote_control_detail(
  version
  , kpy_id
  , obr_date
  , report_name
  , rgn_id
  , szn_id
)
  SELECT
    f.version
    , f.kpy_id
    , f.oper_date
    , '811'
    , p_rgn_id
    , p_szn_id
  FROM fn_report_811(p_rgn_id, p_szn_id, null, null, null) f;
--
-- 1146
INSERT INTO rpt_remote_control_detail(
  version
  , kpy_id
  , obr_date
  , report_name
  , rgn_id
  , szn_id
)
  SELECT
    f.version
    , f.kpy_id
    , f.order_date
    , '1146'
    , p_rgn_id
    , p_szn_id
  FROM fn_report_1146(p_rgn_id, p_szn_id, null, null, null) f;
--
-- 1147
INSERT INTO rpt_remote_control_detail(
  version
  , kpy_id
  , obr_date
  , report_name
  , rgn_id
  , szn_id
)
  SELECT
    f.version
    , f.kpy_id
    , f.order_date
    , '1147'
    , p_rgn_id
    , p_szn_id
  FROM fn_report_1147(p_rgn_id, p_szn_id, null, null, null) f;
--
-- 1085
INSERT INTO rpt_remote_control_detail(
  version
  , kpy_id
  , obr_date
  , report_name
  , rgn_id
  , szn_id
)
  SELECT
    f.version
    , f.kpy_id
    , f.oper_date
    , '1085'
    , p_rgn_id
    , p_szn_id
  FROM fn_report_1085(p_rgn_id, p_szn_id, null, null, null) f;
--
-- 1086
INSERT INTO rpt_remote_control_detail(
  version
  , kpy_id
  , obr_date
  , report_name
  , rgn_id
  , szn_id
)
  SELECT
    f.version
    , f.kpy_id
    , f.oper_date
    , '1086'
    , p_rgn_id
    , p_szn_id
  FROM fn_report_1086(p_rgn_id, p_szn_id, null, null, null) f;
--
-- 1456
INSERT INTO rpt_remote_control_detail(
  version
  , kpy_id
  , obr_date
  , report_name
  , rgn_id
  , szn_id
)
  SELECT
    f.version
    , f.kpy_id
    , f.order_date
    , '1456'
    , p_rgn_id
    , p_szn_id
  FROM fn_report_1456(p_rgn_id, p_szn_id, null, null, null) f;
--
-- 1318
INSERT INTO rpt_remote_control_detail(
  version
  , kpy_id
  , obr_date
  , report_name
  , rgn_id
  , szn_id
)
  SELECT
    f.version
    , f.kpy_id
    , f.order_date
    , '1318'
    , p_rgn_id
    , p_szn_id
  FROM fn_report_1318(p_rgn_id, p_szn_id, null, null, null) f;
--
-- 1306
INSERT INTO rpt_remote_control_detail(
  version
  , kpy_id
  , obr_date
  , report_name
  , rgn_id
  , szn_id
)
  SELECT
    f.version
    , f.kpy_id
    , f.send_date
    , '1306'
    , p_rgn_id
    , p_szn_id
  FROM fn_report_1306(p_rgn_id, p_szn_id, null, null, null) f;
--
-- 1139
INSERT INTO rpt_remote_control_detail(
  version
  , kpy_id
  , obr_date
  , report_name
  , rgn_id
  , szn_id
)
  SELECT
    f.version
    , f.kpy_id
    , f.order_date
    , '1139'
    , p_rgn_id
    , p_szn_id
  FROM fn_report_1139(p_rgn_id, p_szn_id, null, null, null) f;
--
-- 1457
INSERT INTO rpt_remote_control_detail(
  version
  , kpy_id
  , obr_date
  , report_name
  , rgn_id
  , szn_id
)
  SELECT
    f.version
    , f.kpy_id
    , f.unempl_date
    , '1457'
    , p_rgn_id
    , p_szn_id
  FROM fn_report_1457(p_rgn_id, p_szn_id, null, null, null) f;
END;
$$;
