create function recreate_ref_prof() returns void
LANGUAGE plpgsql
AS $$
begin
  SET CONSTRAINTS ALL DEFERRED;
  create temporary table ref_prof_2 as select id from ref_prof;
  delete from ref_prof_2 p using (select distinct id from ref_prof_1) p1 where p1.id=p.id;
  delete from ref_prof p using ref_prof_2 p2 where p2.id=p.id;
END
$$;
