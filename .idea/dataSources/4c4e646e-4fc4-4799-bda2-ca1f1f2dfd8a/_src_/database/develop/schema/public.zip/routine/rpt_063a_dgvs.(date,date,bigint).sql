create function rpt_063a_dgvs(datefrom date, dateto date, region bigint) returns TABLE(id bigint, vacs_id bigint, dog_date date, cash_box_date date)
LANGUAGE plpgsql
AS $$
BEGIN
            RETURN QUERY SELECT
            distinct d.id,
            vc.vacancy_id,
            d.doc_date,
            pln.cash_box_date
            FROM lgl_contract d
            INNER JOIN ref_szn szn on szn.id = d.szn_id
            INNER JOIN ref_rgn rgn on rgn.id = szn.rgn_id
            INNER JOIN lgl_vacancy_contract vc on vc.contract_id = d.id
            LEFT JOIN lgl_plan_expense pln on pln.contract_id = d.id
            LEFT JOIN ref_dict_line szr on szr.id = pln.szr_id and szr.code = 'ОТИ'
            LEFT JOIN ref_dict_line tdg on tdg.id = d.tdg_id and tdg.code in ('Д', 'Р', 'И')
            LEFT JOIN ref_dict_line dgv on dgv.id = d.dgv_id and dgv.code in ('НИ', 'РАА', 'РАИ')

            WHERE d.doc_date > '01-01-2014'::date and d.doc_date <= dateTo and (d.doc_date + interval '1 year' > dateFrom);
            END;
$$;
