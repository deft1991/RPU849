create function fn_report_1139(p_rgn_id bigint, p_szn_id bigint, p_sid bigint, p_start_date date, p_finish_date date) returns TABLE(id bigint, kpy_id bigint, version bigint, doc_date date, num character varying, obr_date date, pz_close_date date, szn_rec_id character varying, close_rsn_id bigint, pers_id bigint, pz_close_rsn_id bigint, szn_dep_id bigint, close_date date, sys_id character varying, career_id bigint, info_id bigint, pob_id bigint, rgn_id bigint, kzf character varying, fio character varying, szn character varying, rgn character varying, staj bigint, vid_narusheniya character varying, obshiy_period bigint, period_viplaty bigint, period_prodleniya bigint, order_date date, age_on_order_date bigint, pol character varying, tpr character varying)
LANGUAGE plpgsql
AS $$
DECLARE
        r RECORD;
      BEGIN
      	-- ================================================================
      	-- DDL
      	-- ================================================================
      	BEGIN
      		DELETE FROM tmp_report_1139;
      	EXCEPTION
      	  WHEN others THEN
      		create temporary table tmp_report_1139(
      		  id bigserial
      		, version int8
      		, marker int8
      		, kpy_id int8
      		, pol_code varchar
      		, birth_date date
      		, insur_staj_years int8
      		, ord_date date
      		, reason varchar
      		, full_period int8
      		, pay_period int8
      		, feb29count int8
      		, age int8
      		, first_period int8
      		, prolong_period int8
      		, ord_end_date date
      		);
      	END;
           --
           IF p_sid IS NOT NULL THEN
      		-- ================================================================
      	     INSERT INTO tmp_report_1139(
      		  marker
      		, kpy_id
      		, version
      		, pol_code
      		, birth_date
      		, insur_staj_years
      		, ord_date
      		, reason
      		, full_period
      		, pay_period
      		, feb29count
      		, age
      		, first_period
      		, prolong_period
      		, ord_end_date
      		)
      		SELECT
      		  1
      		, kpy.id
      		, kpy.version
      		, pol.code AS pol_code
      		, pers.birth_date
      		, career.insur_staj_years
      		, ord_6.order_date
      		, null
      		, coalesce(ord_7.end_date, ord_6.end_date) - ord_1.start_date + 1  AS full_period
      		, ord_6.end_date - ord_1.start_date + 1 + coalesce(ord_7.end_date - ord_7.start_date + 1, 0) AS pay_period
      		, fn_count29feb(ord_1.start_date, ord_6.end_date) + fn_count29feb(ord_7.start_date, ord_7.end_date) AS feb29count
      		, fn_count_year(pers.birth_date, ord_6.order_date) as age
      		, ord_1.end_date - ord_1.start_date + 1 - fn_count29feb(ord_1.start_date, ord_1.end_date) AS first_period
      		, ord_6.end_date - ord_1.end_date AS prolong_period
      		, ord_6.end_date
      		FROM psn_kpy kpy
      		INNER JOIN rpt_param param ON param.num_value = kpy.id
      			AND param.sid = p_sid
      			AND param.report = '1139'
      			AND param.param = 'KPY_ID'
      		INNER JOIN psn_kpy_info info ON info.id = kpy.info_id
      		INNER JOIN ref_szn szn ON szn.id = kpy.szn_dep_id
      		INNER JOIN ref_rgn rgn ON rgn.id = szn.rgn_id
      		INNER JOIN psn_person pers ON pers.id = kpy.pers_id
      		LEFT JOIN ref_dict_line pol ON pol.id = pers.pol_id
      		LEFT JOIN psn_career career ON career.id = kpy.career_id
      		INNER JOIN psn_order ord_6 ON ord_6.kpy_id = kpy.id
      			AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line prkz WHERE dic.id = prkz.dict_id AND dic.code = 'ПРКЗ' AND prkz.code = '6' AND prkz.id = ord_6.prkz_id)
      			AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line stp WHERE dic.id = stp.dict_id AND dic.code = 'СТП' AND stp.code = '1' AND stp.id = coalesce(ord_6.status_id, stp.id))
      		INNER JOIN psn_order ord_1 ON ord_1.kpy_id = kpy.id
      			AND ord_1.id = ord_6.parent_id
      			AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line prkz WHERE dic.id = prkz.dict_id AND dic.code = 'ПРКЗ' AND prkz.code = '1' AND prkz.id = ord_1.prkz_id)
      			AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line stp WHERE dic.id = stp.dict_id AND dic.code = 'СТП' AND stp.code = '1' AND stp.id = coalesce(ord_1.status_id, stp.id))
      		LEFT JOIN psn_order ord_7 ON ord_7.kpy_id = kpy.id
      			AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line prkz WHERE dic.id = prkz.dict_id AND dic.code = 'ПРКЗ' AND prkz.code IN ('1', '7') AND prkz.id = ord_7.prkz_id)
      			AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line stp WHERE dic.id = stp.dict_id AND dic.code = 'СТП' AND stp.code = '1' AND stp.id = coalesce(ord_7.status_id, stp.id))
      			AND ord_7.id != ord_1.id
      			AND ord_7.order_date >= ord_1.order_date
      		WHERE 1 = 1
      		  AND szn.rgn_id = coalesce(p_rgn_id, szn.rgn_id)
      		  AND szn.id = coalesce(p_szn_id, szn.id)
      		  AND ord_6.order_date BETWEEN coalesce(p_start_date, ord_6.order_date) AND coalesce(p_finish_date, ord_6.order_date)
      		  AND ord_1.start_date <= ord_6.start_date
      		  AND ord_6.start_date <= ord_1.end_date + 1
      		  AND ord_6.end_date > ord_1.end_date
      		;
      		--
      		DELETE FROM rpt_param WHERE sid = p_sid AND report = '1139';
      		--
      	ELSE
      		--
      	     INSERT INTO tmp_report_1139(
      		  marker
      		, kpy_id
      		, version
      		, pol_code
      		, birth_date
      		, insur_staj_years
      		, ord_date
      		, reason
      		, full_period
      		, pay_period
      		, feb29count
      		, age
      		, first_period
      		, prolong_period
      		, ord_end_date
      		)
      		SELECT
      		  1
      		, kpy.id
      		, kpy.version
      		, pol.code AS pol_code
      		, pers.birth_date
      		, career.insur_staj_years
      		, ord_6.order_date
      		, null
      		, coalesce(ord_7.end_date, ord_6.end_date) - ord_1.start_date + 1  AS full_period
      		, ord_6.end_date - ord_1.start_date + 1 + coalesce(ord_7.end_date - ord_7.start_date + 1, 0) AS pay_period
      		, fn_count29feb(ord_1.start_date, ord_6.end_date) + fn_count29feb(ord_7.start_date, ord_7.end_date) AS feb29count
      		, fn_count_year(pers.birth_date, ord_6.order_date) as age
      		, ord_1.end_date - ord_1.start_date + 1 - fn_count29feb(ord_1.start_date, ord_1.end_date) AS first_period
      		, ord_6.end_date - ord_1.end_date AS prolong_period
      		, ord_6.end_date
      		FROM psn_kpy kpy
      		INNER JOIN psn_kpy_info info ON info.id = kpy.info_id
      		INNER JOIN ref_szn szn ON szn.id = kpy.szn_dep_id
      		INNER JOIN ref_rgn rgn ON rgn.id = szn.rgn_id
      		INNER JOIN psn_person pers ON pers.id = kpy.pers_id
      		LEFT JOIN ref_dict_line pol ON pol.id = pers.pol_id
      		LEFT JOIN psn_career career ON career.id = kpy.career_id
      		INNER JOIN psn_order ord_6 ON ord_6.kpy_id = kpy.id
      			AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line prkz WHERE dic.id = prkz.dict_id AND dic.code = 'ПРКЗ' AND prkz.code = '6' AND prkz.id = ord_6.prkz_id)
      			AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line stp WHERE dic.id = stp.dict_id AND dic.code = 'СТП' AND stp.code = '1' AND stp.id = coalesce(ord_6.status_id, stp.id))
      		INNER JOIN psn_order ord_1 ON ord_1.kpy_id = kpy.id
      			AND ord_1.id = ord_6.parent_id
      			AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line prkz WHERE dic.id = prkz.dict_id AND dic.code = 'ПРКЗ' AND prkz.code = '1' AND prkz.id = ord_1.prkz_id)
      			AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line stp WHERE dic.id = stp.dict_id AND dic.code = 'СТП' AND stp.code = '1' AND stp.id = coalesce(ord_1.status_id, stp.id))
      		LEFT JOIN psn_order ord_7 ON ord_7.kpy_id = kpy.id
      			AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line prkz WHERE dic.id = prkz.dict_id AND dic.code = 'ПРКЗ' AND prkz.code IN ('1', '7') AND prkz.id = ord_7.prkz_id)
      			AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line stp WHERE dic.id = stp.dict_id AND dic.code = 'СТП' AND stp.code = '1' AND stp.id = coalesce(ord_7.status_id, stp.id))
      			AND ord_7.id != ord_1.id
      			AND ord_7.order_date >= ord_1.order_date
      		WHERE 1 = 1
      		  AND szn.rgn_id = p_rgn_id
      		  AND szn.id = p_szn_id
      		  AND ord_1.start_date <= ord_6.start_date
      		  AND ord_6.start_date <= ord_1.end_date + 1
      		  AND ord_6.end_date > ord_1.end_date
      		;
      		--
      	END IF;
      	--
      	UPDATE tmp_report_1139
      	SET reason  = CASE
      				WHEN first_period <> 365 THEN 'Первый период выплаты не 12 месяцев'
      				WHEN age >= 60 AND pol_code = 'М' THEN 'Мужчина 60 лет и старше'
      				WHEN age >= 55 AND pol_code = 'Ж' THEN 'Женщина 55 лет и старше'
      				WHEN age < 60 AND pol_code = 'М' AND insur_staj_years < 25 THEN 'Cтаж менее 25 лет'
      				WHEN age < 55 AND pol_code = 'Ж' AND insur_staj_years < 20 THEN 'Cтаж менее 20 лет'
      				WHEN age < 60 AND pol_code = 'М' AND insur_staj_years >= 25 AND prolong_period <> 14 * (insur_staj_years - 25) THEN 'Мужчина, неверный период продления'
      				WHEN age < 55 AND pol_code = 'Ж' AND insur_staj_years >= 20 AND prolong_period <> 14 * (insur_staj_years - 20) THEN 'Женщина, неверный период продления'
      				WHEN ord_date IS NULL AND pay_period > 730 + feb29count AND full_period <= 1095 + feb29count THEN 'Период выплаты превысил 24 мес. в течение 36 мес., нет второго приказа о выплате'
      				WHEN ord_date IS NOT NULL AND pay_period > 730 + feb29count AND full_period <= 1095 + feb29count THEN 'Период выплаты превысил 24 мес. в течение 36 мес., есть второй приказ о выплате'
      				ELSE null
      			END
      	;
      	-- ИТОГ
      	FOR r IN (
      			SELECT
      			  t.kpy_id
      			, kpy.version AS version
      			, kpy.num AS kpy_num
      			, pers.last_name || ' ' || pers.first_name || ' ' || pers.middle_name as fio
      			, szn.name AS szn
      			, rgn.name AS rgn
      			, kpy.obr_date AS obr_date
      			, t.ord_date
      			, t.pol_code
      			, t.age
      			, t.insur_staj_years
      			, t.reason
      			, t.full_period
      			, t.pay_period
      			, t.prolong_period
      			, t4.cnt
      			, kzf.name AS kzf
      			, (SELECT kng.name FROM psn_kng tkng, ref_dict_line kng WHERE tkng.kpy_id = kpy.id AND kng.id = tkng.kng_id limit 1) AS kng
      			FROM tmp_report_1139 t
      			INNER JOIN psn_kpy kpy ON kpy.id = t.kpy_id --AND kpy.version = t.version
      			INNER JOIN ref_szn szn ON szn.id = kpy.szn_dep_id
      			INNER JOIN ref_rgn rgn ON rgn.id = szn.rgn_id
      			INNER JOIN psn_person pers ON pers.id = kpy.pers_id
      			INNER JOIN psn_kpy_info info ON info.id = kpy.info_id
      			LEFT JOIN ref_dict_line kzf ON kzf.id = info.kzf_id
      			INNER JOIN (
      				SELECT
      				  t3.kpy_id
      				, t3.cnt
      				, min(t3.id) AS id
      				FROM
      				(
      					SELECT
      					  t2.kpy_id
      					, t2.id
      					, t5.cnt
      					FROM
      					(
      						SELECT
      						  t1.kpy_id
      						, max(ord_end_date) AS ord_end_date
      						, count(1) AS cnt
      						FROM tmp_report_1139 t1
      						GROUP BY t1.kpy_id
      					) t5
      					INNER JOIN tmp_report_1139 t2 ON t2.kpy_id = t5.kpy_id
      						AND t2.ord_end_date = t5.ord_end_date
      				) t3
      				GROUP BY t3.kpy_id, t3.cnt
      			) t4 ON t4.kpy_id = t.kpy_id
      		  WHERE 1 = 1
      		    AND t.reason IS NOT NULL
      		 )
      	LOOP
      	  id := nextval('seq_mdn_kpy');
      	  kpy_id := r.kpy_id;
      	  version := r.version;
      	  num := r.kpy_num;
      	  obr_date := r.obr_date;
      	  fio := r.fio;
      	  szn := r.szn;
      	  rgn := r.rgn;
      	  kzf := r.kzf;
      	  tpr := r.kng;
      	  order_date := r.ord_date; -- дата приказа
      	  staj := r.insur_staj_years;
      	  vid_narusheniya := r.reason;
      	  age_on_order_date := r.age;
      	  pol := r.pol_code;
      	  obshiy_period := r.full_period;
      	  period_viplaty := r.pay_period;
      	  period_prodleniya := r.prolong_period;
      	  RETURN NEXT;
      	END LOOP;
      	--
      END;
$$;
