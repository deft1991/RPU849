CREATE VIEW rpt_kpy_tbl872 AS SELECT kpy.id,
    kpy.version,
    kpy.doc_date,
    kpy.num,
    kpy.obr_date,
    kpy.pz_close_date,
    kpy.szn_rec_id,
    kpy.close_rsn_id,
    kpy.pers_id,
    kpy.pz_close_rsn_id,
    kpy.szn_dep_id,
    kpy.close_date,
    kpy.sys_id,
    kpy.career_id,
    kpy.info_id,
    kpy.pob_id,
    concat(pers.last_name, ' ', pers.first_name, ' ', pers.middle_name) AS fio,
    szn.name AS szn,
    rgn.name AS rgn,
    prevwork.end_date,
    persinfo.last_year_staj,
        CASE
            WHEN ((prevwork.end_date IS NULL) OR (kpy.doc_date IS NULL) OR (kpy.doc_date >= (prevwork.end_date + 1))) THEN (0)::double precision
            ELSE date_part('day'::text, ((((prevwork.end_date)::timestamp without time zone - (kpy.doc_date + '1 year'::interval)) + '1 day'::interval) / (7)::double precision))
        END AS week_staj,
    rgn.id AS rgn_id
   FROM ((((((((psn_kpy kpy
     JOIN psn_order prikaz ON ((prikaz.kpy_id = kpy.id)))
     JOIN ref_dict_line prkz ON (((prkz.id = prikaz.prkz_id) AND ((prkz.code)::text = '1'::text))))
     JOIN ref_dict_line algo ON (((prkz.id = prikaz.algo_id) AND ((prkz.code)::text = 'П1'::text))))
     JOIN ref_szn szn ON ((kpy.szn_dep_id = szn.id)))
     JOIN ref_rgn rgn ON ((szn.rgn_id = rgn.id)))
     JOIN psn_person pers ON ((pers.id = kpy.pers_id)))
     JOIN psn_prev_work prevwork ON (((prevwork.kpy_id = kpy.id) AND (prevwork.is_last = true))))
     JOIN psn_kpy_info persinfo ON ((persinfo.id = kpy.info_id)))
  WHERE ((persinfo.last_year_staj >= 26) AND ((prevwork.end_date - '181 days'::interval) < (kpy.doc_date - '1 year'::interval)) AND (NOT (EXISTS ( SELECT prikazo.id
           FROM (psn_order prikazo
             JOIN ref_dict_line rshso ON (((prikazo.rshs_id = rshso.id) AND ((rshso.code)::text = 'О'::text))))
          WHERE (prikazo.parent_id = prikaz.id)))));
