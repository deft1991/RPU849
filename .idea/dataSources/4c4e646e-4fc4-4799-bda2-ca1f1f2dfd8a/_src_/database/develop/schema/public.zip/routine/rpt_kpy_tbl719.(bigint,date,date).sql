create function rpt_kpy_tbl719(p_rgn_id bigint, p_start_date date, p_finish_date date) returns TABLE(id bigint, version bigint, doc_date date, num character varying, obr_date date, pz_close_date date, szn_rec_id character varying, close_rsn_id bigint, pers_id bigint, pz_close_rsn_id bigint, szn_dep_id bigint, close_date date, sys_id character varying, career_id bigint, info_id bigint, pob_id bigint, fio character varying, szn character varying, rgn character varying, end_date date, order_date date, rgn_id bigint)
LANGUAGE SQL
AS $$
SELECT kpy.id,
		    kpy.version,
		    kpy.doc_date,
		    kpy.num,
		    kpy.obr_date,
		    kpy.pz_close_date,
		    kpy.szn_rec_id,
		    kpy.close_rsn_id,
		    kpy.pers_id,
		    kpy.pz_close_rsn_id,
		    kpy.szn_dep_id,
		    kpy.close_date,
		    kpy.sys_id,
		    kpy.career_id,
		    kpy.info_id,
		    kpy.pob_id,
		    concat(pers.last_name, ' ', pers.first_name, ' ', pers.middle_name) AS fio,
		    szn.name AS szn,
		    rgn.name AS rgn,
		    study.end_date,
		    prikaz2.order_date,
		    szn.rgn_id AS rgn_id
		   FROM psn_kpy kpy
		     JOIN vm_rpt_kpy_tbl719 prikaz1 ON prikaz1.kpy_id = kpy.id
		     LEFT JOIN vm_rpt_kpy_tbl719 prikaz2 ON prikaz2.kpy_id = kpy.id AND prikaz2.parent_id = prikaz1.id AND prikaz2.order_date = (
			SELECT MAX(prkz.order_date) FROM vm_rpt_kpy_tbl719 prkz WHERE prkz.kpy_id = kpy.id GROUP BY prkz.kpy_id
			)
		     JOIN psn_study study ON study.kpy_id = kpy.id AND study.end_date = (
			SELECT MAX(std.end_date) FROM psn_study std WHERE std.kpy_id = kpy.id GROUP BY std.kpy_id
			)
		     JOIN ref_szn szn ON kpy.szn_dep_id = szn.id AND szn.rgn_id = coalesce(p_rgn_id, szn.rgn_id)
		     JOIN ref_rgn rgn ON szn.rgn_id = rgn.id
		     JOIN psn_person pers ON pers.id = kpy.pers_id
		  WHERE prikaz2.order_date >
		        CASE
		            WHEN kpy.pz_close_date IS NOT NULL AND kpy.pz_close_date < study.end_date THEN kpy.pz_close_date
		            ELSE study.end_date
		        END
		        AND prikaz2.order_date BETWEEN p_start_date AND p_finish_date;


$$;
