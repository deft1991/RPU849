create function fn_max_age_child(p_kpy_id bigint, p_date date) returns bigint
LANGUAGE plpgsql
AS $$
DECLARE
        v_date date;
        v_max_dr date;
      BEGIN
           IF p_kpy_id IS NULL THEN return 0; END IF;
           --
           SELECT coalesce(p_date, kpy.obr_date)
           INTO v_date
           FROM psn_kpy kpy
           WHERE kpy.id = p_kpy_id;
           --
      	SELECT max(fam.birth_date)
      	INTO v_max_dr
      	FROM psn_person pers
      	INNER JOIN psn_kpy kpy ON kpy.pers_id = pers.id
      	INNER JOIN psn_family fam ON pers.id = fam.pers_id
           WHERE kpy.id = p_kpy_id;
           --
      	return fn_count_year(v_max_dr, v_date);
      	--
      END;
$$;
