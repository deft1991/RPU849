create function patch_for_regions(dbconn text, sql_text text) returns void
LANGUAGE plpgsql
AS $$
DECLARE
  r record;
BEGIN
  FOR r IN select datname from dblink(coalesce(dbconn,''),
      'SELECT datname FROM pg_database WHERE datistemplate = false and datname like ''region_%''') as (datname text)
  LOOP
    BEGIN
      RAISE INFO '% ..', r.datname;
      PERFORM dblink(coalesce(dbconn,'')||' dbname='||r.datname, 'DO $_$ BEGIN execute '''
        ||replace(replace(sql_text,'''',''''''),'$database$',r.datname)||'''; END $_$;');
    EXCEPTION WHEN syntax_error_or_access_rule_violation OR dependent_privilege_descriptors_still_exist THEN
      RAISE WARNING ' ERROR [%] %', SQLSTATE, SQLERRM;
      CONTINUE;
    END;
  END LOOP;
  RAISE INFO 'OK';
END;
$$;
