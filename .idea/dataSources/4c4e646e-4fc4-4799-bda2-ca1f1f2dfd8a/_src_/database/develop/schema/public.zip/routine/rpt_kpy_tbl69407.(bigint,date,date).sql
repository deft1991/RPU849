create function rpt_kpy_tbl69407(p_rgn_id bigint, p_start_date date, p_finish_date date) returns TABLE(id bigint, version bigint, doc_date date, num character varying, obr_date date, pz_close_date date, szn_rec_id character varying, close_rsn_id bigint, pers_id bigint, pz_close_rsn_id bigint, szn_dep_id bigint, close_date date, sys_id character varying, career_id bigint, info_id bigint, pob_id bigint, order_num character varying, order_date date, start_date date, end_date date, prkz character varying, summ numeric, fio character varying, szn character varying, rgn character varying)
LANGUAGE SQL
AS $$
SELECT kpy.id,
		    kpy.version,
		    kpy.doc_date,
		    kpy.num,
		    kpy.obr_date,
		    kpy.pz_close_date,
		    kpy.szn_rec_id,
		    kpy.close_rsn_id,
		    kpy.pers_id,
		    kpy.pz_close_rsn_id,
		    kpy.szn_dep_id,
		    kpy.close_date,
		    kpy.sys_id,
		    kpy.career_id,
		    kpy.info_id,
		    kpy.pob_id,
		    prikaz.order_num,
		    prikaz.order_date,
		    prikaz.start_date,
		    prikaz.end_date,
		    prkz.name AS prkz,
		    prikaz.summ,
		    concat(pers.last_name, ' ', pers.first_name, ' ', pers.middle_name) AS fio,
		    szn.name AS szn,
		    rgn.name AS rgn
		   FROM psn_kpy kpy
		     JOIN ref_szn szn ON kpy.szn_dep_id = szn.id AND szn.rgn_id = coalesce(p_rgn_id, szn.rgn_id)
		     JOIN ref_rgn rgn ON szn.rgn_id = rgn.id
		     JOIN psn_order prikaz ON prikaz.kpy_id = kpy.id
		     JOIN ref_dict_line rshs ON prikaz.rshs_id = rshs.id AND (rshs.code::text = ANY (ARRAY['Р'::character varying::text, 'К'::character varying::text, 'С'::character varying::text, 'Е'::character varying::text]))
		     LEFT JOIN ref_dict_line rshso ON prikaz.rshs_id = rshso.id AND rshso.code::text = 'O'::text
		     LEFT JOIN psn_order prikaz_parent ON prikaz.parent_id = prikaz_parent.id
		     LEFT JOIN ref_dict_line rshs_parent ON rshs_parent.id = prikaz_parent.prkz_id AND (rshs_parent.code::text = ANY (ARRAY['Р'::character varying::text, 'К'::character varying::text, 'С'::character varying::text, 'Е'::character varying::text]))
		     LEFT JOIN ref_dict_line tvs_parent ON tvs_parent.id = prikaz_parent.tvs_id AND rshs_parent.code::text = 'П'::text
		     LEFT JOIN ref_dict_line prkz ON prkz.id = prikaz.prkz_id
		     JOIN psn_person pers ON pers.id = kpy.pers_id
		  WHERE rshs_parent.id IS NULL
		     AND (prikaz_parent.* IS NULL OR tvs_parent.id IS NULL)
		     AND prikaz.order_date BETWEEN p_start_date AND p_finish_date;



$$;
