CREATE MATERIALIZED VIEW rpt_kpy_tbl1082 AS SELECT kpy.id,
    kpy.version,
    kpy.doc_date,
    kpy.num,
    kpy.obr_date,
    kpy.pz_close_date,
    kpy.szn_rec_id,
    kpy.close_rsn_id,
    kpy.pers_id,
    kpy.pz_close_rsn_id,
    kpy.szn_dep_id,
    kpy.close_date,
    kpy.sys_id,
    kpy.career_id,
    kpy.info_id,
    kpy.pob_id,
    ord.order_num,
    ord.start_date,
    ord.end_date,
    tvs.name AS tvs_name,
    rshs.name AS rshs_name,
    rshs.id AS rshs_id,
    prs.name AS prs_name,
    prs.id AS prs_id,
    kpy.num AS kpy_num,
    concat(p.last_name, ' ', p.first_name, ' ', p.middle_name) AS fio,
    ord.summ,
    ord.region_coeff,
    ord.order_date,
    ord.status_id,
    szn.name AS szn_name,
    szn.id AS szn_id,
    rgn.name AS rgn_name,
    rgn.id AS rgn_id,
    tpr.name AS tpr_name,
    ref_kng.name AS kng_name,
    fn_get_next_obr(kpy.id) AS next_obr,
    sys_talon.sys_updated,
    ref_algo.name AS algo,
    ref_algo.id AS algo_id,
    (date_part('year'::text, now()) - date_part('year'::text, p.birth_date)) AS age,
    study.start_date AS study_start_date,
    job.start_date AS job_start_date,
    prev_work.end_date AS pw_end_date,
    (ord.end_date - ord.start_date) AS ord_duration,
    p.birth_date,
    ord.staj_last_year,
    lim_max.name AS lim_max,
    lim_min.name AS lim_min,
    concat_ws(''::text, to_char((ord_info.start_date)::timestamp with time zone, 'DD.MM.YYYY'::text), to_char((ord_info.end_date)::timestamp with time zone, 'DD.MM.YYYY'::text)) AS pay_period,
    ref_close_rsn.name AS close_rsn_name,
    puv.name AS puv_name,
    COALESCE(prev_work.prof_name, (prof.name)::character varying) AS prof,
    p.snils,
    ord.zp,
    concat(career.total_staj_years, '/', career.total_staj_month, '/', career.total_staj_days) AS insur_staj,
    concat(ord.total_staj_years, '/', ord.total_staj_month, '/', ord.total_staj_days) AS staj
   FROM ((((((((((((((((((((((((psn_order ord
     JOIN psn_kpy kpy ON ((ord.kpy_id = kpy.id)))
     JOIN psn_person p ON ((p.id = kpy.pers_id)))
     LEFT JOIN ref_szn szn ON ((szn.id = kpy.szn_dep_id)))
     LEFT JOIN ref_rgn rgn ON ((rgn.id = szn.rgn_id)))
     LEFT JOIN psn_job_search_problem jsp ON ((jsp.kpy_id = kpy.id)))
     LEFT JOIN ref_dict_line tpr ON ((tpr.id = jsp.tpr_id)))
     LEFT JOIN psn_kng kng ON ((kng.kpy_id = kpy.id)))
     LEFT JOIN ref_dict_line ref_kng ON ((ref_kng.id = kng.kng_id)))
     LEFT JOIN sys_talon ON (((sys_talon.sys_id)::text = (kpy.sys_id)::text)))
     LEFT JOIN psn_kng ON ((kng.kpy_id = kpy.id)))
     LEFT JOIN psn_study study ON ((study.kpy_id = kpy.id)))
     LEFT JOIN psn_prev_work prev_work ON (((prev_work.kpy_id = kpy.id) AND (prev_work.is_last IS TRUE))))
     LEFT JOIN ref_prof prof ON ((prof.id = prev_work.prof_id)))
     LEFT JOIN ref_dict_line ref_algo ON ((ref_algo.id = ord.algo_id)))
     LEFT JOIN psn_job job ON ((job.kpy_id = kpy.id)))
     LEFT JOIN psn_order_info ord_info ON ((ord_info.order_id = ord.id)))
     LEFT JOIN psn_career career ON ((career.id = kpy.career_id)))
     LEFT JOIN ref_dict_line tvs ON ((tvs.id = ord.tvs_id)))
     LEFT JOIN ref_dict_line rshs ON ((rshs.id = ord.rshs_id)))
     LEFT JOIN ref_dict_line lim_max ON ((lim_max.id = ord.lim_max_id)))
     LEFT JOIN ref_dict_line lim_min ON ((lim_min.id = ord.lim_min_id)))
     LEFT JOIN ref_dict_line ref_close_rsn ON ((ref_close_rsn.id = kpy.close_rsn_id)))
     LEFT JOIN ref_dict_line puv ON ((puv.id = prev_work.puv_id)))
     LEFT JOIN ref_dict_line prs ON ((prs.id = ord.prs_id)));
