create function fn_report_1306(p_rgn_id bigint, p_szn_id bigint, p_sid bigint, p_start_date date, p_finish_date date) returns TABLE(id bigint, kpy_id bigint, version bigint, doc_date date, num character varying, obr_date date, pz_close_date date, szn_rec_id character varying, close_rsn_id bigint, pers_id bigint, pz_close_rsn_id bigint, szn_dep_id bigint, close_date date, sys_id character varying, career_id bigint, info_id bigint, pob_id bigint, rgn_id bigint, tpr character varying, fio character varying, szn character varying, rgn character varying, send_date date, kzf character varying, kng character varying, reg_month bigint, idle_year bigint)
LANGUAGE plpgsql
AS $$
DECLARE
  r RECORD;
BEGIN
	-- ================================================================
	-- Итог
	-- ================================================================	     
     IF p_sid IS NOT NULL THEN 
     	-- МДН
	 	FOR r IN (
				SELECT DISTINCT
				  kpy.id AS kpy_id
				, kpy.version AS version  
				, kpy.num AS kpy_num
				, concat(pers.last_name, ' ', pers.first_name, ' ', pers.middle_name) AS fio
				, szn.name AS szn
				, rgn.name AS rgn
				, kpy.obr_date AS obr_date
				, max(send.send_date) AS send_date
				, kzf.name AS kzf
				, (SELECT kng.name FROM psn_kng tkng, ref_dict_line kng WHERE tkng.kpy_id = kpy.id AND kng.id = tkng.kng_id limit 1) AS kng
				, max(send.send_date - kpy.obr_date)/ 30 as reg_month
				, coalesce((kpy.obr_date -  prev_work.end_date) / 365, 0) as idle_year 
				FROM psn_kpy kpy
				INNER JOIN rpt_param param ON param.num_value = kpy.id
					AND param.sid = p_sid 
					AND param.report = '1306' 
					AND param.param = 'KPY_ID'	
				INNER JOIN ref_szn szn ON szn.id = kpy.szn_dep_id
				INNER JOIN ref_rgn rgn ON rgn.id = szn.rgn_id
				INNER JOIN psn_person pers ON pers.id = kpy.pers_id
				INNER JOIN psn_job job ON job.kpy_id = kpy.id
				INNER JOIN psn_send_job send ON send.kpy_id = kpy.id
				INNER JOIN psn_kpy_info info ON info.id = kpy.info_id 
				INNER JOIN ref_dict_line pob ON pob.id = kpy.pob_id AND pob.code IN ('1', '2', '3', '4')
				LEFT JOIN psn_prev_work prev_work ON prev_work.kpy_id = kpy.id
					AND prev_work.is_last = true
				INNER JOIN ref_dict_line vtr ON vtr.id = send.vtr_id AND vtr.code = '3'
				LEFT JOIN ref_dict_line kzf ON kzf.id = info.kzf_id
				WHERE 1 = 1
				  AND szn.rgn_id = coalesce(p_rgn_id, szn.rgn_id)
				  AND szn.id = coalesce(p_szn_id, szn.id)
				  AND send.send_date BETWEEN coalesce(p_start_date, send.send_date) AND coalesce(p_finish_date, send.send_date)
				  AND EXISTS (SELECT null
				  		    FROM psn_kng kpy_kng 
				  		    INNER JOIN ref_dict_line kng ON kng.id = kpy_kng.kng_id 
				  		    WHERE 1 = 1
				  		      AND kpy_kng.kpy_id = kpy.id
				  		      AND coalesce(prev_work.prof_id, 0) = 0 
				  		      AND kng.code = '03'
				  		    --
				  		    UNION ALL
				  		    --  
						    SELECT null
				  		    FROM psn_kng kpy_kng 
				  		    INNER JOIN ref_dict_line kng ON kng.id = kpy_kng.kng_id 
				  		    WHERE 1 = 1
				  		      AND kpy_kng.kpy_id = kpy.id
				  		      AND kng.code IN ('10', '07', '08')
				  		    --
				  		    UNION ALL
				  		    --
				  		    SELECT null
				  		    FROM dual
				  		    WHERE 1 = 1
				  		      AND kzf.code = '01'
				  		      AND kpy.obr_date > prev_work.end_date  + interval '1 year'
				  		    --
				  		    UNION ALL
				  		    --
				  		    SELECT null
				  		    FROM dual
				  		    WHERE 1 = 1
				  		      AND send.send_date > kpy.obr_date + interval '18 month'
				  		    --
				  		    UNION ALL
				  		    --
				  		    SELECT null
				  		    FROM dual
				  		    WHERE 1 = 1
				  		      AND kpy.obr_date > prev_work.end_date  + interval '3 year'
				  		   ) 
				GROUP BY kpy.id, pers.id, szn.id, rgn.id, kzf.id, prev_work.id
			 )
		LOOP
		  id := nextval('seq_mdn_kpy');
		  kpy_id := r.kpy_id;
		  version := r.version;
		  num := r.kpy_num;
		  obr_date := r.obr_date;
		  fio := r.fio; 
		  szn := r.szn;
		  rgn := r.rgn;
		  send_date := r.send_date; 
		  kzf := r.kzf;
		  kng := r.kng;
		  reg_month := r.reg_month; 
		  idle_year := r.idle_year;
		  RETURN NEXT;
		END LOOP;
		--	
		DELETE FROM rpt_param WHERE sid = p_sid AND report = '1306'; 
		--	
	ELSE
	 	FOR r IN (
				SELECT DISTINCT
				  kpy.id AS kpy_id
				, kpy.version AS version  
				, kpy.num AS kpy_num
				, concat(pers.last_name, ' ', pers.first_name, ' ', pers.middle_name) AS fio
				, szn.name AS szn
				, rgn.name AS rgn
				, kpy.obr_date AS obr_date
				, max(send.send_date) AS send_date
				, kzf.name AS kzf
				, (SELECT kng.name FROM psn_kng tkng, ref_dict_line kng WHERE tkng.kpy_id = kpy.id AND kng.id = tkng.kng_id limit 1) AS kng
				, max(send.send_date - kpy.obr_date)/ 30 as reg_month
				, coalesce((kpy.obr_date -  prev_work.end_date) / 365, 0) as idle_year
				FROM psn_kpy kpy
				INNER JOIN ref_szn szn ON szn.id = kpy.szn_dep_id
				INNER JOIN ref_rgn rgn ON rgn.id = szn.rgn_id
				INNER JOIN psn_person pers ON pers.id = kpy.pers_id
				INNER JOIN psn_job job ON job.kpy_id = kpy.id
				INNER JOIN psn_send_job send ON send.kpy_id = kpy.id
				INNER JOIN psn_kpy_info info ON info.id = kpy.info_id 
				INNER JOIN ref_dict_line pob ON pob.id = kpy.pob_id AND pob.code IN ('1', '2', '3', '4')
				LEFT JOIN psn_prev_work prev_work ON prev_work.kpy_id = kpy.id
					AND prev_work.is_last = true
				INNER JOIN ref_dict_line vtr ON vtr.id = send.vtr_id AND vtr.code = '3'
				LEFT JOIN ref_dict_line kzf ON kzf.id = info.kzf_id
				WHERE 1 = 1
				  AND szn.rgn_id = p_rgn_id
				  AND szn.id = p_szn_id
				  AND EXISTS (SELECT null
				  		    FROM psn_kng kpy_kng 
				  		    INNER JOIN ref_dict_line kng ON kng.id = kpy_kng.kng_id 
				  		    WHERE 1 = 1
				  		      AND kpy_kng.kpy_id = kpy.id
				  		      AND coalesce(prev_work.prof_id, 0) = 0 
				  		      AND kng.code = '03'
				  		    --
				  		    UNION ALL
				  		    --  
						    SELECT null
				  		    FROM psn_kng kpy_kng 
				  		    INNER JOIN ref_dict_line kng ON kng.id = kpy_kng.kng_id 
				  		    WHERE 1 = 1
				  		      AND kpy_kng.kpy_id = kpy.id
				  		      AND kng.code IN ('10', '07', '08')
				  		    --
				  		    UNION ALL
				  		    --
				  		    SELECT null
				  		    FROM dual
				  		    WHERE 1 = 1
				  		      AND kzf.code = '01'
				  		      AND kpy.obr_date > prev_work.end_date  + interval '1 year'
				  		    --
				  		    UNION ALL
				  		    --
				  		    SELECT null
				  		    FROM dual
				  		    WHERE 1 = 1
				  		      AND send.send_date > kpy.obr_date + interval '18 month'
				  		    --
				  		    UNION ALL
				  		    --
				  		    SELECT null
				  		    FROM dual
				  		    WHERE 1 = 1
				  		      AND kpy.obr_date > prev_work.end_date  + interval '3 year'
				  		   )
				GROUP BY kpy.id, pers.id, szn.id, rgn.id, kzf.id, prev_work.id
			 )
		LOOP
		  id := nextval('seq_mdn_kpy');
		  kpy_id := r.kpy_id;
		  version := r.version;
		  num := r.kpy_num;
		  obr_date := r.obr_date;
		  fio := r.fio; 
		  szn := r.szn;
		  rgn := r.rgn;
		  send_date := r.send_date; 
		  kzf := r.kzf;
		  kng := r.kng;
		  reg_month := r.reg_month; 
		  idle_year := r.idle_year;
		  RETURN NEXT;
		END LOOP;
		--		
	END IF;
END;
$$;
