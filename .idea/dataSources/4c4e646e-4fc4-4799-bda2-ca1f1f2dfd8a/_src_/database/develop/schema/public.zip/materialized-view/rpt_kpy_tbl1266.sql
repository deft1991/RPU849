CREATE MATERIALIZED VIEW rpt_kpy_tbl1266 AS SELECT kpy.id,
    kpy.version,
    kpy.close_date,
    kpy.doc_date,
    kpy.num,
    kpy.obr_date,
    kpy.pz_close_date,
    kpy.szn_rec_id,
    kpy.close_rsn_id,
    kpy.pers_id,
    kpy.pz_close_rsn_id,
    kpy.szn_dep_id,
    NULL::unknown AS region_id,
    psn_order.order_num AS ordernum,
    psn_order.start_date AS startdate,
    psn_order.end_date AS enddate,
    scv.name AS scvname,
    prkz.name AS prkzname,
    prp.name AS prpname,
    concat(pers.last_name, ' ', pers.first_name, ' ', pers.middle_name) AS fio,
    psn_order.summ AS ordersum,
    psn_order.region_coeff AS regioncoeff,
    psn_order.order_date AS orderdate,
    szn.name AS sznname,
    rgn.id AS rgnid,
    rgn.name AS rgnname,
    ( SELECT tpr.name
           FROM psn_job_search_problem dfj,
            ref_dict_line tpr
          WHERE ((dfj.kpy_id = kpy.id) AND (tpr.id = dfj.tpr_id))
         LIMIT 1) AS tprname,
    ( SELECT kng.name
           FROM psn_kng tkng,
            ref_dict_line kng
          WHERE ((tkng.kpy_id = kpy.id) AND (kng.id = tkng.kng_id))
         LIMIT 1) AS kngname,
    sys_talon.tdate,
    (psn_order.start_date - sys_talon.tdate) AS duration,
    NULL::bigint AS career_id,
    NULL::bigint AS info_id,
    NULL::bigint AS pob_id
   FROM (((((((((psn_kpy kpy
     JOIN psn_person pers ON ((kpy.pers_id = pers.id)))
     JOIN psn_kpy_info p_info ON ((kpy.info_id = p_info.id)))
     JOIN ref_szn szn ON ((szn.id = kpy.szn_dep_id)))
     JOIN ref_rgn rgn ON ((rgn.id = szn.rgn_id)))
     LEFT JOIN psn_order ON ((psn_order.kpy_id = kpy.id)))
     LEFT JOIN ref_dict_line scv ON ((scv.id = psn_order.scv_id)))
     LEFT JOIN ref_dict_line prp ON ((prp.id = psn_order.prp_id)))
     LEFT JOIN ref_dict_line prkz ON ((prkz.id = psn_order.prkz_id)))
     JOIN sys_talon ON (((sys_talon.sys_id)::text = (psn_order.sys_id)::text)))
  WHERE ((EXISTS ( SELECT prkz_1.id
           FROM (ref_dict_line prkz_1
             JOIN ref_dict_line stp ON (((psn_order.status_id = stp.id) AND ((stp.code)::text = '1'::text))))
          WHERE ((prkz_1.id = psn_order.prkz_id) AND ((prkz_1.code)::text = ANY ((ARRAY['9'::character varying, '25'::character varying])::text[]))))) AND (NOT (EXISTS ( SELECT NULL::unknown
           FROM ((psn_soc_payment_card
             JOIN psn_soc_payment_period ON ((psn_soc_payment_period.soc_pmnts_card_id = psn_soc_payment_card.id)))
             JOIN psn_soc_payment_sum ON ((psn_soc_payment_sum.pmnts_period_id = psn_soc_payment_period.id)))
          WHERE ((psn_soc_payment_card.order_id = psn_order.id) AND (psn_soc_payment_sum.is_set IS TRUE))))) AND (psn_order.start_date <= sys_talon.tdate));
