CREATE MATERIALIZED VIEW ref_sfd AS SELECT dl.id,
    0 AS version,
    dl.code,
    dl.name
   FROM (ref_dict
     JOIN ref_dict_line dl ON ((ref_dict.id = dl.dict_id)))
  WHERE ((ref_dict.code)::text = 'СФД'::text);
