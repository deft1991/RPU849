create function fn_mdn_init_szn_report(p_rgn_id bigint, p_szn_id bigint, p_start_date date, p_finish_date date, p_report_name character varying) returns bigint
LANGUAGE plpgsql
AS $$
DECLARE
 v_sid int8;
 r record;
BEGIN
  v_sid := nextval('seq_mdn_param');
  IF p_rgn_id IS NOT NULL THEN
	  FOR r IN (SELECT kpy_id 
	  		  FROM rpt_remote_control_detail 
	  		  WHERE 1 = 1
	  		    AND rgn_id = p_rgn_id
	  		    AND szn_id = coalesce(p_szn_id, szn_id)
	  		    AND obr_date BETWEEN p_start_date AND p_finish_date
	  		    AND report_name = p_report_name
	  		  )
	  LOOP
		INSERT INTO rpt_param(
		  sid
		, report
		, param
		, num_value
		)
		VALUES( 
		  v_sid
		, p_report_name
		, 'KPY_ID'
		, r.kpy_id
		);
	  END LOOP;
  ELSE
	  FOR r IN (SELECT kpy_id 
	  		  FROM rpt_remote_control_detail 
	  		  WHERE 1 = 1
	  		    AND report_name = p_report_name
	  		  )
	  LOOP
		INSERT INTO rpt_param(
		  sid
		, report
		, param
		, num_value
		)
		VALUES( 
		  v_sid
		, p_report_name
		, 'KPY_ID'
		, r.kpy_id
		);
	  END LOOP;  END IF;	  
  RETURN v_sid;
END;
$$;
