create function etl_load_report(p_sys_id text) returns TABLE(file_name text, error_count bigint, error_message text)
LANGUAGE SQL
AS $$
SELECT
    upper(d.file_name) file_name,
    sum(1) error_count,
    d.error_message || coalesce(': '||d.column_name,'') error_message
FROM sys_talon_log_detail d
    inner join sys_meta m on d.sys_id = m.sys_id
    inner join sys_report_conf c on c.format=m.format and c.file_name=d.file_name and d.error_code = any(string_to_array(c.error_code,','))
                                    and ((c.column_name is null and d.column_name is null) or d.column_name = any(string_to_array(c.column_name,',')))
WHERE d.sys_id=p_sys_id and d.error_code <> '0' and d.error_code is not null
      and d.sys_update>=(select max(sys_updated)-'10min'::interval talon_date from sys_talon where sys_id=p_sys_id)
GROUP BY upper(d.file_name), d.error_message, d.column_name
ORDER BY file_name, error_count desc;
$$;
