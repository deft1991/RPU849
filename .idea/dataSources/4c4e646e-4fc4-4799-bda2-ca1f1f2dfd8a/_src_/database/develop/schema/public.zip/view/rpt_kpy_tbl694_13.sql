CREATE VIEW rpt_kpy_tbl694_13 AS SELECT kpy.id,
    kpy.version,
    kpy.doc_date,
    kpy.num,
    kpy.obr_date,
    kpy.pz_close_date,
    kpy.szn_rec_id,
    kpy.close_rsn_id,
    kpy.pers_id,
    kpy.pz_close_rsn_id,
    kpy.szn_dep_id,
    kpy.close_date,
    kpy.sys_id,
    kpy.career_id,
    kpy.info_id,
    kpy.pob_id,
    concat(pers.last_name, ' ', pers.first_name, ' ', pers.middle_name) AS fio,
    szn.name AS szn,
    rgn.name AS rgn,
    ( SELECT tpr.name
           FROM psn_job_search_problem dfj,
            ref_dict_line tpr
          WHERE ((dfj.kpy_id = kpy.id) AND (tpr.id = dfj.tpr_id))
         LIMIT 1) AS tpr,
    kzf.name AS kzf,
    rgn.id AS rgn_id
   FROM (((((((((((psn_kpy kpy
     JOIN psn_order prikazp ON ((prikazp.kpy_id = kpy.id)))
     JOIN ref_dict_line rshsp ON (((prikazp.rshs_id = rshsp.id) AND ((rshsp.code)::text = 'П'::text))))
     JOIN ref_dict_line tvsp ON ((prikazp.tvs_id = tvsp.id)))
     JOIN psn_order prikazk ON (((prikazk.kpy_id = kpy.id) AND (prikazk.parent_id = prikazp.id))))
     JOIN ref_dict_line rshsk ON (((prikazk.rshs_id = rshsk.id) AND ((rshsk.code)::text = 'К'::text))))
     JOIN ref_dict_line tvsk ON ((prikazk.tvs_id = tvsk.id)))
     JOIN psn_person pers ON ((pers.id = kpy.pers_id)))
     JOIN ref_szn szn ON ((kpy.szn_dep_id = szn.id)))
     JOIN ref_rgn rgn ON ((szn.rgn_id = rgn.id)))
     LEFT JOIN psn_kpy_info persinfo ON ((persinfo.id = kpy.info_id)))
     LEFT JOIN ref_dict_line kzf ON ((kzf.id = persinfo.kzf_id)))
  WHERE ((NOT (EXISTS ( SELECT prikazo.id
           FROM (psn_order prikazo
             JOIN ref_dict_line rshso ON (((prikazo.rshs_id = rshso.id) AND ((rshso.code)::text = 'О'::text))))
          WHERE ((prikazo.parent_id = prikazp.id) OR (prikazo.parent_id = prikazk.id))))) AND (prikazp.order_date > prikazk.order_date));
