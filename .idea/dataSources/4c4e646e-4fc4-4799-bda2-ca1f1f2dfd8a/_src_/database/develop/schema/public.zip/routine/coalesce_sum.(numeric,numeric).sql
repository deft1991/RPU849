create function coalesce_sum(sum1 numeric, sum2 numeric) returns numeric
LANGUAGE plpgsql
AS $$
DECLARE 
BEGIN
  IF coalesce(sum1, 0) != 0 THEN
    return sum1;
  ELSE
    return sum2;
  END IF;                     
END;
$$;
