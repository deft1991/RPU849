create function tsk_refresh_mat_views_public() returns integer
LANGUAGE plpgsql
AS $$
DECLARE
        r RECORD;
    BEGIN
        FOR r IN SELECT matviewname FROM pg_matviews WHERE schemaname = 'public'
        LOOP
            RAISE NOTICE 'Refreshing %', r.matviewname;
            EXECUTE 'REFRESH MATERIALIZED VIEW public.' || r.matviewname;
        END LOOP;

        RETURN 1;
    END
$$;
