create function rpt_063a(datefrom date, dateto date, rgnid bigint) returns TABLE(c1 character varying, c2 character varying, c3 character varying, c4 character varying, c5 character varying, c6 character varying, c7 character varying, c8 integer, c9 character varying, c10 integer, c11 integer, c12 text, c13 text, c14 text, c15 text, c16 numeric, c17 date, c18 text, c19 date, c20 character varying, c21 character varying, c22 numeric, c23 text, c24 character varying, c25 character varying, c26 text, c27 character varying, c28 date, c29 text, c30 text, c31 text, c32 text)
LANGUAGE plpgsql
AS $$
DECLARE
            dgvs RECORD;
            BEGIN
            FOR dgvs in select org.full_name, okopf.name, okfs.name, lgl_addr.full_addr
            ,fact_addr.full_addr, org.inn, okved2.name, 0, v.prof_name
            ,v.init_need_no, 0, v.grf_1, v.grf_2, v.grf_3, v.grf_4,
            CASE
            WHEN plan.cash_box_sum IS NOT NULL THEN plan.cash_box_sum
            ELSE plan.pay_sum
            END
            , v.reg_date, j.fio, j.start_date, j.uro, j.prof_name
            ,v.average, '', j.ipra_vid, j.ipra_gin, '', j.ipra_ppi, j.end_date, '', '','', ''
            from rpt_063a_dgvs(dateFrom, dateTo, rgnId) d
            JOIN rpt_063a_vacs(d.vacs_id, dateto) v on v.id = d.vacs_id
            JOIN rpt_063a_jobs(v.id) j on j.vacancy_id = v.id
            LEFT JOIN lgl_plan_expense plan on plan.contract_id = d.id
            and EXISTS (select oti.id from ref_dict_line oti where oti.code = 'ОТИ')

            LEFT JOIN lgl_organization org on org.id = v.org_id
            LEFT JOIN ref_dict_line okopf on okopf.id = org.okopf_id
            LEFT JOIN ref_dict_line okfs on okfs.id = org.okfs_id
            LEFT JOIN psn_address lgl_addr on lgl_addr.id = org.legal_addr_id
            LEFT JOIN psn_address fact_addr on fact_addr.id = org.fact_addr_id
            LEFT JOIN ref_dict_line okved2 on okved2.id = org.okved2_id

            LOOP
            RETURN NEXT;
            END LOOP;
            END;
$$;
