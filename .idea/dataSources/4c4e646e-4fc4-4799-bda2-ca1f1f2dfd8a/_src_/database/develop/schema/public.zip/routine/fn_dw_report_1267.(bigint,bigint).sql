create function fn_dw_report_1267(p_rgn_id bigint, p_szn_id bigint) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
			BEGIN
			DELETE FROM dw_rep1267
			WHERE 1 = 1
			AND szn_id = coalesce(p_szn_id, szn_id)
			AND rgn_id = coalesce(p_rgn_id, rgn_id)
			;
			--
			INSERT INTO dw_rep1267(
			szn_id -- СЗН
			, rgn_id -- Регион
			, kpy_num -- КПУ
			, fio -- ФИО
			, order_num -- Номер приказа
			, start_date -- Начало
			, end_date -- Окончание
			, tvs_id -- Тип выплаты
			, rshs_id -- Решение
			, prs_id -- Причина
			, amount -- Сумма
			, koef -- Коэффициент
			, order_date -- Дата приказа
			, obr_date -- Дата обращения
			, close_date -- Дата закрытия
			, doc_date -- Дата подачи
			, tpr_id -- Категория испытывающего трудности в поисках работы
			, kng_id -- Категория незанятости
			, report_year -- Отчетный период
			, report_month -- Отчетный период
			, duration -- Длительность
			)
			SELECT DISTINCT
			coalesce(szn.id, 0) AS szn_id -- СЗН
			, coalesce(rgn.id, 0) AS rgn_id -- Регион
			, coalesce(kpy.num, '') as kpy_num -- КПУ
			, coalesce(pers.last_name || ' ' || pers.first_name || ' ' || pers.middle_name, '') as fio -- ФИО
			, coalesce(ord.order_num, '') AS order_num -- Номер приказа
			, ord.start_date AS start_date -- Начало
			, ord.end_date AS end_date -- Окончание
			, coalesce(ord.tvs_id, 0) AS tvs_id -- Тип выплаты
			, coalesce(ord.rshs_id, 0) AS rshs_id -- Решение
			, coalesce(ord.prs_id, 0) AS prs_id -- Причина
			, coalesce(ord.summ, 0) AS amount -- Сумма
			, coalesce(ord.region_coeff, 0) AS koef -- Коэффициент
			, ord.order_date AS order_date -- Дата приказа
			, kpy.obr_date AS obr_date -- Дата обращения
			, kpy.close_date AS close_date -- Дата закрытия
			, kpy.doc_date AS doc_date -- Дата подачи
			, coalesce(jsp.tpr_id, 0) AS tpr_id -- Категория испытывающего трудности в поисках работы
			, coalesce(kpy_kng.kng_id, 0) AS kng_id -- Категория незанятости
			, to_char(ord.order_date, 'YYYY')::int4 AS report_year -- Отчетный период
			, to_char(ord.order_date, 'MM')::int4 AS report_month -- Отчетный период
			, date_part('day', talon.tdate::timestamp - stud.end_date::timestamp)  AS duration -- Длительность
			FROM psn_kpy kpy
			INNER JOIN psn_person pers ON pers.id = kpy.pers_id
			INNER JOIN ref_szn szn ON szn.id = kpy.szn_dep_id
			INNER JOIN ref_rgn rgn ON rgn.id = szn.rgn_id
			INNER JOIN ref_dict_line psu ON psu.id = kpy.close_rsn_id
			INNER JOIN psn_study stud ON stud.kpy_id = kpy.id
			INNER JOIN psn_order ord ON ord.kpy_id = kpy.id
			AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line stp WHERE dic.id = stp.dict_id AND dic.code = 'СТП' AND stp.code = '1' AND stp.id = coalesce(ord.status_id, stp.id))
			AND EXISTS (SELECT null FROM ref_dict_line prkz WHERE prkz.code = '21'AND prkz.id = ord.prkz_id)
			LEFT JOIN psn_soc_payment_card card ON card.order_id = ord.id
			LEFT JOIN psn_soc_payment_period soc_prd ON soc_prd.soc_pmnts_card_id = card.id
			LEFT JOIN psn_soc_payment_sum soc_sum ON soc_sum.pmnts_period_id = soc_prd.id
			LEFT JOIN sys_talon talon ON talon.sys_id = ord.sys_id
			LEFT JOIN psn_kng kpy_kng ON kpy_kng.kpy_id = kpy.id
			LEFT JOIN psn_job_search_problem jsp ON jsp.kpy_id = kpy.id
			WHERE 1 = 1
			--AND kpy.id IN ( 672641828, 1455575630)
			AND szn.id = coalesce(p_szn_id, szn.id)
			AND rgn.id = coalesce(p_rgn_id, rgn.id)
			AND ord.order_date >= to_date('01.01.2014','DD.MM.YYYY')
			AND ord.start_date <= talon.tdate
			AND soc_sum.id IS NULL
			AND stud.end_date < talon.tdate
						AND coalesce(kpy.pz_close_date,  stud.end_date) >=  stud.end_date
			;
			return true;
			--
			END;
$$;
