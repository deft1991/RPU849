create function getvacs_places_period(p_rgn_id bigint, p_szn_id bigint, p_datefrom date, p_dateto date) returns TABLE(rgn_id bigint, szn_id bigint, id bigint, vac_count bigint, vac_opened bigint, vac_closed bigint, cur_need_no bigint, job_no bigint, job_send_no bigint, send_no bigint)
LANGUAGE plpgsql
AS $$
DECLARE
r RECORD;
BEGIN
FOR r IN (
	SELECT
		VachTotals.rgn_id AS rgn_id, 
		VachTotals.szn_id AS szn_id,
		VachTotals.vacs_id AS vacs_id,
		VachTotals.VacCount AS vac_count,
		VachTotals.VacReqOpened + VachTotals.VacEmpOpened AS vac_opened,
		VachTotals.VacReqClosed + VachTotals.VacEmpClosed + CASE WHEN VachSuperTotals.VacClosed > 0 THEN VachSuperTotals.VacClosed ELSE 0 END AS vac_closed,
		VachTotals.VacRequired AS vac_required,
		VachTotals.VacEmployed AS vac_employed,
		VachTotals.VacEmployedSZ AS vac_employedSZ,
		VachTotals.VacSent AS vac_sent
	FROM (
		SELECT
			rgn.id AS rgn_id, 
			vacs.szn_id,
			vacs.id AS vacs_id,
			count(*) AS VacCount,
			sum(vach.cur_need_no) AS VacRequired,
			sum(vach.job_no) AS VacEmployed,
			sum(vach.job_send_no) AS VacEmployedSZ,
			sum(vach.send_no) AS VacSent,
			sum(CASE WHEN vach.cur_need_no > 0 THEN vach.cur_need_no ELSE 0 END) AS VacReqOpened,
			sum(CASE WHEN vach.cur_need_no < 0 THEN -vach.cur_need_no ELSE 0 END) AS VacReqClosed,
			sum(CASE WHEN vach.job_no > 0 THEN vach.job_no ELSE 0 END) AS VacEmpClosed,
			sum(CASE WHEN vach.job_no < 0 THEN -vach.job_no ELSE 0 END) AS VacEmpOpened
		FROM lgl_vacancy vacs 
		JOIN lgl_vacancy_history vach ON vach.vacancy_id = vacs.id
		INNER JOIN ref_szn szn ON szn.id = vacs.szn_id
		INNER JOIN ref_rgn rgn ON rgn.id = szn.rgn_id
		WHERE rgn.id = COALESCE(p_rgn_id, rgn.id)
		AND (vacs.szn_id = COALESCE(p_szn_id, vacs.szn_id))
		AND (vach.edit_date IS NULL OR vach.edit_date BETWEEN COALESCE(p_datefrom, vach.edit_date) AND COALESCE(p_dateTo, vach.edit_date))
		GROUP BY
			rgn.id,
			vacs.szn_id,
			vacs.id
		UNION
		-- 30.05.2012 Шендера Кирилл
		-- Вакансии, закрытые в отчетном периоде, по которым не было движения в VACHe
		-- нужны нам для join с подзапросом VachSuperTotals
		SELECT
			rgn.id AS rgn_id, 
			vacs.szn_id,
			vacs.id AS vacs_id,
			0 As VacCount,
			0 As VacRequired,
			0 As VacEmployed,
			0 As VacEmployedSZ,
			0 As VacSent,
			0 As VacReqOpened,
			0 As VacReqClosed,
			0 As VacEmpClosed,
			0 As VacEmpOpened
		FROM lgl_vacancy vacs
		INNER JOIN ref_szn szn ON szn.id = vacs.szn_id
		INNER JOIN ref_rgn rgn ON rgn.id = szn.rgn_id
		WHERE rgn.id = COALESCE(p_rgn_id, rgn.id)
		AND (vacs.szn_id = COALESCE(p_szn_id, vacs.szn_id))
		AND vacs.close_date BETWEEN COALESCE(p_datefrom, vacs.close_date) AND COALESCE(p_dateTo, vacs.close_date) 
		AND NOT EXISTS
			(
			SELECT
				vach.vacancy_id
			FROM lgl_vacancy_history vach
			WHERE vach.edit_date IS NULL OR vach.edit_date BETWEEN COALESCE(p_datefrom, vach.edit_date) AND COALESCE(p_dateTo, vach.edit_date)
			And vacs.id = vach.vacancy_id
			)
	) VachTotals
	FULL JOIN (
		SELECT
			rgn.id AS rgn_id, 
			vacs.szn_id,
			vacs.id AS vacs_id,
			sum(vach.cur_need_no) - sum(vach.job_no) AS VacClosed
		FROM lgl_vacancy_history vach
		JOIN lgl_vacancy vacs ON vach.vacancy_id = vacs.id
		INNER JOIN ref_szn szn ON szn.id = vacs.szn_id
		INNER JOIN ref_rgn rgn ON rgn.id = szn.rgn_id
		WHERE rgn.id = COALESCE(p_rgn_id, rgn.id)
		AND (vacs.szn_id = COALESCE(p_szn_id, vacs.szn_id))
		AND vacs.close_date BETWEEN COALESCE(p_datefrom, vacs.close_date) AND COALESCE(p_dateTo, vacs.close_date)
		GROUP BY
			rgn.id,
			vacs.szn_id,
			vacs.id
	) VachSuperTotals
	ON VachSuperTotals.rgn_id = VachTotals.rgn_id
	AND VachSuperTotals.vacs_id = VachTotals.vacs_id
)
LOOP
rgn_id := r.rgn_id;
szn_id := r.szn_id;
id := r.vacs_id;
vac_count := r.vac_count;
vac_opened := r.vac_opened;
vac_closed := r.vac_closed;
cur_need_no := r.vac_required;
job_no := r.vac_employed;
job_send_no := r.vac_employedSZ;
send_no := r.vac_sent;
RETURN NEXT;
END LOOP;
END;
$$;
