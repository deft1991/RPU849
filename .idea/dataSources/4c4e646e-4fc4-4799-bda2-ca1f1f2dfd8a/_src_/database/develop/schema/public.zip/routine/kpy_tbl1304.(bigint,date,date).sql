create function kpy_tbl1304(p_rgn_id bigint, p_start_date date, p_finish_date date) returns TABLE(id bigint, version bigint, doc_date date, num character varying, obr_date date, pz_close_date date, szn_rec_id character varying, close_rsn_id bigint, pers_id bigint, pz_close_rsn_id bigint, szn_dep_id bigint, close_date date, sys_id character varying, career_id bigint, info_id bigint, pob_id bigint, order_d_date date, order_d_o_id bigint, order_12_date date, order_12_o_id bigint, order_kp_id bigint, order_pp_after_id bigint, order_pp_before_id bigint)
LANGUAGE SQL
AS $$
SELECT DISTINCT kpy.id
	  , kpy.version
	  , kpy.doc_date
	  , kpy.num
	  , kpy.obr_date
	  , kpy.pz_close_date
	  , kpy.szn_rec_id
	  , kpy.close_rsn_id
	  , kpy.pers_id
	  , kpy.pz_close_rsn_id
	  , kpy.szn_dep_id
	  , kpy.close_date
	  , kpy.sys_id
	  , kpy.career_id
	  , kpy.info_id
	  , kpy.pob_id
          , ordD.order_date order_D_date
	  , (SELECT ordDO.id FROM psn_order ordDO JOIN ref_dict_line rshsDO ON ordDO.rshs_id=rshsDO.id AND rshsDO.code = 'О' WHERE ordDO.parent_id = ordD.id LIMIT 1
	    ) order_D_O_id
	  , ord12.order_date order_12_date
	  , (SELECT ord12o.id FROM psn_order ord12o JOIN ref_dict_line rshs12o ON ord12o.rshs_id=rshs12o.id AND rshs12o.code = 'О' WHERE ord12o.parent_id = ord12.id LIMIT 1
	    ) order_12_O_id
	  , (SELECT ordKP.id FROM psn_order ordKP
	      JOIN ref_dict_line rshsKP ON ordKP.rshs_id=rshsKP.id AND rshsKP.code = 'К'
	      JOIN ref_dict_line tvsKP ON ordKP.tvs_id=tvsKP.id AND tvsKP.code = 'П'
	      WHERE ordKP.kpy_id = kpy.id
	      AND NOT EXISTS (
		SELECT NULL FROM psn_order ordKPO JOIN ref_dict_line rshsKPO ON ordKPO.rshs_id=rshsKPO.id AND rshsKPO.code = 'О' WHERE ordKPO.parent_id = ordKP.id 
	      ) LIMIT 1
	    ) order_KP_id
	  , (SELECT ordPP.id FROM psn_order ordPP
	      JOIN ref_dict_line rshsKP ON ordPP.rshs_id=rshsKP.id AND rshsKP.code = 'П'
	      JOIN ref_dict_line tvsPP ON ordPP.tvs_id=tvsPP.id AND tvsPP.code = 'П'
	      WHERE ordPP.kpy_id = kpy.id
	      AND (ordPP.start_date >= ordD.start_date)
	      AND NOT EXISTS (
		SELECT NULL FROM psn_order ordPPO JOIN ref_dict_line rshsPPO ON ordPPO.rshs_id=rshsPPO.id AND rshsPPO.code = 'О' WHERE ordPPO.parent_id = ordPP.id
	      ) LIMIT 1
	    ) order_PP_after_id
	  , (SELECT ordPP.id FROM psn_order ordPP
	      JOIN ref_dict_line rshsKP ON ordPP.rshs_id=rshsKP.id AND rshsKP.code = 'П'
	      JOIN ref_dict_line tvsPP ON ordPP.tvs_id=tvsPP.id AND tvsPP.code = 'П'
	      WHERE ordPP.kpy_id = kpy.id
	      AND (ordPP.end_date <= ordD.start_date)
	      AND NOT EXISTS (
		SELECT NULL FROM psn_order ordPPO JOIN ref_dict_line rshsPPO ON ordPPO.rshs_id=rshsPPO.id AND rshsPPO.code = 'О' WHERE ordPPO.parent_id = ordPP.id
	      ) LIMIT 1
	    ) order_PP_before_id
from psn_kpy kpy 
  JOIN ref_szn szn ON szn.id = kpy.szn_dep_id AND szn.rgn_id = coalesce(p_rgn_id, szn.rgn_id)
  JOIN ref_rgn rgn ON rgn.id = szn.rgn_id
  JOIN psn_order ordD ON ordD.kpy_id = kpy.id AND ordD.order_date BETWEEN p_start_date AND p_finish_date
  JOIN ref_dict_line rshsYA ON ordD.rshs_id=rshsYA.id AND rshsYA.code = 'Я'
  JOIN ref_dict_line tvsD ON ordD.tvs_id=tvsD.id and tvsD.code = 'Д'
  JOIN psn_order ord12 ON ord12.kpy_id = kpy.id
  JOIN ref_dict_line prkz12 ON prkz12.id = ord12.prkz_id AND prkz12.code = '12'



$$;
