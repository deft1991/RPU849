CREATE MATERIALIZED VIEW rpt_kpy_tbl1305 AS SELECT DISTINCT t.id,
    t.version,
    t.close_date,
    t.doc_date,
    t.num,
    t.obr_date,
    t.pz_close_date,
    t.szn_rec_id,
    t.close_rsn_id,
    t.pers_id,
    t.pz_close_rsn_id,
    t.szn_dep_id,
    t.sznname,
    t.rgnid,
    t.rgnname,
    t.scvid,
    t.tdate,
    min(t.duration) AS duration,
    min(t.operdate) AS operdate,
    t.fio,
    NULL::bigint AS career_id,
    NULL::bigint AS info_id,
    NULL::bigint AS pob_id
   FROM ( SELECT psn_kpy.id,
            psn_kpy.version,
            psn_kpy.close_date,
            psn_kpy.doc_date,
            psn_kpy.num,
            psn_kpy.obr_date,
            psn_kpy.pz_close_date,
            psn_kpy.szn_rec_id,
            psn_kpy.close_rsn_id,
            psn_kpy.pers_id,
            psn_kpy.pz_close_rsn_id,
            psn_kpy.szn_dep_id,
            szn.name AS sznname,
            rgn.id AS rgnid,
            rgn.name AS rgnname,
            sys_talon.tdate,
            (sys_talon.tdate - min((pay_sum_paid.oper_date)::date)) AS duration,
            min(pay_sum_paid.oper_date) AS operdate,
            concat(psn_person.last_name, ' ', psn_person.first_name, ' ', psn_person.middle_name) AS fio,
            scv.id AS scvid
           FROM (((((((((((psn_kpy
             JOIN psn_person ON ((psn_kpy.pers_id = psn_person.id)))
             JOIN ref_szn szn ON ((szn.id = psn_kpy.szn_dep_id)))
             JOIN ref_rgn rgn ON ((rgn.id = szn.rgn_id)))
             LEFT JOIN psn_order ON ((psn_order.kpy_id = psn_kpy.id)))
             LEFT JOIN psn_soc_payment_card pay_card ON ((pay_card.order_id = psn_order.id)))
             LEFT JOIN psn_soc_payment_period pay_period ON ((pay_period.soc_pmnts_card_id = pay_card.id)))
             LEFT JOIN psn_soc_payment_sum pay_sum ON ((pay_sum.pmnts_period_id = pay_period.id)))
             JOIN psn_soc_payment_sum_paid pay_sum_paid ON ((pay_sum_paid.add_sum_id = pay_sum.id)))
             JOIN ref_dict_line scv ON ((scv.id = psn_order.scv_id)))
             JOIN ref_dict_line ivp ON ((ivp.id = pay_sum_paid.ivp_id)))
             JOIN sys_talon ON (((sys_talon.sys_id)::text = (psn_order.sys_id)::text)))
          WHERE ((psn_order.start_date <= sys_talon.tdate) AND ((ivp.code)::text = 'Л'::text) AND (pay_sum_paid.summ > (0)::numeric))
          GROUP BY psn_kpy.id, psn_kpy.version, psn_kpy.close_date, psn_kpy.doc_date, psn_kpy.num, psn_kpy.obr_date, psn_kpy.pz_close_date, psn_kpy.szn_rec_id, psn_kpy.close_rsn_id, psn_kpy.pers_id, psn_kpy.pz_close_rsn_id, psn_kpy.szn_dep_id, szn.name, rgn.id, rgn.name, pay_sum_paid.oper_date, sys_talon.tdate, psn_order.duration, psn_order.start_date, (concat(psn_person.last_name, ' ', psn_person.first_name, ' ', psn_person.middle_name)), scv.id, psn_kpy.career_id, psn_kpy.info_id, psn_kpy.pob_id) t
  GROUP BY t.id, t.version, t.close_date, t.doc_date, t.num, t.obr_date, t.pz_close_date, t.szn_rec_id, t.close_rsn_id, t.pers_id, t.pz_close_rsn_id, t.szn_dep_id, t.sznname, t.rgnid, t.rgnname, t.scvid, t.tdate, t.fio;
