create function rpt_kpy_tbl69412(p_rgn_id bigint, p_start_date date, p_finish_date date) returns TABLE(id bigint, version bigint, close_date date, doc_date date, num character varying, obr_date date, pz_close_date date, szn_rec_id character varying, close_rsn_id bigint, pers_id bigint, pz_close_rsn_id bigint, szn_dep_id bigint, tpr_name character varying, fio character varying, kzf_name character varying, szn_name character varying, rgn_name character varying, rgn_id bigint, career_id bigint, info_id bigint, pob_id bigint)
LANGUAGE SQL
AS $$
SELECT kpy.id,
		    kpy.version,
		    kpy.close_date,
		    kpy.doc_date,
		    kpy.num,
		    kpy.obr_date,
		    kpy.pz_close_date,
		    kpy.szn_rec_id,
		    kpy.close_rsn_id,
		    kpy.pers_id,
		    kpy.pz_close_rsn_id,
		    kpy.szn_dep_id,
		    ( SELECT tpr.name
		           FROM psn_job_search_problem dfj,
		            ref_dict_line tpr
		          WHERE dfj.kpy_id = kpy.id AND tpr.id = dfj.tpr_id
		         LIMIT 1) AS tpr_name,
		    concat_ws(' '::text, pers.last_name, pers.first_name, pers.middle_name) AS fio,
		    kzf.name AS kzf_name,
		    szn.name AS szn_name,
		    rgn.name AS rgn_name,
		    rgn.id AS rgn_id,
		    NULL::bigint AS career_id,
		    NULL::bigint AS info_id,
		    NULL::bigint AS pob_id
		   FROM psn_kpy kpy
		     JOIN ref_szn szn ON szn.id = kpy.szn_dep_id and szn.rgn_id = coalesce(p_rgn_id, szn.rgn_id)
		     JOIN ref_rgn rgn ON rgn.id = szn.rgn_id
		     JOIN psn_kpy_info p_info ON p_info.id = kpy.info_id
		     LEFT JOIN ref_dict_line kzf ON kzf.id = p_info.kzf_id
		     JOIN psn_person pers ON pers.id = kpy.pers_id
		     JOIN psn_order ord12 ON ord12.kpy_id = kpy.id AND ord12.prkz_id = (
		       SELECT line.id FROM ref_dict_line line JOIN ref_dict dict ON line.dict_id = dict.id AND dict.code = 'ПРКЗ' AND line.code = '12' LIMIT 1
		     ) AND NOT EXISTS (
			SELECT NULL
			FROM psn_order order_o
			JOIN ref_dict_line rshs_o ON order_o.rshs_id = rshs_o.id AND rshs_o.code::text = 'О'::text
			WHERE order_o.parent_id = ord12.id
		     )
		     JOIN psn_order ordK ON ordK.kpy_id = kpy.id AND ordK.rshs_id = (
		       SELECT line.id FROM ref_dict_line line JOIN ref_dict dict ON line.dict_id = dict.id AND dict.code = 'РШС' AND line.code = 'К' LIMIT 1
		     ) AND NOT EXISTS (
			SELECT NULL
			FROM psn_order order_o
			JOIN ref_dict_line rshs_o ON order_o.rshs_id = rshs_o.id AND rshs_o.code::text = 'О'::text
			WHERE order_o.parent_id = ordK.id
		     )

		  WHERE ord12.order_date > ordK.order_date
			AND kpy.obr_date IS NOT NULL AND kpy.obr_date <= p_start_date
			AND (kpy.close_date IS NULL OR kpy.close_date <= p_finish_date)
		  ;


$$;
