create function fn_set_dw_region(p_start_rgn bigint, p_finish_rgn bigint) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
			res boolean  := true;
			BEGIN
			FOR r IN p_start_rgn .. p_finish_rgn
			LOOP
			/*-- 1218
			res := fn_dw_report_1218(r, null);
			IF (res is false) THEN
			EXIT;
			END IF;
			-- 1232
			res := fn_dw_report_1232(r, null);
			IF (res is false) THEN
			EXIT;
			END IF; */
			-- 1460
			res := fn_dw_report_1460(r, null);
			IF (res is false) THEN
			EXIT;
			END IF;
			END LOOP;
			RETURN res;
			END;
$$;
