CREATE MATERIALIZED VIEW rpt_doc_1422 AS SELECT szn.id,
    szn.version,
    szn.name,
    rgn.id AS rgn_id,
    rgn.name AS rgn_name,
    ( SELECT count(kpy.*) AS count
           FROM psn_kpy kpy
          WHERE ((kpy.szn_dep_id = szn.id) AND (kpy.close_date IS NOT NULL) AND (kpy.pz_close_date IS NOT NULL))) AS kpy_count
   FROM (ref_szn szn
     JOIN ref_rgn rgn ON ((szn.rgn_id = rgn.id)));
