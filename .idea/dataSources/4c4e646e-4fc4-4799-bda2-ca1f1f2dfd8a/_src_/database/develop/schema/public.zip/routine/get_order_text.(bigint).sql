create function get_order_text(orderid bigint) returns character varying
LANGUAGE plpgsql
AS $$
DECLARE
			title varchar := ' ';
			prkzName varchar := '';
			prkzCode varchar := '';
			scvName varchar := '';
			startDate date;
			rshsId bigint;
			rshsCode varchar := '';
			tvsCode varchar := '';
			tvsName varchar := '';
			rshsName varchar := '';
			tvsId bigint;
			startDateStr varchar := '';
			body varchar := '';
			endDate date;
			endDateStr varchar := '';
			result varchar := '';
			regionCoeff decimal;
			ifnId bigint;
			scvCode varchar := '';
			zp decimal;
			cr varchar := chr(13)||chr(10);
			algoId bigint;
			tab varchar := chr(9);
			limMaxId bigint;
			limMinId bigint;
			isMoneyHelp boolean;
			totalStajYears bigint;
			totalStajMonth bigint;
			totalStajDays bigint;
			stajLastYear bigint;
			ordParentNum varchar := '';
			ordParentDate date;
			isKeep boolean;

			BEGIN

			SELECT
			prkz.name
			,prkz.code
			,scv.name
			,scv.code
			,rshs.name
			,rshs.code
			,ord.rshs_id
			,tvs.code
			,tvs.name
			,ord.tvs_id
			,ord.rshs_id
			,ord.start_Date
			,ord.start_Date :: varchar
			,ord.end_date
			,ord.end_date :: varchar
			,ord.region_coeff
			,ord.ifn_id
			,ord.zp
			,ord.algo_id
			,ord.lim_max_id
			,ord.lim_min_id
			,ord.is_money_help
			,ord.total_staj_years
			,ord.total_staj_month
			,ord.total_staj_days
			,ord.staj_last_year
			,ord_parent.order_num
			,ord_parent.order_date
			,ord.is_keep
			INTO
			prkzName,
			prkzCode,
			scvName,
			scvCode,
			rshsName,
			rshsCode,
			rshsId,
			tvsCode,
			tvsName,
			tvsId,
			rshsId,
			startDate,
			startDateStr,
			endDate,
			endDateStr,
			regionCoeff,
			ifnId,
			zp,
			algoId,
			limMaxId,
			LimMinId,
			isMoneyHelp,
			totalStajYears,
			totalStajMonth,
			totalStajDays,
			stajLastYear,
			ordParentNum,
			ordParentDate,
			isKeep

			from psn_order ord
			left join ref_dict_line scv on scv.id = ord.scv_id
			left join ref_dict scv_ on scv.dict_id = scv_.id and scv_.code = 'СЦВ'
			left join ref_dict_line prkz on prkz.id =  ord.prkz_id
			left join ref_dict prkz_ on prkz.dict_id = prkz_.id and prkz_.code = 'ПРКЗ'
			left join ref_dict_line prp on prp.id = ord.prp_id
			left join ref_dict_line rshs on rshs.id = ord.rshs_id
			left join ref_dict_line tvs on tvs.id = ord.tvs_id
			left join psn_order ord_parent
			on ord.KPY_id = ord_parent.KPY_id
			and ord.parent_id = ord_parent.ID
			and ord.parent_id != ord.ID
			where ord.ID = orderId;

			tvsName =
			case  tvsName
			when 'Матподдержка' then 'матподдержки'
			when 'Другие' then 'других'
			when 'Финподдержка' then 'финподдержки'
			when 'Доплата' then 'доплаты'
			when 'Материальная помощь' then 'материальной помощи'
			when 'Общественные работы' then 'общественных работ'
			when 'Пособие' then 'пособия'
			when 'Стипендия' then 'стипендии'
			when 'Финансовая помощь' then 'финансовой помощи'
			else tvsName
			end;

			title = COALESCE(rshsName, '') || CASE WHEN prkzCode IN ('30','42','10','9','5','6','4','1','3','24','21','27','23','41') OR (rshsCode in ('Ц', 'Е', 'К', 'Н', 'П', 'ПИ', 'Р', 'У'))
			THEN ' ' || tvsName ELSE '' END;

			IF ((prkzCode = ('30') AND rshsId in (1732,1740,1731)) OR (prkzCode in ('42', '9', '6', '1', '21', '27', '41')) OR (rshsCode in ('П  ','ПИ ', 'У'))) then
			BEGIN
			if (ifnId is NULL) then
			SELECT prkz.id
			INTO ifnId
			FROM ref_dict_line prkz
			inner join ref_dict prkz_ on prkz.dict_id = prkz_.id and prkz_.code = 'ИФН'
			WHERE prkz.code= '3';
			end if;

			IF (tvsCode = 'Ф') then
			begin
			body = body || ' c ' ||  to_char(startDate, 'DD.MM.YYYY') || ' в размере ' || ltrim(str(zp,12,2)) || ' руб.';
			IF (infId IS NOT NULL) then
			select body || cr || 'Источник финансирования: ' || ifn .name
			into body
			FROM ref_dict_line ifn
			WHERE id = ifnId;
			end if;
			end;
			end if;

			body = ' с ' || to_char(startDate, 'DD.MM.YYYY');
			IF endDate IS NOT NULL then
			body = body || ' по ' || to_char(endDate, 'DD.MM.YYYY') ;
			end if;
			IF prkzCode = '27' then
			body = body || Tab || get_order_title(ordParentNum, ordParentDate, true);
			end if;
			IF prkzCode = '41' then
			body = body || Tab || get_order_title(ordParentNum, ordParentDate, true);
			end if;
			IF ifnId IS NOT NULL then
			select body || CR || 'Источник финансирования: ' ||  ifn.name
			into body
			FROM ref_dict_line ifn
			WHERE ifn.id = ifnId;
			end if;

			if tvsCode in ('П', 'С') then
			begin
			body = body || CR || 'Порядок начисления: ';

			IF (algoId IS NOT NULL) then
			SELECT  body || cr || tab || lower(ref_dict_line.name)
			into body
			FROM ref_dict_line
			WHERE id = algoId;
			end if;

			IF LimMaxId IS NOT NULL then
			SELECT  body || cr || tab || lower(NAME)
			into body
			FROM ref_dict_line
			WHERE id= LimMaxId;
			end if;
			IF LimMinId IS NOT NULL then
			SELECT body || cr || tab || lower(NAME)
			into body
			FROM ref_dict_line
			WHERE id= LimMinId;
			end if;
			IF coalesce(ZP,0) > 0 then
			body = body || cr || 'Средняя заработная плата: ' || to_char(zp, 'FM999999999999.99') || ' руб.';
			end if;

			IF regionCoeff > 1 then
			Body = Body || CR || 'Районный коэффициент: ' || regionCoeff :: text || '%';
			end if;
			IF (totalStajYears + totalStajMonth + totalStajDays + stajLastYear > 0) then
			Body = Body || cr || 'Справочно: трудовой стаж ' ||
			substring(totalStajYears ::text from 1 for 2) ||'/'||
			substring(totalStajMonth ::text from 1 for 2) ||'/'||
			substring(totalStajDays ::text from 1 for 2) || ' за 12 мес. ' ||
			substring(stajLastYear ::text from 1 for 3);
			end if;

			RETURN title || ' ' || body;

			end;
			end if;
			if tvsCode in ('М', 'А') then
			begin
			Body = Body || CR || 'Порядок начисления: ';
			IF (isMoneyHelp = false) then
			Body = Body || CR || Tab || 'самостоятельная выплата ';
			ELSE BEGIN
			Body = Body || CR || Tab || 'дополнительно к основной выплате ';
			IF ordParentNum IS NOT NULL then
			Body = Body || get_order_title(ordParentNum, ordParentDate, true);
			end if;
			END;
			Body = Body || CR || Tab || 'в размере ';
			END IF;
			if regionCoeff > 1 then
			Body = Body || CR || 'Районный коэффициент: ' || to_char(regionCoeff) + '%';
			end if;
			if isKeep is not null then
			Body = Body || CR || TAB ||'удержания производятся';
			end if;

			RETURN title || ' ' || body ||;
			end;
			end if;
			END;
			END IF;

			IF ((prkzCode = ('30') AND rshsId in (1725,1737,1739,1719,1720,1721,1722,1723))
			OR (prkzCode in ('13', '12', '8', '10', '24')) OR (rshsCode IN ('К', 'Я', 'Т', 'З', 'А', 'Ф', 'Ч'))) then
			BEGIN
			body = 'с ' || to_char(startDate, 'DD.MM.YYYY');
			IF ((prkzCode = '13' or rshsCode='А') and endDate is not null) then
			body = body || ', повторная регистрация ' || endDateStr;
			END IF;
			body = body || CR || get_order_title(ordParentNum, ordParentDate, true);
			END;
			ELSIF ((prkzCode = ('30') AND rshsId in (1729,1711,1717,1733,1734,1738))
			OR  (prkzCode in ('5', '4', '3', '2', '23', '22')) OR (rshsCode in ('Р', 'С', 'Б', 'Н', 'Ц', 'Е'))) then
			BEGIN

			body = 'с ' || to_char(startDate, 'DD.MM.YYYY') || ' по ' || to_char(endDate, 'DD.MM.YYYY') ||
			CASE WHEN startDate is not null and endDate is not null and endDate >= startDate
			then ' (' || ((endDate :: date - startDate :: date) + 1) :: varchar || ' дн.)'
			ELSE ''
			END;

			IF ((prkzCode = '22' OR rshsCode = 'Е') and coalesce(regionCoeff, 0) > 0) then
			body = body || ', продлить на ' || to_char(regionCoeff, 'FM9999') || ' дн.';
			END IF;

			body = body || CR || get_order_title(ordParentNum, ordParentDate, true);

			END;
			ELSIF (prkzCode = '11' OR rshsCode = 'О') then
			Body= get_order_title(ordParentNum, ordParentDate, false);
			ELSE
			BEGIN
			Body= CR || get_order_title(ordParentNum, ordParentDate, true);
			END;
			END IF;

			RETURN title || ' ' || body;

			END;



$$;
