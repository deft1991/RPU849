create function fn_report_1270_v3(p_rgn_id bigint, p_szn_id bigint, p_sid bigint, p_start_date date, p_finish_date date) returns TABLE(id bigint, kpy_id bigint, version bigint, doc_date date, num character varying, obr_date date, pz_close_date date, szn_rec_id character varying, close_rsn_id bigint, pers_id bigint, pz_close_rsn_id bigint, szn_dep_id bigint, close_date date, sys_id character varying, career_id bigint, info_id bigint, pob_id bigint, rgn_id bigint, tpr character varying, fio character varying, szn character varying, rgn character varying, oper_date date, birth_date date, kzf character varying, period character varying, date_diff bigint, scv_name character varying)
LANGUAGE plpgsql
AS $$
DECLARE
  r RECORD;
BEGIN
  -- ================================================================
  -- DDL
  -- ================================================================
  BEGIN
    TRUNCATE tmp_report_1270;
  EXCEPTION WHEN others THEN
      create temporary table tmp_report_1270(
          id bigserial
        , marker int8
        , kpy_id int8
        , oper_date date
        , start_date date
        , end_date date
        , scv_name varchar
        , kzf_name varchar
        , paid_date date
        , prd_sum numeric(17,2)
        , soc_prd_id int8
        , scv_id int8
        , kzf_id int8
      );
      create index tmp_1270_ind1 on tmp_report_1270 (kpy_id);
  END;
  --
  IF p_sid IS NOT NULL THEN
    -- МДН
    INSERT INTO tmp_report_1270(
      marker
      , kpy_id
      , oper_date
      , start_date
      , end_date
      , scv_name
      , kzf_name
      , paid_date
      , prd_sum
    )
      SELECT DISTINCT
        1
        , kpy.id AS kpy_id
        , soc_prd.oper_date
        , soc_prd.start_date
        , soc_prd.end_date
        , scv.name AS scv_name
        , kzf.name AS kzf_name
        , min(coalesce(sum_paid.oper_date, talon.tdate)) AS paid_date
        , sum(coalesce(soc_sum.summ, 0)) AS prd_sum
      FROM psn_kpy kpy
        INNER JOIN rpt_param param ON param.num_value = kpy.id
                                      AND param.sid = p_sid
                                      AND param.report = '1270'
                                      AND param.param = 'KPY_ID'
        INNER JOIN psn_kpy_info info ON info.id = kpy.info_id
        LEFT JOIN ref_dict_line kzf ON kzf.id = info.kzf_id
                                       AND EXISTS (SELECT null FROM ref_dict dic WHERE dic.id = kzf.dict_id AND dic.code = 'КЗФ')
        INNER JOIN ref_szn szn ON kpy.szn_dep_id = szn.id
        INNER JOIN psn_order ord ON ord.kpy_id = kpy.id
                                    AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line stp WHERE dic.id = stp.dict_id AND dic.code = 'СТП' AND stp.code = '1' AND stp.id = coalesce(ord.status_id, stp.id))
        INNER JOIN ref_dict_line scv ON scv.id = ord.scv_id
                                        AND EXISTS (SELECT null FROM ref_dict dic WHERE dic.id = scv.dict_id AND dic.code = 'СЦВ')
        INNER JOIN psn_soc_payment_card soc_card ON soc_card.order_id = ord.id
        INNER JOIN psn_soc_payment_period soc_prd ON soc_prd.soc_pmnts_card_id = soc_card.id
        INNER JOIN psn_soc_payment_sum soc_sum ON soc_sum.pmnts_period_id = soc_prd.id
                                                  AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line tn4 WHERE dic.id = tn4.dict_id AND dic.code = 'ТНЧ' AND tn4.code NOT IN ('Н', 'О') AND tn4.id = soc_sum.tnch_id)
                                                  AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line vnu WHERE dic.id = vnu.dict_id AND dic.code = 'ВНУ' AND vnu.code IN ('Б', 'И', 'Р', 'Ч', 'П') AND vnu.id = soc_sum.vnu_id)
                                                  AND soc_sum.is_set = true
        INNER JOIN sys_talon talon ON talon.sys_id = soc_sum.sys_id
        LEFT JOIN psn_soc_payment_sum_paid sum_paid ON sum_paid.pmnts_period_id = soc_prd.id
      WHERE 1 = 1
            AND szn.rgn_id = coalesce(p_rgn_id, szn.rgn_id)
            AND szn.id = coalesce(p_szn_id, szn.id)
            AND soc_prd.oper_date BETWEEN coalesce(p_start_date, soc_prd.oper_date) AND coalesce(p_finish_date, soc_prd.oper_date)
            AND coalesce(soc_prd.is_recalc, false) = false
            AND soc_sum.summ > 0
      GROUP BY kpy.id, soc_prd.id, scv.id, kzf.id
    ;
    --
    INSERT INTO tmp_report_1270(
      marker
      , kpy_id
      , oper_date
      , scv_name
      , paid_date
      , prd_sum
    )
      SELECT DISTINCT
        2
        , kpy.id AS kpy_id
        , soc_prd.oper_date
        , scv.name AS scv_name
        , min(coalesce(sum_paid.oper_date, talon.tdate)) AS paid_date
        , sum(coalesce(soc_sum.summ, 0)) AS prd_sum
      FROM psn_kpy kpy
        INNER JOIN rpt_param param ON param.num_value = kpy.id
                                      AND param.sid = p_sid
                                      AND param.report = '1270'
                                      AND param.param = 'KPY_ID'
        INNER JOIN ref_szn szn ON kpy.szn_dep_id = szn.id
        INNER JOIN psn_order ord ON ord.kpy_id = kpy.id
                                    AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line stp WHERE dic.id = stp.dict_id AND dic.code = 'СТП' AND stp.code = '1' AND stp.id = coalesce(ord.status_id, stp.id))
        INNER JOIN ref_dict_line scv ON scv.id = ord.scv_id
                                        AND EXISTS (SELECT null FROM ref_dict dic WHERE dic.id = scv.dict_id AND dic.code = 'СЦВ')
        INNER JOIN psn_soc_payment_card soc_card ON soc_card.order_id = ord.id
        INNER JOIN psn_soc_payment_period soc_prd ON soc_prd.soc_pmnts_card_id = soc_card.id
        INNER JOIN sys_talon talon ON talon.sys_id = soc_prd.sys_id
        LEFT JOIN psn_soc_payment_sum soc_sum ON soc_sum.pmnts_period_id = soc_prd.id
                                                 AND soc_sum.is_set = false
        LEFT JOIN psn_soc_payment_sum_paid sum_paid ON sum_paid.pmnts_period_id = soc_prd.id
      WHERE 1 = 1
            AND szn.rgn_id = coalesce(p_rgn_id, szn.rgn_id)
            AND szn.id = coalesce(p_szn_id, szn.id)
            AND soc_prd.oper_date BETWEEN p_start_date AND p_finish_date
            AND coalesce(soc_prd.is_recalc, false) = false
      GROUP BY kpy.id, soc_prd.oper_date, scv.id
    ;
    --
    DELETE FROM rpt_param WHERE sid = p_sid AND report = '1270';
    --	
  ELSE
    -- Отчет
    insert into tst_log(report_name, duration, rgn_id, szn_id, date_time) values('start 1270',  null, p_rgn_id, p_szn_id, clock_timestamp()::timestamp);
    INSERT INTO tmp_report_1270(
      marker
      , kpy_id
      , oper_date
      , start_date
      , end_date
      , scv_name
      , kzf_name
      , paid_date
      , prd_sum
      , soc_prd_id
      , scv_id
      , kzf_id
    )
      WITH
        -- 178 = //stp1 as (SELECT stp.id FROM ref_dict dic, ref_dict_line stp WHERE dic.id = stp.dict_id AND dic.code = 'СТП' AND stp.code = '1'),
          scv as (SELECT scv.id, scv.name FROM ref_dict dic, ref_dict_line scv WHERE dic.id = scv.dict_id AND dic.code = 'СЦВ'),
          kzf as (SELECT kzf.id, kzf.name FROM ref_dict dic, ref_dict_line kzf WHERE dic.id = kzf.dict_id AND dic.code = 'КЗФ'),
          kpy as (SELECT kpy.id kpy_id, ord.id ord_id, ord.scv_id
                  FROM psn_kpy kpy INNER JOIN psn_order ord ON ord.kpy_id = kpy.id AND coalesce(ord.status_id,178) = 178
                  WHERE (p_szn_id IS NOT NULL AND kpy.szn_dep_id = p_szn_id) OR (p_szn_id IS NULL AND (p_rgn_id IS NULL OR kpy.szn_dep_id IN (SELECT id FROM ref_szn WHERE rgn_id = p_rgn_id)))
        )
      SELECT DISTINCT
        1
        , kpy.kpy_id
        , sp.oper_date
        , sp.start_date
        , sp.end_date
        , scv.name AS scv_name
        , kzf.name AS kzf_name
        , coalesce(sum_paid.oper_date, talon.tdate) AS paid_date
        , sp.prd_sum
        , sp.prd_id
        , scv.id scv_id
        , kzf.id kzf_id
      FROM kpy
        INNER JOIN fn_vm_soc_prd sp ON sp.order_id = kpy.ord_id
            AND (sp.oper_date is null
                 or (p_start_date is null and p_finish_date is null)
                 or sp.oper_date BETWEEN coalesce(p_start_date, sp.oper_date) AND coalesce(p_finish_date, sp.oper_date))
        INNER JOIN psn_kpy ON psn_kpy.id = kpy.kpy_id
        LEFT JOIN scv ON scv.id = kpy.scv_id
        LEFT JOIN psn_kpy_info info ON info.id = psn_kpy.info_id
        LEFT JOIN kzf ON kzf.id = info.kzf_id
        LEFT JOIN sys_talon talon ON talon.sys_id = psn_kpy.sys_id
        LEFT JOIN psn_soc_payment_sum_paid sum_paid ON sum_paid.pmnts_period_id = sp.prd_id
    ;
    insert into tst_log(report_name, duration, rgn_id, szn_id, date_time) values('start 1270  step 1',  null, p_rgn_id, p_szn_id, clock_timestamp()::timestamp);
    INSERT INTO tmp_report_1270(
      marker
      , kpy_id
      , oper_date
      , start_date
      , end_date
      , scv_name
      , kzf_name
      , paid_date
      , prd_sum
    )
      SELECT
        2
        , a.kpy_id
        , a.oper_date
        , a.start_date
        , a.end_date
        , a.scv_name
        , a.kzf_name
        , min(a.paid_date) -- min
        , sum(a.prd_sum)  -- sum
      FROM tmp_report_1270 a
      WHERE a.marker = 1
      GROUP BY a.kpy_id, a.oper_date , a.start_date, a.end_date, a.scv_name, a.kzf_name, a.soc_prd_id, a.scv_id, a.kzf_id
    ;
    insert into tst_log(report_name, duration, rgn_id, szn_id, date_time) values('start 1270  step 2',  null, p_rgn_id, p_szn_id, clock_timestamp()::timestamp);
    --
    INSERT INTO tmp_report_1270(
      marker
      , kpy_id
      , oper_date
      , scv_name
      , paid_date
      , prd_sum
    )
      SELECT DISTINCT
        3
        , kpy.id AS kpy_id
        , soc_prd.oper_date
        , scv.name AS scv_name
        , min(coalesce(sum_paid.oper_date, talon.tdate)) AS paid_date
        , sum(coalesce(soc_sum.summ, 0)) AS prd_sum
      FROM tmp_report_1270 t1
        LEFT JOIN psn_kpy kpy on kpy.id = t1.kpy_id
        INNER JOIN ref_szn szn ON kpy.szn_dep_id = szn.id
        INNER JOIN psn_order ord ON ord.kpy_id = kpy.id
                                    AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line stp WHERE dic.id = stp.dict_id AND dic.code = 'СТП' AND stp.code = '1' AND stp.id = coalesce(ord.status_id, stp.id))
        INNER JOIN ref_dict_line scv ON scv.id = ord.scv_id
                                        AND EXISTS (SELECT null FROM ref_dict dic WHERE dic.id = scv.dict_id AND dic.code = 'СЦВ')
        INNER JOIN psn_soc_payment_card soc_card ON soc_card.order_id = ord.id
        INNER JOIN psn_soc_payment_period soc_prd ON soc_prd.soc_pmnts_card_id = soc_card.id
        INNER JOIN sys_talon talon ON talon.sys_id = soc_prd.sys_id
        LEFT JOIN psn_soc_payment_sum soc_sum ON soc_sum.pmnts_period_id = soc_prd.id
                                                 AND soc_sum.is_set = false
        LEFT JOIN psn_soc_payment_sum_paid sum_paid ON sum_paid.pmnts_period_id = soc_prd.id
      WHERE 1 = 1
            AND t1.marker = 2
            AND szn.rgn_id = p_rgn_id
            AND szn.id = p_szn_id
            AND soc_prd.oper_date BETWEEN soc_prd.oper_date AND soc_prd.oper_date
            AND coalesce(soc_prd.is_recalc, false) = false
      GROUP BY szn.rgn_id, szn.id, kpy.id, soc_prd.oper_date, scv.id
    ;
    --
    insert into tst_log(report_name, duration, rgn_id, szn_id, date_time) values('start 1270  step 3',  null, p_rgn_id, p_szn_id, clock_timestamp()::timestamp);
    --			
  END IF;
  -- ================================================================
  -- Итог
  -- ================================================================	     
  FOR r IN (
    SELECT DISTINCT
        t1.kpy_id AS kpy_id
      , kpy.version AS version
      , t1.oper_date AS oper_date
      , kpy.num AS kpy_num
      , pers.last_name || ' ' || pers.first_name || ' ' || pers.middle_name as fio
      , szn.name as szn
      , rgn.name as rgn
      , kpy.obr_date as obr_date
      , pers.birth_date AS birth_date
      , t1.kzf_name AS kzf_name
      , to_char(t1.start_date, 'DD.MM.YYYY') || ' - ' || to_char(t1.end_date, 'DD.MM.YYYY') AS period
      , date_part('day', t1.paid_date::timestamp - t1.oper_date::timestamp) AS date_count
      , t1.scv_name AS scv_name
    FROM tmp_report_1270 t1
      INNER JOIN tmp_report_1270 t2 ON t1.kpy_id = t2.kpy_id AND t1.oper_date =  t2.oper_date AND t1.scv_name = t2.scv_name
      INNER JOIN psn_kpy kpy ON kpy.id = t1.kpy_id
      INNER JOIN psn_person pers ON pers.id = kpy.pers_id
      INNER JOIN ref_szn szn ON szn.id = kpy.szn_dep_id
      INNER JOIN ref_rgn rgn ON rgn.id = szn.rgn_id
    WHERE 1 = 1
          AND t1.marker = 2
          AND t2.marker = 3
          AND t2.prd_sum < t1.prd_sum
          AND t1.paid_date > t1.oper_date
  )
  LOOP
    id := nextval('seq_mdn_kpy');
    kpy_id := r.kpy_id;
    version := r.version;
    doc_date := null;
    num := r.kpy_num;
    obr_date := r.obr_date;
    pz_close_date := null;
    szn_rec_id := null;
    close_rsn_id := null;
    pers_id := null;
    pz_close_rsn_id := null;
    szn_dep_id := null;
    close_date := null;
    sys_id := null;
    career_id := null;
    info_id := null;
    pob_id := null;
    rgn_id := null;
    tpr := null;
    oper_date := r.oper_date;
    fio := r.fio;
    szn := r.szn;
    rgn := r.rgn;
    birth_date := r.birth_date;
    kzf := r.kzf_name;
    period := r.period;
    date_diff := r.date_count;
    scv_name := r.scv_name;
    RETURN NEXT;
  END LOOP;
  insert into tst_log(report_name, duration, rgn_id, szn_id, date_time) values('start 1270  step 4',  null, p_rgn_id, p_szn_id, clock_timestamp()::timestamp);
  --
END;
$$;
