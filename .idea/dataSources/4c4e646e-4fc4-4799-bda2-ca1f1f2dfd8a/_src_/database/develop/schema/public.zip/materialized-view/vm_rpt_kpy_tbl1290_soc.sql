CREATE MATERIALIZED VIEW vm_rpt_kpy_tbl1290_soc AS SELECT soc_card.order_id,
    soc_paid.oper_date AS paid_oper_date,
    soc_sum.oper_date AS sum_oper_date,
    soc_prd.id AS period_id
   FROM (((((psn_soc_payment_sum soc_sum
     JOIN ref_dict_line tn4 ON (((tn4.id = soc_sum.tnch_id) AND ((tn4.code)::text <> ALL (ARRAY[('Н'::character varying)::text, ('О'::character varying)::text])))))
     JOIN ref_dict_line vnu ON (((vnu.id = soc_sum.vnu_id) AND ((vnu.code)::text = ANY (ARRAY[('Б'::character varying)::text, ('И'::character varying)::text, ('Р'::character varying)::text, ('Ч'::character varying)::text, ('П'::character varying)::text])))))
     JOIN psn_soc_payment_period soc_prd ON (((soc_sum.pmnts_period_id = soc_prd.id) AND (soc_prd.is_recalc <> true))))
     JOIN psn_soc_payment_sum_paid soc_paid ON (((soc_paid.pmnts_period_id = soc_prd.id) AND (soc_paid.oper_date IS NOT NULL))))
     JOIN psn_soc_payment_card soc_card ON ((soc_prd.soc_pmnts_card_id = soc_card.id)));
CREATE INDEX vm_tbl1290_soc_order_index
  ON vm_rpt_kpy_tbl1290_soc (order_id);
