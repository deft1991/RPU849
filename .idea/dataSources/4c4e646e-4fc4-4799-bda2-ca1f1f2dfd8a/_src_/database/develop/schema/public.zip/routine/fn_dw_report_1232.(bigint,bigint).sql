create function fn_dw_report_1232(p_rgn_id bigint, p_szn_id bigint) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
      BEGIN
           DELETE FROM dw_rep1232
           WHERE 1 = 1
             AND szn_id = coalesce(p_szn_id, szn_id)
             AND rgn_id = coalesce(p_rgn_id, rgn_id)
           ;
           --
      	INSERT INTO dw_rep1232(
      	  version
      	, kpy_num
      	, fio
      	, szn_id
      	, rgn_id
      	, obr_date
      	, close_date
      	, pol_id
      	, kzf_id
      	, kng_id
      	, tpr_id
      	, puv_id
      	, prof_name
      	, age
      	, age_child
      	, uro_id
      	, vob_id
      	, is_bg
      	, cnt
      	)
      	SELECT DISTINCT
      	  0 AS version
      	, coalesce(kpy.num, '') as kpy_num -- Рег. номер
      	, pers.last_name || ' ' || pers.first_name || ' ' || pers.middle_name as fio -- ФИО
      	, szn.id AS szn_id -- СЗН
      	, rgn.id AS rgn_id -- Регион
      	, kpy.obr_date AS obr_date -- Дата обращения
      	, kpy.close_date AS close_date -- Дата закрытия
      	, coalesce(pol.id, 0) AS pol_id -- Пол
      	, coalesce(inf.kzf_id, 0) AS kzf_id -- Отношения к занятости
      	, coalesce(kng.kng_id, 0) AS kng_id -- Категория незанятости
      	, coalesce(jsp.tpr_id, 0) AS tpr_id -- Категория испытывающего трудности в поисках работы
      	, coalesce(prw.puv_id, 0) AS puv_id -- Причина увольнения
      	, coalesce(std.prof_name, '') AS prof_name -- Специальность проф. обучения
      	, fn_count_year(pers.birth_date, kpy.obr_date)AS age -- Возраст
      	, fn_max_age_child(kpy.id, std.start_date ) AS age_child -- Возраст ребенка
      	, coalesce(edu.uro_id, 0) AS uro_id -- Уровень образования
      	, coalesce(std.vob_id, 0) AS vob_id -- Вид обучения
      	, (CASE WHEN pers.unempl_date IS NULL THEN true ELSE false END) AS is_bg -- Признак безработного
      	, 1 AS cnt -- Мера
      	FROM psn_kpy kpy
      	INNER JOIN psn_person pers ON pers.id = kpy.pers_id
      	INNER JOIN ref_szn szn ON szn.id = kpy.szn_dep_id
      	INNER JOIN ref_rgn rgn ON rgn.id = szn.rgn_id
      	INNER JOIN psn_study std ON std.kpy_id = kpy.id
      	INNER JOIN ref_dict_line pob ON pob.id = kpy.pob_id
      	INNER JOIN ref_dict_line psu ON psu.id = kpy.close_rsn_id
      	INNER JOIN psn_kpy_info inf ON kpy.info_id = inf.id
      	LEFT JOIN ref_dict_line pol ON pol.id = pers.pol_id
      	LEFT JOIN psn_job_search_problem jsp ON jsp.kpy_id = kpy.id
      	LEFT JOIN ref_prof prf ON prf.id = std.prof_id
      	LEFT JOIN psn_kng kng ON kng.kpy_id = kpy.id
      	LEFT JOIN psn_prev_work prw ON prw.kpy_id = kpy.id AND prw.is_last = true
      	LEFT JOIN psn_education edu ON edu.pers_id = pers.id
      	WHERE 1 = 1
             AND szn.id = coalesce(p_szn_id, szn.id)
             AND rgn.id = coalesce(p_rgn_id, rgn.id)
      	  AND psu.code = '12'
      	  AND pob.code = '1'
      	  AND kpy.close_date IS NOT NULL
      	  AND std.start_date IS NOT NULL
      	;
      	return true;
      	--
      END;
$$;
