create function kpy_tbl1293(p_rgn_id bigint, p_szn_id bigint, p_start_date date, p_end_date date) returns TABLE(kpy_id bigint, order_id bigint, period character varying, p_count_pay bigint, job_period character varying, duration bigint, n_pr bigint, last_date_reg date, last_date_sum date, p_finish_date date, p_is_without_suspense character varying)
LANGUAGE plpgsql
AS $$
DECLARE
					  r RECORD;
					BEGIN
						-- ================================================================
						-- DDL
						-- ================================================================
						if ((not exists (select 1 from pg_tables where tablename='tmp_report_1293'))
							or
						((SELECT iftableexists('tmp_report_1293') = 'F'))) then
							create temporary table tmp_report_1293(
							  id bigserial
							, marker int8
							, kpy_id int8
							, order_id int8
							, soc_prd_id int8
							, sum_paid_date date
							, yy varchar(4)
							, mm varchar(2)
							, start_date date
							, end_date date
							, job_period varchar(100)
							, ord int8
							, duration int8
							, n_pr int8
							, last_date_reg date
							, last_date_sum date
							, p_finish_date date
							, p_count_pay int8
							);
						else
						  DELETE FROM tmp_report_1293;
						 end if;
						-- ================================================================
						-- Фактические выплаты, с датой выплаты до конца отчетного периода
						-- Берется только первая выплата в каждом расчете
						-- ================================================================
						 INSERT INTO tmp_report_1293(
						  marker
						, kpy_id
						, order_id
						, soc_prd_id
						, sum_paid_date
						, p_finish_date
						)
						SELECT
						  1
						, kpy.id
						, ord_17.id
						, soc_prd.id
						, min(sum_paid.oper_date)
						, kpy.obr_date
						FROM psn_kpy kpy
						INNER JOIN ref_szn szn ON kpy.szn_dep_id = szn.id
						INNER JOIN psn_order ord_17 ON ord_17.kpy_id = kpy.id
							AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line prkz_17 WHERE dic.id = prkz_17.dict_id AND dic.code = 'ПРКЗ' AND prkz_17.code IN ('1', '7') AND prkz_17.id = ord_17.prkz_id)
							AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line stp WHERE dic.id = stp.dict_id AND dic.code = 'СТП' AND stp.code = '1' AND stp.id = coalesce(ord_17.status_id, stp.id))
						INNER JOIN psn_soc_payment_card soc_card ON soc_card.order_id = ord_17.id
						INNER JOIN psn_soc_payment_period soc_prd ON soc_prd.soc_pmnts_card_id = soc_card.id
						INNER JOIN psn_soc_payment_sum soc_sum ON soc_sum.pmnts_period_id = soc_prd.id
							AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line tn4 WHERE dic.id = tn4.dict_id AND dic.code = 'ТНЧ' AND tn4.code NOT IN ('Н', 'О') AND tn4.id = soc_sum.tnch_id)
							AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line vnu WHERE dic.id = vnu.dict_id AND dic.code = 'ВНУ' AND vnu.code IN ('Б', 'И', 'Р', 'Ч', 'П') AND vnu.id = soc_sum.vnu_id)
						INNER JOIN psn_soc_payment_sum_paid sum_paid ON sum_paid.pmnts_period_id = soc_prd.id
						WHERE 1 = 1
						  AND kpy.szn_dep_id = coalesce(p_szn_id, kpy.szn_dep_id)
						  AND szn.rgn_id = coalesce(p_rgn_id, szn.rgn_id)
						  --AND szn.rgn_id = 34
						  AND coalesce(soc_prd.is_recalc, false) = false
						  AND sum_paid.oper_date IS NOT NULL
						  AND soc_sum.summ > 0
						  AND coalesce(ord_17.start_date, sum_paid.oper_date) <= sum_paid.oper_date
						  --AND kpy.obr_date <= to_date('31.12.2016', 'DD.MM.YYYY')
						  AND soc_sum.oper_date <= coalesce(kpy.close_date, soc_sum.oper_date)
						  --AND kpy.id = 5417539834
						  AND kpy.obr_date >= p_start_date
						  AND kpy.obr_date <= p_end_date
						GROUP BY kpy.id, ord_17.id, soc_prd.id, kpy.obr_date
						;
						-- ================================================================
						-- Сформируем сетку месячных периодов выплат по каждому ЛД
						-- ================================================================
						INSERT INTO tmp_report_1293(
						  marker
						, kpy_id
						, order_id
						, start_date
						, end_date
						, p_finish_date
						)
						SELECT DISTINCT
						  2
						, ord.kpy_id
						, ord.id
						, ord.start_date
						, fn_min_date(coalesce(ord_8.start_date, ord.end_date), coalesce(kpy.close_date, talon.tdate)) AS dt
						, t.p_finish_date
						FROM tmp_report_1293 t
						INNER JOIN psn_kpy kpy ON kpy.id = t.kpy_id
						INNER JOIN psn_order ord ON ord.kpy_id = t.kpy_id
						LEFT JOIN psn_order ord_8 ON ord_8.kpy_id = kpy.id
							AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line prkz_8 WHERE dic.id = prkz_8.dict_id AND dic.code = 'ПРКЗ' AND prkz_8.code IN ('8') AND prkz_8.id = ord_8.prkz_id)
							AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line stp WHERE dic.id = stp.dict_id AND dic.code = 'СТП' AND stp.code = '1' AND stp.id = coalesce(ord_8.status_id, stp.id))
						LEFT JOIN sys_talon talon ON talon.sys_id = ord.sys_id
						WHERE 1 = 1
						  AND t.marker = 1
						;
						--
						INSERT INTO tmp_report_1293(
						  marker
						, kpy_id
						, order_id
						, start_date
						, end_date
						, p_finish_date
						)
						SELECT
						  3
						, t.kpy_id
						, t.order_id
						, (CASE WHEN TO_CHAR(t.start_date, 'DD') != '01' THEN to_date(to_char(t.start_date + interval'1 month', 'YYYY.MM') || '.01', 'YYYY.MM.DD') ELSE t.start_date END )::date AS start_date
						, (CASE WHEN TO_CHAR(t.end_date, 'MM') != TO_CHAR(t.end_date + interval'1 day' , 'MM') THEN t.end_date ELSE (date_trunc('month', t.end_date) - interval'1 day')  END)::date AS end_date
						, t.p_finish_date
						FROM tmp_report_1293 t
						WHERE 1 = 1
						  AND t.marker = 2
						;
						--
						INSERT INTO tmp_report_1293(
						  marker
						, kpy_id
						, order_id
						, yy
						, mm
						, p_count_pay
						, p_finish_date
						)
						SELECT
						  4
						, t.kpy_id
						, t.order_id
						, to_char(t.sum_paid_date, 'YYYY')
						, to_char(t.sum_paid_date, 'MM')
						, count(*)
						, t.p_finish_date
						FROM tmp_report_1293 t
						WHERE 1 = 1
						  AND t.marker = 1
						GROUP BY t.kpy_id, t.order_id, to_char(t.sum_paid_date, 'YYYY'), to_char(t.sum_paid_date, 'MM'), t.p_finish_date
						;
						--
						INSERT INTO tmp_report_1293(
						  marker
						, kpy_id
						, order_id
						, yy
						, mm
						, start_date
						, end_date
						, p_count_pay
						, p_finish_date
						)
						SELECT
						  5
						, t3.kpy_id
						, t3.order_id
						, t4.yy
						, t4.mm
						, period.begin_date
						, period.end_date
						, coalesce(t4.p_count_pay, 0)
						, t4.p_finish_date
						FROM tmp_report_1293 t3
						INNER JOIN ref_period period ON period.begin_date <= t3.end_date AND period.end_date >= t3.start_date
						LEFT JOIN tmp_report_1293 t4 ON t4.marker = 4
							AND t4.order_id = t3.order_id
							AND period.begin_date = to_date('01.' || t4.mm || '.' ||t4.yy , 'DD.MM.YYYY')
						WHERE 1 = 1
						  AND t3.marker = 3
						  AND t3.start_date < t3.end_date
						;
						-- ================================================================
						-- Приказы Приостановить и Не производить в отобранных периодах выплат
						-- ================================================================
						UPDATE tmp_report_1293
							SET duration = ORD.duration
						FROM (
							SELECT
							  t5.id AS period_id
							, MAX(fn_min_date(t5.end_date, ord_34.end_date) - fn_max_date(t5.start_date, ord_34.start_date) ) + 1 AS duration
						   FROM tmp_report_1293 t5
						   INNER JOIN tmp_report_1293 t1 ON t1.marker = 1
							AND t1.kpy_id = t5.kpy_id
						   INNER JOIN psn_order ord_34 ON ord_34.kpy_id = t1.kpy_id
							AND ord_34.start_date <= t5.end_date
							AND ord_34.end_date >= t5.start_date
							AND ord_34.parent_id = t1.order_id
							AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line prkz WHERE dic.id = prkz.dict_id AND dic.code = 'ПРКЗ' AND prkz.code IN ('3', '4') AND prkz.id = ord_34.prkz_id)
							AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line stp WHERE dic.id = stp.dict_id AND dic.code = 'СТП' AND stp.code IN ('1', '2') AND stp.id = coalesce(ord_34.status_id, stp.id))
						   WHERE 1 = 1
							 AND t5.marker = 5
						   GROUP BY t5.id
						) ORD
						WHERE 1 = 1
							AND marker = 5
							AND id = ORD.period_id
						;
						-- ================================================================
						-- Общественные работы
						-- ================================================================
						UPDATE tmp_report_1293
							SET job_period = WRK.period
						FROM (
							SELECT
							 t5.id AS period_id
						   , to_char(fn_max_date(t5.start_date, job.start_date), 'DD.MM.YY') || ' - ' || to_char(fn_min_date(t5.end_date, job.end_date), 'DD.MM.YY') AS period
						   , ROW_NUMBER() OVER(PARTITION BY t5.id ORDER BY job.start_date) AS r
						   FROM tmp_report_1293 t5
						   INNER JOIN tmp_report_1293 t1 ON t1.marker = 1
							AND t1.kpy_id = t5.kpy_id
						   INNER JOIN psn_job job ON job.kpy_id = t1.kpy_id
								AND EXISTS (SELECT null FROM ref_dict dic, ref_dict_line vtr WHERE dic.id = vtr.dict_id AND dic.code = 'ВТР' AND vtr.code IN ('3') AND vtr.id = job.vtr_id)
								AND job.end_date >= t5.start_date
								AND job.start_date <= t5.end_date
						   WHERE 1 = 1
							 AND t5.marker = 5
						) WRK
						WHERE 1 = 1
							AND marker = 5
							AND id = WRK.period_id
						;
						--
						-- ================================================================
						-- Перерегистрации
						-- ================================================================
						UPDATE tmp_report_1293
							SET n_pr = RR.cnt_prd
							, last_date_reg = RR.vis_fact_date
						FROM (
							SELECT t5.id AS period_id
							, count(*) AS cnt_prd
							, max(visit.fact_date) AS vis_fact_date
							FROM tmp_report_1293 t5
							INNER JOIN psn_visit visit ON visit.kpy_id = t5.kpy_id
								AND EXISTS (SELECT ps6.* FROM ref_dict dic, ref_dict_line ps6 WHERE dic.id = ps6.dict_id AND dic.code = 'ПСЩ' AND ps6.code IN ('02') AND ps6.id = visit.pssch_id)
								AND visit.fact_date BETWEEN t5.start_date AND t5.end_date
							WHERE 1 = 1
								AND t5.marker = 5
							GROUP BY t5.id
						) RR
						WHERE 1 = 1
							AND marker = 5
							AND id = RR.period_id
						;
						-- ================================================================
						-- Выплаты
						-- ================================================================
						UPDATE tmp_report_1293
							SET last_date_sum = PM.sum_paid_date
		 				FROM (
							SELECT t5.id AS period_id
							, max(sum_paid.oper_date) AS sum_paid_date
							FROM tmp_report_1293 t5
							INNER JOIN psn_order ord ON ord.kpy_id = t5.kpy_id
								AND EXISTS (SELECT scv.* FROM ref_dict dic, ref_dict_line scv WHERE dic.id = scv.dict_id AND dic.code = 'СЦВ' AND scv.code IN ('01') AND scv.id = ord.scv_id)
							INNER JOIN psn_soc_payment_card soc_card ON soc_card.order_id = ord.id
							INNER JOIN psn_soc_payment_period soc_prd ON soc_prd.soc_pmnts_card_id = soc_card.id
							INNER JOIN psn_soc_payment_sum_paid sum_paid ON sum_paid.pmnts_period_id = soc_prd.id
							WHERE 1 = 1
								AND t5.marker = 5
								AND sum_paid.summ > 0
								--AND sum_paid.oper_date <= to_date('31.12.2016', 'DD.MM.YYYY')
								--AND sum_paid.oper_date <= p_finish_date
							GROUP BY t5.id
						 ) PM
						 WHERE 1 = 1
							AND marker = 5
							AND id = PM.period_id
						;
						-- ================================================================
						-- Итоговый отбор
						-- ================================================================
						INSERT INTO tmp_report_1293(
						  marker
						, kpy_id
						, order_id
						, yy
						, mm
						, job_period
						, duration
						, ord
						, n_pr
						, last_date_reg
						, last_date_sum
						, p_finish_date
						, p_count_pay
						)
						SELECT
						  6
						, t5.kpy_id
						, t5.order_id
						, t5.yy
						, t5.mm
						, t5.job_period
						, t5.duration
						, ROW_NUMBER() OVER(PARTITION BY  t5.order_id ORDER BY t5.order_id, t5.p_count_pay, t5.yy, t5.mm) AS ord
						, t5.n_pr
						, t5.last_date_reg
						, t5.last_date_sum
						, t5.p_finish_date
						, t5.p_count_pay
						FROM tmp_report_1293 t5
						WHERE 1 = 1
						  AND t5.marker = 5
						;
						-- ================================================================
						-- Итог
						-- ================================================================
						FOR r IN (
								SELECT
								  t.kpy_id
								, t.order_id
								, t.yy || '.' || t.mm  AS period
								, t.p_count_pay
								, t.job_period
								, (CASE WHEN t.duration = 0 THEN null ELSE t.duration END) AS duration
								, t.n_pr
								, t.last_date_reg
								, t.last_date_sum
								, t.p_finish_date
								, (CASE WHEN coalesce(t.duration, 0) = 0 THEN 'Да' ELSE 'Нет' END) AS p_is_without_suspense
								FROM tmp_report_1293 t
								WHERE 1 = 1
								  AND t.marker = 6
								  AND t.ord = 1
							 )
						LOOP
						  kpy_id := r.kpy_id;
						  order_id := r.order_id;
						  period := r.period;
						  p_count_pay := r.p_count_pay;
						  job_period := r.job_period;
						  duration := r.duration;
						  n_pr := r.n_pr;
						  last_date_reg := r.last_date_reg;
						  last_date_sum := r.last_date_sum;
						  p_finish_date := r.p_finish_date;
						  p_is_without_suspense := r.p_is_without_suspense;
						  RETURN NEXT;
						END LOOP;
					END;

$$;
