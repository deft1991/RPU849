CREATE MATERIALIZED VIEW rpt_kpy_tbl1149 AS SELECT kpy.id,
    kpy.version,
    kpy.doc_date,
    kpy.num,
    kpy.obr_date,
    kpy.pz_close_date,
    kpy.szn_rec_id,
    kpy.close_rsn_id,
    kpy.pers_id,
    kpy.pz_close_rsn_id,
    kpy.szn_dep_id,
    kpy.close_date,
    kpy.sys_id,
    kpy.career_id,
    kpy.info_id,
    kpy.pob_id,
    t.rgn_id,
    t.szn_id,
    kpy.obr_date AS obrdate,
    t.fio,
    t.szn_name,
    t.rgn_name,
    t.tpr_name,
    t.kzf_name,
    t.order_date,
    t.first_period,
    t.second_period,
    t.has_order6,
    (t.first_period + t.second_period) AS full_period
   FROM (( SELECT row_number() OVER (PARTITION BY kpy_1.id ORDER BY ord_7.order_date DESC) AS numm,
            kpy_1.id,
            szn.id AS szn_id,
            szn.rgn_id,
            concat(pers.last_name, ' ', pers.first_name, ' ', pers.middle_name) AS fio,
            ord_7.order_date,
            szn.name AS szn_name,
            rgn.name AS rgn_name,
            tpr.name AS tpr_name,
            kzf.name AS kzf_name,
            kpy_1.num,
            (date_part('day'::text, (COALESCE((ord_6.end_date)::timestamp without time zone, (ord_1.end_date)::timestamp without time zone) - (ord_1.start_date)::timestamp without time zone)) + (1)::double precision) AS first_period,
            (date_part('day'::text, ((ord_7.end_date)::timestamp without time zone - (ord_7.start_date)::timestamp without time zone)) + (1)::double precision) AS second_period,
                CASE ord_6.id
                    WHEN NULL::bigint THEN false
                    ELSE true
                END AS has_order6
           FROM ((((((((((((((((psn_kpy kpy_1
             JOIN ref_szn szn ON ((szn.id = kpy_1.szn_dep_id)))
             JOIN ref_rgn rgn ON ((rgn.id = szn.rgn_id)))
             LEFT JOIN psn_order ord_6 ON ((ord_6.kpy_id = kpy_1.id)))
             JOIN ref_dict_line prkz_6 ON (((prkz_6.id = ord_6.prkz_id) AND ((prkz_6.code)::text = '6'::text))))
             JOIN ref_dict_line stp_6 ON (((stp_6.id = COALESCE(ord_6.status_id, (2714)::bigint)) AND ((stp_6.code)::text = '1'::text))))
             JOIN psn_order ord_1 ON ((ord_1.kpy_id = kpy_1.id)))
             JOIN ref_dict_line prkz_1 ON (((prkz_1.id = ord_1.prkz_id) AND ((prkz_1.code)::text = '1'::text))))
             JOIN ref_dict_line stp_1 ON (((stp_1.id = COALESCE(ord_1.status_id, (2714)::bigint)) AND ((stp_1.code)::text = '1'::text))))
             JOIN psn_order ord_7 ON (((ord_7.kpy_id = kpy_1.id) AND (ord_7.id <> ord_1.id))))
             JOIN ref_dict_line prkz_7 ON (((prkz_7.id = ord_7.prkz_id) AND ((prkz_7.code)::text = ANY ((ARRAY['1'::character varying, '7'::character varying])::text[])))))
             JOIN ref_dict_line stp_7 ON (((stp_7.id = COALESCE(ord_7.status_id, (2714)::bigint)) AND ((stp_7.code)::text = '1'::text))))
             LEFT JOIN psn_person pers ON ((kpy_1.pers_id = pers.id)))
             LEFT JOIN psn_kpy_info p_info ON ((kpy_1.info_id = p_info.id)))
             LEFT JOIN ref_dict_line kzf ON ((p_info.kzf_id = kzf.id)))
             LEFT JOIN psn_job_search_problem dfj ON ((dfj.kpy_id = kpy_1.id)))
             LEFT JOIN ref_dict_line tpr ON ((tpr.id = dfj.tpr_id)))
          WHERE ((1 = 1) AND (date_part('day'::text, ((ord_1.end_date)::timestamp without time zone - (ord_1.start_date)::timestamp without time zone)) <> date_part('day'::text, ((ord_7.end_date)::timestamp without time zone - (ord_7.start_date)::timestamp without time zone))) AND ((ord_6.id IS NOT NULL) OR (date_part('day'::text, ((ord_1.end_date)::timestamp without time zone - (ord_1.start_date)::timestamp without time zone)) <> ((364 + fn_count29feb(ord_1.start_date, ord_1.end_date)))::double precision) OR ((date_part('day'::text, ((ord_6.end_date)::timestamp without time zone - (ord_1.start_date)::timestamp without time zone)) + date_part('day'::text, ((ord_7.end_date)::timestamp without time zone - (ord_7.start_date)::timestamp without time zone))) <> (((728 + fn_count29feb(ord_1.start_date, ord_6.end_date)) + fn_count29feb(ord_7.start_date, ord_7.end_date)))::double precision) OR (NOT ((ord_6.start_date >= ord_1.start_date) AND (ord_6.start_date <= ord_1.end_date) AND (ord_6.end_date > ord_1.end_date)))))) t
     JOIN psn_kpy kpy ON ((kpy.id = t.id)))
  WHERE (t.numm = 1);
