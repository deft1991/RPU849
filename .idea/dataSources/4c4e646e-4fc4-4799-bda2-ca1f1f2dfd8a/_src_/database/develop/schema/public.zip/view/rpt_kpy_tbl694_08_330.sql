CREATE VIEW rpt_kpy_tbl694_08_330 AS SELECT DISTINCT kpy.id,
    kpy.version,
    kpy.close_date,
    kpy.doc_date,
    kpy.num,
    kpy.obr_date,
    kpy.pz_close_date,
    kpy.szn_rec_id,
    kpy.close_rsn_id,
    kpy.pers_id,
    kpy.pz_close_rsn_id,
    kpy.szn_dep_id,
    prikaz.order_date,
    NULL::bigint AS career_id,
    NULL::bigint AS info_id,
    NULL::bigint AS pob_id
   FROM ((((psn_kpy kpy
     JOIN psn_order prikaz ON ((prikaz.kpy_id = kpy.id)))
     JOIN ref_dict_line prikaz_prkz ON (((prikaz_prkz.id = prikaz.prkz_id) AND ((prikaz_prkz.code)::text = '4'::text))))
     JOIN psn_order prikaz2 ON ((prikaz2.kpy_id = kpy.id)))
     JOIN ref_dict_line prikaz_prkz2 ON (((prikaz_prkz2.id = prikaz2.prkz_id) AND ((prikaz_prkz2.code)::text = '5'::text))))
  WHERE (NOT (EXISTS ( SELECT prikaz11.id
           FROM (psn_order prikaz11
             JOIN ref_dict_line prkz11 ON (((prikaz11.prkz_id = prkz11.id) AND ((prkz11.code)::text = '11'::text))))
          WHERE ((prikaz11.parent_id = prikaz.id) AND (prikaz11.parent_id = prikaz2.id)))));
